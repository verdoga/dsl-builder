package resourcefind

// formatFor — единственный источник фиксированных соответствий ТЗ 9.3.
// extension включает начальную точку, сравнение не учитывает регистр.
// kind равен audio, video, image, script или subtitles; ok ложен для прочих
// расширений, тогда обе строки пусты. Никакого определения MIME по байтам,
// реестру Windows, установленным кодекам или внешним настройкам нет.
//
// audio: .mp3 — audio/mpeg; .wav — audio/wav; .ogg, .opus — audio/ogg;
// .m4a — audio/mp4; .aac — audio/aac; .flac — audio/flac.
// video: .mp4, .m4v — video/mp4; .webm — video/webm; .ogv — video/ogg;
// .mov — video/quicktime; .avi — video/x-msvideo; .mkv — video/x-matroska;
// .wmv — video/x-ms-wmv.
// image: .jpg, .jpeg — image/jpeg; .png — image/png; .gif — image/gif;
// .webp — image/webp; .bmp — image/bmp; .svg — image/svg+xml;
// .tif, .tiff — image/tiff; .avif — image/avif.
// script: .txt — text/plain.
// subtitles: .vtt — text/vtt; .srt — application/x-subrip;
// .ttml, .dfxp — application/ttml+xml; .ass, .ssa — text/plain.
func formatFor(extension string) (kind string, mimeType string, ok bool)
