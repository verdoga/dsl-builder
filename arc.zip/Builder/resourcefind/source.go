package resourcefind

import (
  "smoothlingua/diagnostic"
  "smoothlingua/filetree"
)

// explicitSource отличает ограничивающую пару двойных кавычек в source.raw.
// raw — уже распознанный элемент Contract 1.0, а не строка DSL для разбора.
// Не проверяет его грамматику заново и не получает значение пути из raw.
func explicitSource(raw string) bool

// mainFile выбирает explicitFile при кавычках в raw, иначе searchFile.
// value передаётся без обрезания пробелов, преобразования в число,
// повторного снятия экранирования и добавления либо удаления кавычек.
func (f *Finder) mainFile(mediaType string, raw string, value string, context diagnostic.Context) (File, *diagnostic.Error)

// explicitFile разрешает value через filetree.Resolve от baseDir и Inspect.
// Принимает только обычный файл с расширением объявленного mediaType.
// Абсолютный путь допускается вне resourceDirs; относительный не подставляется
// внутрь этих каталогов. При ошибке перехода к поиску по подстроке нет.
// Ошибки пути, доступа, вида объекта и расширения блокируют выбор.
func (f *Finder) explicitFile(mediaType string, value string, context diagnostic.Context) (File, *diagnostic.Error)

// searchFile получает candidates и требует ровно один различный файл.
// Ноль, включая отсутствие resourceDirs, — CodeNotFound с русской причиной
// «Ресурс не найден»; больше одного — CodeAmbiguous со всеми путями.
// Первый кандидат не выбирается из неоднозначного набора.
func (f *Finder) searchFile(mediaType string, value string, context diagnostic.Context) (File, *diagnostic.Error)

// matchesMedia проверяет разрешённое для mediaType расширение и вхождение
// всего value в любую часть имени с расширением, взятого из Entry.Path.
// Сопоставление без учёта регистра средствами стандартной библиотеки Go.
// Имена каталогов не участвуют; точки, пробелы и ведущие нули значимы.
// Числовых, длиновых и иных дополнительных ограничений DSL нет.
func matchesMedia(entry filetree.Entry, mediaType string, value string) bool
