package resourcefind

import (
  "smoothlingua/diagnostic"
  "smoothlingua/filetree"
)

// companions перечисляет tree.ReadDir только каталога Body.Entry.Path.
// Поиск основан на адресе выбранного имени, а не на адресе цели ссылки.
// Отбирает отдельными companion расшифровку .txt и все форматы субтитров.
// Базовое имя — имя Body.Entry.Path без последнего расширения; совпадение
// полное и без регистра, не подстрока. Подкаталоги не обходятся.
// Необязательные отсутствующие файлы допустимы независимо друг от друга.
// Ошибка перечисления или доступа к найденному объекту блокирует результат;
// проверка чтения байтов остаётся resourceembed и также обязательна.
func (f *Finder) companions(body File, context diagnostic.Context) (script *File, subtitles []File, err *diagnostic.Error)

// companion отбирает из entries обычные файлы с заданным полным базовым
// именем и extension без учёта регистра, затем применяет filetree.Unique.
// Отсутствие даёт nil, nil; один файл даёт File с MIME таблицы;
// несколько разных файлов, в том числе отличающихся только регистром,
// дают CodeAmbiguous со всеми кандидатами. Псевдонимы одного файла не спорят.
// Остальные имена и расширения не подключаются и вне resourceDirs не учитываются.
// Файловую систему не читает; entries получены одним ReadDir.
func companion(entries []filetree.Entry, baseName string, extension string, context diagnostic.Context) (*File, *diagnostic.Error)

// subtitleExtensions возвращает независимый срез фиксированного порядка:
// .vtt, .srt, .ttml, .dfxp, .ass, .ssa. Каждый формат выбирается отдельно;
// найденный формат не вытесняет другие. Таблица не настраивается пользователем.
func subtitleExtensions() []string
