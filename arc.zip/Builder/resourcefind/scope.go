package resourcefind

import (
  "smoothlingua/diagnostic"
  "smoothlingua/filetree"
)

// resolveDirectories разрешает каждое значение resourceDirs через
// filetree.Resolve от baseDir; абсолютные Windows-пути использует напрямую.
// Не снимает экранирование, не меняет пробелы и не ищет альтернативных баз.
// Возвращает все полные адреса в исходном порядке либо nil и ошибку.
func resolveDirectories(baseDir string, resourceDirs []string, context diagnostic.Context) ([]string, *diagnostic.Error)

// inventory вызывает tree.Walk с nil-фильтром для каждого указанного каталога.
// Проверка существования, типа и доступности, рекурсия без лимита глубины,
// обход ссылок и исключение циклов принадлежат filetree.
// Все обычные файлы, включая неподдерживаемые расширения, входят в учёт.
// Объединяет результаты через accountedPaths; пустая область допустима.
// Не пропускает очередной Walk из-за совпадения или пересечения каталогов.
// Ошибка одного каталога запрещает частичный результат.
func (f *Finder) inventory(context diagnostic.Context) ([]string, *diagnostic.Error)

// candidates ищет только в directories через tree.Walk с фильтром matchesMedia.
// Отбор каждого адреса по имени и расширению предшествует filetree.Unique,
// чтобы неподходящее имя ссылки не скрыло подходящее имя того же файла.
// Объединяет кандидатов разных каталогов по IdentityPath; один физический
// файл не создаёт неоднозначности из-за пересекающихся областей или ссылок.
// Итог упорядочивает filetree.ComparePaths по Entry.Path; при ошибке — nil.
// При отсутствии directories возвращает пустой список без обхода соседей.
func (f *Finder) candidates(mediaType string, value string, context diagnostic.Context) ([]filetree.Entry, *diagnostic.Error)
