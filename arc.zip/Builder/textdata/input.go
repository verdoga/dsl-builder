package textdata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// checkNodeKind проверяет только принадлежность kind области Build;
// остальные известные lesson.NodeType и неизвестные значения дают
// CodeUnsupportedType. Это граница пакета, а не повтор проверки enum схемы.
func checkNodeKind(kind lesson.NodeType, context diagnostic.Context) *diagnostic.Error

// checkDeclaration проверяет наличие декларации и её соответствие kind
// по единственному tag.Value, без разбора Raw. Допускает nil только для text;
// для instruction ожидает instr либо объявление multifill или ordering.
// Для heading ожидает header, для answerKey — key, для wordList — wordlist;
// остальные поддерживаемые имена соответствуют исходным тегам.
// Не выбирает выходной тип, не проверяет существование исходного родителя.
func checkDeclaration(kind lesson.NodeType, declaration *model.Line, context diagnostic.Context) *diagnostic.Error

// checkOwnLines проверяет только разрешённую форму собственного среза:
// пустой у title-only нод и выделенной инструкции multifill/ordering;
// content/blank у текстовых тел, separator дополнительно у example/table.
// У блочного instr допускает строки вложенного hint и его границы;
// точное отделение единственной подсказки делегировано splitInstructionHint.
// Однострочные объявления не получают дополнительные строки тела.
// Не вычисляет принадлежность нод в дереве по NestingLevel или ParentLine;
// собственный срез заранее выбран вызывающим конвейером.
func checkOwnLines(kind lesson.NodeType, declaration *model.Line, lines []model.Line, context diagnostic.Context) *diagnostic.Error
