package textdata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// buildInstruction координирует inlineText либо splitInstructionHint,
// joinBody и instructionHint. Создаёт один body с объединённым текстом
// инструкции; вложенная подсказка записывается в Hint этого body целиком.
// Подсказка не включается в Value и не порождает отдельные данные или ноду.
// Порядок обычных строк до и после hint сохраняется. Answers пуст.
// При декларации multifill или ordering читает только её inlineText:
// роль body принадлежит отдельной ноде instruction, а не упражнению.
// Отдельный instr и объявленная инструкция обрабатываются независимыми
// вызовами; совпадение текста не вызывает объединения или удаления.
// Пустая выделенная инструкция не создаёт body; решение не создавать
// ноду без исходной инструкции принимает structure до вызова Build.
// Подсказка без содержимого самой инструкции даёт CodeInstructionHint,
// чтобы ошибочный локальный вход не приводил к незаметной утрате подсказки.
func buildInstruction(declaration model.Line, lines []model.Line, context diagnostic.Context) ([]lesson.Data, *diagnostic.Error)

// splitInstructionHint отделяет собственные текстовые строки инструкции
// от единственного непосредственно вложенного hint по tag.Value и ParentLine.
// Вход ограничен одним instr одного экземпляра; глобальный индекс не строится.
// Возвращает обычные строки, исходную декларацию hint или nil и только его
// строки содержимого; границы hint не попадают в оба текстовых результата.
// Вторая подсказка, чужие вложенные теги или неоднозначная локальная связь
// дают CodeInstructionHint. Связывать соседний самостоятельный hint нельзя.
// Привязка подсказок к question и другим упражнениям остаётся exercisedata.
func splitInstructionHint(declaration model.Line, lines []model.Line, context diagnostic.Context) (body []model.Line, hintDeclaration *model.Line, hintLines []model.Line, err *diagnostic.Error)

// instructionHint возвращает пустую строку при hintDeclaration=nil,
// inlineText для однострочной подсказки либо joinBody с keepEmpty=false
// для блочной. Сохраняет порядок, разметку и переводы \n; ничего не связывает.
func instructionHint(hintDeclaration *model.Line, hintLines []model.Line, context diagnostic.Context) (string, *diagnostic.Error)
