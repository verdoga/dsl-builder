package textdata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// buildExample координирует необязательный title, splitExample и joinBody.
// Однострочный пример всегда содержит body из inlineText; дефисы и стрелки
// в нём не разделяют данные. Блок без разделителя даёт body; блок с одним
// содержательным разделителем даёт before, затем after. Название, если
// присутствует, стоит первым. У всех данных Answers пуст и Hint пуст.
func buildExample(declaration model.Line, lines []model.Line, context diagnostic.Context) ([]lesson.Data, *diagnostic.Error)

// splitExample разделяет только собственные строки блочного example по
// isExampleSeparator, исключая сам разделитель. При отсутствии разделителя
// before содержит всё тело, after пуст, separated=false; вызывающий код
// использует роль body. Повторный разделитель либо отсутствие непустого
// содержимого с одной из сторон дают CodeExampleSeparator с координатами.
// Внутристрочные дефисы, стрелки и экранированный литерал не разделяются.
func splitExample(lines []model.Line, context diagnostic.Context) (before []model.Line, after []model.Line, separated bool, err *diagnostic.Error)

// isExampleSeparator признаёт нормативный LineTypeSeparator.
// Совместимость со старым golden 3, строка 15: допускается LineTypeContent
// с единственным content, у которого Raw и ненулевое Value равны ---,
// а вне его диапазона в Line.Raw находятся только U+0020/TAB.
// Это узкое чтение сохранённой структурной записи по ТЗ 10.2; Value=---
// само по себе недостаточно. Экранированный Raw не является разделителем.
// Вызывается исключительно для строк тела блочного example.
func isExampleSeparator(line model.Line) bool
