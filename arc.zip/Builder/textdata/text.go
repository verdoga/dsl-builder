package textdata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// buildTextBlock координирует declarationTitle, inlineText и joinBody
// для text, note, alt, script, hint, answerKey, wordList и table.
// Необязательный title предшествует body. Однострочный content берётся
// из декларации; у блочной формы body содержит только переданные lines.
// Для самостоятельного текста declaration=nil и body берётся из lines.
// Несколько строк дают один body с переводами \n; пустые исходные строки
// отбрасываются. При отсутствии названия и содержимого возвращается пустой
// ненулевой срез; пустое тело не синтезируется как исключение multifill.
// Таблица, HTML, текст script, ключ и список слов остаются строками;
// ячейки, реплики, ответы, разметка и точки с запятой не разбираются.
func buildTextBlock(kind lesson.NodeType, declaration *model.Line, lines []model.Line, context diagnostic.Context) ([]lesson.Data, *diagnostic.Error)

// inlineText выбирает только content и placeholder декларации и вызывает
// composeElements. Возвращает текст и наличие содержательных элементов;
// отсутствие content не подменяется title или полным Raw объявления.
// tag, title, identifier, name и скобки в текст не включаются.
// Наличие элемента с пустым Value отличается от отсутствия элемента.
func inlineText(line model.Line, context diagnostic.Context) (string, bool, *diagnostic.Error)

// joinBody соединяет значения bodyLine ровно одним \n между сохранёнными
// физическими строками, не использует EOL и не добавляет завершающий перенос.
// keepEmpty=true применяется только к multifill: сохраняются все пустые
// строки, включая начальные, конечные и последовательные; они естественно
// могут образовать начальный или конечный \n в результате соединения.
// При false пустые строки отбрасываются; непустая разметка, например <br>,
// сохраняется буквально. Номера строк не используются для заполнения дыр.
// bool результата обозначает наличие хотя бы одной сохранённой строки.
func joinBody(lines []model.Line, keepEmpty bool, context diagnostic.Context) (string, bool, *diagnostic.Error)

// bodyLine возвращает пустую строку для LineTypeBlank, строку --- для
// нормативного LineTypeSeparator и composeElements для LineTypeContent.
// Separator сохраняется внутри table; example удаляет его до joinBody.
// Теги, границы блоков и иные нетекстовые строки здесь дают CodeInput.
// Content с пустым Value является корректной пустой строкой; отсутствие
// нужных элементов не заменяется чтением полного Raw как обычного текста.
func bodyLine(line model.Line, context diagnostic.Context) (string, *diagnostic.Error)

// composeElements соединяет выбранные content и placeholder в исходном
// порядке. Для content берёт Value без повторного снятия экранирования;
// для placeholder берёт полный Raw, никогда не его Value с ответом.
// Пустое Value content допустимо, nil даёт CodeMissingValue.
// Промежутки между выбранными диапазонами сохраняет через elementGap;
// за пределами первого и последнего выбранного элемента Raw не добавляет.
// Не вставляет разделительные пробелы от себя и не склеивает через теги.
// Все специальные записи multifill остаются целыми; ответы не извлекаются.
func composeElements(line model.Line, elements []model.Element, context diagnostic.Context) (string, *diagnostic.Error)

// elementGap возвращает непокрытый промежуток Line.Raw между End левого
// и Start правого элемента, считая колонки в кодовых точках Unicode с 1.
// Промежуток допустим только из U+0020/TAB; непокрытый содержательный текст,
// пересечение или выход диапазона за строку дают CodeInput без догадок.
// Никакой повторной обработки экранирования или нормализации пробелов нет.
func elementGap(line model.Line, left model.Element, right model.Element, context diagnostic.Context) (string, *diagnostic.Error)

// textDatum создаёт текстовый Data с переданной ролью, значением и hint,
// пустым ненулевым Answers и новым указателем Role. Используется только
// для title, body, before и after; выходные типы и роли не переобъявляются.
func textDatum(role lesson.DataRole, value string, hint string) lesson.Data
