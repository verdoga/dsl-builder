package textdata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// Build координирует только выбор специализированного формирования данных.
// kind уже выбран structure: task, step, variants, variant, heading,
// text, instruction, note, alt, script, hint, answerKey, example,
// wordList, table или multifill. Другой тип даёт CodeUnsupportedType.
// declaration — исходная строка объявления; nil допустим только для
// самостоятельного text. Назначение типа по исходному тегу здесь не выполняется.
// lines — собственные строки одного экземпляра ноды в порядке источника,
// без декларации, её закрывающей границы и содержимого дочерних нод.
// Срез может быть несмежным: номера строк не превращаются в пропуски текста.
// Для instruction из блочного instr в lines включён вложенный hint
// целиком, включая его декларацию и, при наличии, закрывающую границу.
// Для task, step, variant, variants и heading lines должен быть пуст.
// Для instruction из объявления multifill/ordering передаются эта декларация
// и пустой lines; содержимое упражнения в инструкцию не попадает.
// Для самого multifill декларационный content не является body.
// Обычные строки text передаются через lines при declaration=nil.
// Проверка пригодности локального среза — checkInput; далее вызовы
// buildTitleOnly, buildTextBlock, buildInstruction, buildExample или
// buildMultifill. При ошибке возвращается nil и одна блокирующая диагностика;
// частичный результат не возвращается. Успех обозначается nil ошибки.
func Build(kind lesson.NodeType, declaration *model.Line, lines []model.Line, context diagnostic.Context) ([]lesson.Data, *diagnostic.Error)

// checkInput координирует checkNodeKind, checkDeclaration и checkOwnLines.
// Проверяет поддерживаемый kind, декларацию и локальную форму строк.
// Не переопределяет kind, не обходит
// документ, не проверяет дерево, parser diagnostics, ID и версию контракта.
// Неподходящая декларация, чужие теги в собственных строках либо передача
// строк тела для title-only ноды дают CodeInput, а не молчаливую потерю текста.
// При NodeInstruction разрешены декларации instr, multifill и ordering;
// у двух последних lines пуст. NodeText с nil принимает только свой текст.
func checkInput(kind lesson.NodeType, declaration *model.Line, lines []model.Line, context diagnostic.Context) *diagnostic.Error

// buildTitleOnly формирует title для task из identifier, step и heading
// из title, variant из name; использует declarationTitle и textDatum.
// У variants возвращает пустой ненулевой срез; его потомки не читаются.
// Исходный ID task сохраняется как текст, не используется как итоговый ID.
func buildTitleOnly(kind lesson.NodeType, declaration model.Line, context diagnostic.Context) ([]lesson.Data, *diagnostic.Error)

// declarationTitle извлекает единственное соответствующее Value объявления:
// identifier у task, name у variant, title у heading, step и именуемых
// блоков text, note, alt, script, answerKey, wordList, table, example.
// Возвращает nil при отсутствии необязательного названия; отсутствие
// обязательного элемента или несколько кандидатов дают CodeInput.
// Присутствующее nil Value даёт CodeMissingValue; значение не обрезается.
// В variants, hint, instruction и multifill собственного title нет.
func declarationTitle(kind lesson.NodeType, declaration model.Line, context diagnostic.Context) (*string, *diagnostic.Error)
