package safewrite

import "smoothlingua/diagnostic"

// createCandidate эксклюзивно создаёт уникальный временный файл в каталоге
// target и сохраняет его дескриптор. Не создаёт каталогов и не изменяет цель.
func (t *transaction) createCandidate() *diagnostic.Error

// writeCandidate передаёт поток кандидата write; формат полностью принадлежит
// callback. Ошибка callback запрещает установку кандидата.
func (t *transaction) writeCandidate(write WriteFunc) *diagnostic.Error

// closeCandidate выполняет Sync и закрывает файл, учитывая обе ошибки.
// Вызывается и после ошибки записи; ошибка Sync не отменяет попытку Close.
// Не оставляет владение дескриптором у callback; повторно закрытый файл
// повторно не закрывается. Ошибка любого завершения запрещает проверку и замену.
func (t *transaction) closeCandidate() []*diagnostic.Error

// verifyCandidate вызывает verify только для успешно записанного и закрытого
// файла. Только его успешное завершение устанавливает verified.
func (t *transaction) verifyCandidate(verify VerifyFunc) *diagnostic.Error
