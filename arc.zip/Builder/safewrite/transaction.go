package safewrite

import (
  "os"
  "smoothlingua/diagnostic"
)

// transaction — приватное состояние одной операции; хранит владение файлами
// для отката и очистки, не представляет модель или план содержимого.
type transaction struct {
  // target — неизменяемый полный путь назначения.
  target string

  // original — исходное состояние цели; nil означает её отсутствие.
  original os.FileInfo

  // candidatePath — уникальный путь кандидата в каталоге target.
  candidatePath string

  // candidate — принадлежащий транзакции открытый файл; nil после закрытия.
  candidate *os.File

  // backupPath — уникальное резервное имя рядом с целью; пусто до выделения.
  backupPath string

  // originalMoved — исходник успешно перемещён в backupPath и ещё не
  // восстановлен или удалён после успешной установки результата.
  originalMoved bool

  // verified — запись, Sync, закрытие и проверка кандидата успешны.
  verified bool

  // installed — кандидат успешно установлен по target.
  installed bool
}

// inspectTarget проверяет путь и разрешение перезаписи без записи файлов.
// Различает отсутствие цели и ошибку доступа; существующая цель должна быть
// обычным файлом, а не каталогом или символической ссылкой. Возвращает её
// сведения для контроля идентичности перед заменой, либо nil при отсутствии.
func inspectTarget(target string, replaceExisting bool) (os.FileInfo, *diagnostic.Error)

// checkTarget проверяет перед заменой, что цель не появилась, не исчезла
// и не сменила известную идентичность, размер или время изменения с начала
// вызова. Изменение требует нового анализа в app. Это дополнительная проверка,
// а не гарантия исключения гонок с другими процессами.
func (t *transaction) checkTarget() *diagnostic.Error

// result создаёт снимок текущих мест кандидата и исходника без файлового ввода-вывода.
func (t *transaction) result() Result
