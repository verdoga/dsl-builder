package preview

import (
  "smoothlingua/catalog"
  "smoothlingua/module"
)

// Composition показывает курс, присутствующий юнит и весь текущий состав.
// Размещение берёт только из state, файлы — из value.Files; value.Manifest
// не читает. Допускает незавершённый catalog до Export и module.Validate:
// отсутствующие/неверные веса, конфликты и нераспределённые записи сохраняются.
// newFileNames — явный список добавляемых файлов от владельца операции;
// при создании пуст. Только эти строки получают пометку «НОВЫЙ» и ID урока.
// Не выводит версии отдельных уроков, в том числе при новой сборке.
// Небольшой координатор compositionHeading, compositionGroups и totals.
// Предусловие: у каждой записи есть ровно один готовый File; набор имён
// записей равен набору Files. Ошибка сопоставления не скрывает отдельный
// блок OrderConflicts, который вызывающий код может показать независимо.
func Composition(state *catalog.State, value *module.Module, newFileNames []string) (string, error)

// compositionHeading выводит название курса и только присутствующий юнит.
// Ничего не извлекает из имени архива, путей или содержимого уроков.
func compositionHeading(state *catalog.State) string

// compositionGroups сохраняет порядок Sections и Items, не сортируя веса.
// Секции нумеруются с 1; временный вес показывается только при его наличии.
// Пустая рабочая секция помечается как пустая, без обещания её записи в JSON.
// При Sectioned=true записи без секции идут в блок «Не распределены»;
// при false — «Без секций». Все записи показываются ровно один раз.
// Для строки вызывает compositionLesson; не выбирает первый из дублей файла.
func compositionGroups(state *catalog.State, files []*module.File, newFileNames []string) (string, error)

// compositionLesson выводит одной строкой техническое имя, название,
// присутствующий подзаголовок, исходный order, lineCount, число страниц
// и всех вложенных нод. Метаданные берёт из Item.Entry, счётчики — из File.
// nil Order отображает как «не задан»; неверную строку сохраняет буквально.
// isNew только отображает уже принятое отнесение к добавляемым урокам.
func compositionLesson(item catalog.Item, file *module.File, isNew bool) (string, error)

// totals выводит суммарное количество уроков, страниц и всех вложенных нод
// из полного набора файлов; пустой набор даёт нули, а не ошибку схемы.
// Координирует lessonCounts; это статистика отображения, не валидация.
func totals(files []*module.File) (string, error)

// lessonCounts получает количество страниц и нод любой вложенности
// из File.Lesson, не читая собственные Data и не пересчитывая lineCount.
// Счётчики соответствуют реально размещённым в памяти массивам.
func lessonCounts(file *module.File) (pages int, nodes int, err error)
