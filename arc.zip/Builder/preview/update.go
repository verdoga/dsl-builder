package preview

import (
  "smoothlingua/compare"
  "smoothlingua/module"
)

// UpdateHeading выводит путь архива, техническое имя, стабильный ID,
// итоговое название, присутствующий подзаголовок и старую/итоговую ревизии.
// before и after — файлы одного урока из старого и подготовленного модуля.
// Читает Version буквально; не увеличивает её и не формирует суффиксы.
// Переход может сохранять версию при изменениях только манифеста.
func UpdateHeading(archivePath string, before *module.File, after *module.File) (string, error)

// Replacements представляет только уровень и состав замен из готового plan.
// after содержит итог применения этого плана и решений по полям, включая
// рассчитанные владельцем ревизии ID; первичный кандидат сюда не передаётся.
// Не сравнивает модели повторно и не использует Plan.Fields как подтверждения.
// Небольшой координатор lessonReplacement либо pageReplacements.
// При пустом плане сообщает лишь «Замены нод не запланированы»;
// решение об отсутствии всей операции остаётся у вызывающего кода.
func Replacements(before *module.File, after *module.File, plan *compare.Plan) (string, error)

// pageReplacements представляет переданные изменённые страницы по порядку,
// вызывая pageReplacement либо nodeReplacement для каждого готового изменения.
// Собственное отличие ребёнка не добавляет родителя в перечень замен.
func pageReplacements(before *module.File, after *module.File, changes []compare.PageChange) (string, error)
