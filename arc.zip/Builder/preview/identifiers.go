package preview

import "smoothlingua/module"

// pageIDs возвращает точные ID всех страниц в порядке переданного снимка.
// Пустой список страниц допустим; это извлечение для показа, не генерация ID.
func pageIDs(file *module.File) ([]string, error)

// nodeIDs возвращает все полные ID нод выбранной страницы: родитель, затем
// дети в порядке массива, без ограничения глубины. Data не читаются.
// Пустая страница даёт пустой список; недоступный индекс даёт error.
func nodeIDs(file *module.File, pageIndex int) ([]string, error)

// nodeID возвращает точный ID по индексу страницы и пути ноды из compare.
// Пустой либо недоступный путь даёт error, без подбора ближайшей ноды.
func nodeID(file *module.File, pageIndex int, path []int) (string, error)

// idList представляет готовые ID полностью и в исходном порядке;
// пустой список отображает словом «нет», без искусственного диапазона.
func idList(values []string) string
