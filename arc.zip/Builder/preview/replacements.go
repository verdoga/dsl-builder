package preview

import (
  "smoothlingua/compare"
  "smoothlingua/module"
)

// nodeReplacement показывает страницу и одну пару полных ID «было → станет»
// по pageIndex и change.Path, только при сохранённой структуре плана.
// Перечисляет русские названия изменённых собственных полей из change.Fields,
// но не их значения. Не приписывает изменения всем последующим нодам.
func nodeReplacement(before *module.File, after *module.File, pageIndex int, change compare.NodeChange) (string, error)

// pageReplacement показывает ID и название страницы, все структурные причины
// и сохранение ID страницы. В отдельных списках «Будут удалены» и
// «Будут созданы» перечисляет все старые/новые ноды, включая вложенные.
// Списки независимы, могут быть пустыми и иметь разную длину; пары не строятся.
func pageReplacement(before *module.File, after *module.File, change compare.PageChange) (string, error)

// lessonReplacement явно объявляет полную замену урока и все её причины.
// Указывает сохранение ID урока и технического имени. Через pageIDs отдельно
// выводит старые и новые страницы, затем через nodeIDs — старые и новые ноды
// каждой стороны, сгруппированные по её собственным страницам.
// Не сопоставляет страницы по позиции, первичному ID или названию;
// не сворачивает фактические ID в диапазоны и не вычисляет новые номера.
func lessonReplacement(before *module.File, after *module.File, reasons []compare.Reason) (string, error)

// replacementReasons выводит все Description в исходном порядке и известные
// OldPointer/NewPointer с явными подписями старого снимка и кандидата.
// Адрес кандидата не выдаёт за новый ID, не подменяет конкретную причину
// общим сообщением о больших изменениях и не добавляет собственных причин.
func replacementReasons(reasons []compare.Reason) string
