package convert

import (
  "smoothlingua/diagnostic"
  "smoothlingua/filetree"
  "smoothlingua/lesson"
  "smoothlingua/parsed"
  "smoothlingua/parsed/model"
  "smoothlingua/resourcefind"
  "smoothlingua/resourceusage"
  "smoothlingua/structure"
)

// prepareResources вызывает resourcefind.Prepare(tree, input.Path,
// input.Result.Document.Metadata.ResourceDirs, context), затем при успехе
// usage.Register(accountedPaths). Возвращает полученный Finder без обёртки.
// Prepare проверяет все явно объявленные каталоги даже без медианод;
// nil/пустые resourceDirs передаются без подстановки области автопоиска.
// Единственное использование filetree — передача того же tree в Prepare:
// convert не обходит каталоги, не нормализует пути и не создаёт Resolver.
func prepareResources(input *parsed.Input, tree *filetree.Resolver, usage *resourceusage.Registry, context diagnostic.Context) (*resourcefind.Finder, *diagnostic.Error)

// fillMedia координирует mediaSource для binding.Entries[0].Source,
// finder.Find(mediaType, source.Raw, *source.Value, sourceContext) и
// resourceembed.Embed(selection, sourceContext). SourceContext содержит
// исходную строку и source.Start, включая экземпляр развёрнутого фрагмента.
// Привязка содержит только однострочное объявление медиа; постороннее тело
// даёт CodeMediaSource, а не отбрасывается при извлечении первого элемента.
// После Find регистрирует точные selection.AccountedPaths через usage.Register.
// После полного успеха Embed сначала присваивает node.Data, затем вызывает
// usage.MarkUsed(selection.AccountedPaths). Ошибка Find/Embed не отмечается
// как использование; при последующей ошибке Build весь локальный учёт исчезает.
// Порядок/роли файлов и MIME не определяет; данные не дополняет чужим script,
// не объединяет одинаковые байты и не встраивает невыбранные файлы области.
// Прочитанные ресурсы включены в строящийся урок до отметки использования;
// никакие данные/флаги/дети соседних нод не меняются.
func fillMedia(node *lesson.Node, binding structure.Binding, finder *resourcefind.Finder, usage *resourceusage.Registry, context diagnostic.Context) *diagnostic.Error

// mediaSource адаптирует одну готовую строку к параметрам Finder.Find:
// требует LineTypeTag, ровно один ElementTypeMediaType и ElementTypeSource
// с известными Value. Их отсутствие/неоднозначность даёт CodeMediaSource
// с исходными координатами и всеми конфликтующими местами в Related.
// mediaType берётся из Value первого элемента, source возвращается как
// существующий model.Element только для чтения; словарь типа проверен parsed.
// Raw/Value/Start сохраняются точно. Кавычки, пути, расширения, подстроки
// и MIME трактует только resourcefind. Пустота, длина, пробелы и числовой
// вид source не получают дополнительных ограничений старого DSL.
func mediaSource(line model.Line, context diagnostic.Context) (mediaType string, source model.Element, err *diagnostic.Error)
