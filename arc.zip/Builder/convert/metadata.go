package convert

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// newLesson создаёт только оболочку lesson.Lesson из существующего Document.
// DocumentID уже проверен parsed; переносится точно, без изменения регистра.
// Title=nil или LineCount=nil дают CodeMetadata с именем отсутствующего поля:
// Contract допускает неизвестность, но выход требует конкретного значения.
// Пустой известный Title и известный нулевой LineCount допустимы; заголовок
// не выводится из lines/имени файла, число строк не вычисляется из len(lines).
// Subtitle переносится с отдельным указателем, сохраняя null и пустую строку.
// LineCount переводится из известного model.*int точно в десятичный json.Number,
// без float64 и без дополнительных ограничений поверх существующей модели.
// FormatVersion равен lesson.FormatVersion. Version/CreatedAt оставлены
// revision.Initial; Pages — пустой ненулевой срез до результата structure.Build.
// Processing, Diagnostics и служебные метаданные парсера не копируются.
// При ошибке возвращает nil; исходный Document и его указатели не изменяет.
func newLesson(document model.Document, context diagnostic.Context) (*lesson.Lesson, *diagnostic.Error)
