package convert

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/resourcefind"
  "smoothlingua/resourceusage"
  "smoothlingua/structure"
)

// fillData обходит готовые bindings в порядке structure.Build и для каждой
// вызывает fillNode с bindingContext. Само дерево повторно не строит и не
// ищет исходники по физическому номеру: разные include имеют разные Binding.
// Количество, порядок и вложенность pages/Nodes остаются неизменными.
// На первой ошибке прекращает заполнение; локальная модель и реестр будут
// отброшены Build. Ошибки одного вызова сохраняются в порядке владельца.
func fillData(pages []lesson.Page, bindings []structure.Binding, finder *resourcefind.Finder, usage *resourceusage.Registry, context diagnostic.Context) []*diagnostic.Error

// fillNode получает адрес только через binding.Node(pages) и выбирает шаг
// по готовому Node.Type: NodeMedia — fillMedia; NodeQuestion, NodeSingleChoice,
// NodeMultipleChoice, NodeMatching, NodeOrdering — fillExercise; остальные
// поддерживаемые textdata типы — fillText. Не распознаёт исходные теги заново.
// Ошибка обогащается bindingError; нового типа или ноды взамен ошибочной нет.
// Вложенные ноды имеют собственные Binding и заполняются независимо.
func fillNode(pages []lesson.Page, binding structure.Binding, finder *resourcefind.Finder, usage *resourceusage.Registry, context diagnostic.Context) *diagnostic.Error

// fillText передаёт binding.TextSource() в textdata.Build(node.Type,
// declaration, lines, context) и только при успехе присваивает node.Data.
// Флаги не меняет: task сохраняет Speaking/Stepped от structure, multifill
// сохраняет пустые Flags с Checkable=nil. Внутренние ответы не извлекает.
// Отдельные instruction уже размещены structure и получают свои декларации;
// script обрабатывается как самостоятельная текстовая нода, отдельно от TXT.
// Правила текста, коллекций, переносов и подсказок остаются у textdata.
func fillText(node *lesson.Node, binding structure.Binding, context diagnostic.Context) *diagnostic.Error

// fillExercise передаёт полную binding.Lines() в exercisedata.Build.
// Только при успехе устанавливает node.Data и отдельный указатель Checkable
// на возвращённый bool, включая false; Speaking/Stepped не добавляет.
// Не отбирает answer/hint повторно, не создаёт коллекции и не вычисляет
// проверяемость самостоятельно. NodeMultifill сюда никогда не передаётся.
func fillExercise(node *lesson.Node, binding structure.Binding, context diagnostic.Context) *diagnostic.Error
