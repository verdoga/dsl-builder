package manifest

import (
  "smoothlingua/diagnostic"
  "smoothlingua/identity"
  "smoothlingua/order"
)

// validateEntry координирует проверки восьми полей одной записи.
// ID проверяет существующая identity.ValidateLessonID, имя — identity.ParseFileName;
// узкие проверки DSL, назначение номеров и сравнение ID не выполняются.
// Ненулевой Order проверяет существующая order.Validate без изменения строки;
// allowNullOrder определяется длиной содержащего массива, а не всего модуля.
// Title проверяет ValidateTitle, даты и целые — функции validate_values.go;
// Subtitle допускает null и любую корректную UTF-8 строку без minLength.
// Ошибки зависимостей сохраняют Code/Reason/Details и получают контекст
// записи и JSON Pointer; собственный парсер ID или арифметика веса не нужны.
func validateEntry(value Entry, allowNullOrder bool, pointer string, context diagnostic.Context) []*diagnostic.Error
