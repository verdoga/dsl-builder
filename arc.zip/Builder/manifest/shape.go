package manifest

import "smoothlingua/diagnostic"

// ValidateShape проверяет required, additionalProperties, типы и null до
// преобразования уже декодированного JSON в Manifest. moduleio передаёт
// обычное дерево encoding/json: map[string]any, []any, string, json.Number,
// bool и nil, полученное с UseNumber. Файлы и байты функция не читает.
// Вход обязан представлять ровно одно синтаксически корректное JSON-значение;
// его декодирование, UTF-8 и отсутствие хвостовых данных проверяет moduleio.
// Числовой тип float64 не принимается: точность должна сохраняться до проверки.
// Проверяет корневой объект и его три обязательных поля, затем делегирует
// вложенные объекты; неизвестные поля запрещены на каждом уровне схемы.
// Отсутствие order/subtitle отличается от допустимого явного null;
// unit:null и null вместо массива/объекта/обязательного скаляра запрещены.
// Значения const/pattern/minimum/minItems/uniqueItems проверяет Validate;
// для полной проверки прочитанного манифеста необходимы оба вызова.
// Успех — пустой срез; ошибки упорядочены по полям схемы и индексам массивов,
// неизвестные поля — лексикографически; JSON Pointer помещается в Details.
func ValidateShape(value any, context diagnostic.Context) []*diagnostic.Error

// validateCourseShape проверяет объект и ровно один набор полей:
// title/unit либо title/lessons/sections, затем формы выбранных потомков.
// Наличие unit учитывается независимо от значения; unit:null не равно отсутствию.
func validateCourseShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateUnitShape проверяет обязательные title:string, lessons:array,
// sections:array без дополнительных полей, затем формы их элементов.
func validateUnitShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateSectionsShape проверяет тип array и передаёт каждый элемент
// validateSectionShape; null вместо массива или объекта не разрешён.
func validateSectionsShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateSectionShape проверяет ровно title:string и lessons:array,
// обязательность обоих полей и формы записей через validateEntriesShape.
func validateSectionShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateEntriesShape проверяет тип array и формы всех записей;
// ограничение длины и зависимость null order от длины остаются в Validate.
func validateEntriesShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateEntryShape проверяет восемь обязательных полей без дополнительных:
// id/fileName/title/createdAt — string; order/subtitle — string либо null;
// lineCount/version — json.Number. Значения чисел проверяются после формы.
func validateEntryShape(value any, pointer string, context diagnostic.Context) []*diagnostic.Error
