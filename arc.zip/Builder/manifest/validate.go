package manifest

import "smoothlingua/diagnostic"

// Validate проверяет готовую модель по фиксированной схеме: версию, даты,
// скаляры, форму course, непустое содержимое уровня, массивы и uniqueItems.
// Это небольшой координатор validateCourse и проверок корневых значений.
// Не проверяет связи ZIP, уникальность отдельных ID/имён/весов/названий,
// сортировку, смешанное размещение и обязательность итогового веса по ТЗ.
// Для прочитанного JSON предварительно требуется успешный ValidateShape.
// Возвращает все независимые ошибки в порядке полей модели и индексов массивов;
// после ошибки формы не обращается к отсутствующим ветвям. Успех — пустой срез.
// context задаёт известный архив и manifest.json; внутри записи сохраняется
// Path, а FileName и LessonID дополняются её значениями, если они известны.
// Details всегда содержит JSON Pointer поля; координаты DSL не выдумываются.
func Validate(value Manifest, context diagnostic.Context) []*diagnostic.Error

// validateCourse проверяет название и ровно одну форму: unit без lessons/sections
// либо обе непосредственные коллекции без unit; делегирует проверку содержимого.
func validateCourse(value Course, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateUnit проверяет название и делегирует validateContents обязательные массивы.
func validateUnit(value Unit, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateContents проверяет ненулевые массивы и хотя бы один элемент суммарно,
// затем передаёт lessons и sections профильным проверкам. Одновременная
// непустота массивов допускается схемой; запрет смешения принадлежит catalog.
func validateContents(lessons []Entry, sections []Section, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateSections проверяет ненулевой массив, каждую секцию и uniqueItems;
// пустой массив разрешён. Одинаковый title сам по себе здесь не ошибка.
func validateSections(values []Section, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateSection проверяет имя и непустое lessons через профильные функции.
func validateSection(value Section, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateEntries проверяет ненулевой массив, минимум minimumItems (0 либо 1),
// записи и uniqueItems. При длине от двух null order запрещён у каждой записи;
// при длине один null допустим. Отдельные одинаковые числовые веса не ищет.
func validateEntries(values []Entry, minimumItems int, pointer string, context diagnostic.Context) []*diagnostic.Error
