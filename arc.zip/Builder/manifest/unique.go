package manifest

import "smoothlingua/diagnostic"

// validateUniqueEntries проверяет только uniqueItems одного массива lessons.
// Равны целые объекты по equalEntry, не отдельные ID, fileName или веса.
// Детали ошибки содержат JSON Pointer всех повторяющихся элементов.
func validateUniqueEntries(values []Entry, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateUniqueSections проверяет uniqueItems одного массива sections.
// Равны полное название и содержимое lessons с учётом порядка записей.
// Секции с одинаковым названием и разными lessons не равны по этой проверке.
func validateUniqueSections(values []Section, pointer string, context diagnostic.Context) []*diagnostic.Error

// equalEntry сравнивает все восемь полей по равенству JSON-значений:
// строки побуквенно и с регистром, null отдельно от строки, целые численно
// без потери точности. Строки order 1 и 01 различны; числа 1 и 1.0 равны.
// Предусловие: обе записи прошли проверки скаляров; сравнение не меняет их.
func equalEntry(left Entry, right Entry) bool

// equalSection сравнивает title и последовательность lessons через equalEntry.
// Предусловие: поля обеих секций прошли проверки; массивы не сортируются.
func equalSection(left Section, right Section) bool
