package manifest

import (
  "encoding/json"
  "smoothlingua/diagnostic"
)

// ValidateTitle проверяет корректный UTF-8, minLength 1 и наличие символа
// вне класса пробелов ECMAScript, соответствующего pattern \S схемы.
// Пробелы не обрезаются; ограничения имени секции сюда не добавляются.
// pointer — JSON Pointer проверяемого поля; пригодно для названий курса,
// юнита и урока до включения в полную модель. Успех — nil.
func ValidateTitle(value string, pointer string, context diagnostic.Context) *diagnostic.Error

// ValidateSectionTitle применяет ValidateTitle и точное отрицание pattern схемы:
// запрещены крайние U+0020, два соседних U+0020, TAB, CR и LF в любом месте.
// Другие пробелы не запрещаются сверх ограничений схемы; имя не исправляется.
func ValidateSectionTitle(value string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateCreatedAt проверяет полную запись YYYY-MM-DDTHH:MM:SSZ:
// четыре цифры года, верхний регистр T/Z, без долей, смещения и лишних знаков.
// Помимо pattern обязательна календарная проверка format date-time по RFC 3339,
// включая допустимость високосной секунды 60; один time.Parse не заменяет её.
// Время не назначается, не округляется и не сверяется с текущими часами.
func validateCreatedAt(value string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateInteger проверяет непустой корректный JSON number, математическую
// целочисленность и нижнюю границу minimum (0 либо 1) без float64 и int64.
// Целые записи с дробной частью из нулей или экспонентой допустимы по схеме;
// исходная запись не нормализуется. Ограничения длины/верхней границы нет.
func validateInteger(value json.Number, minimum int, pointer string, context diagnostic.Context) *diagnostic.Error
