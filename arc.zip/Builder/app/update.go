package app

import (
  "smoothlingua/catalog"
  "smoothlingua/diagnostic"
  "smoothlingua/module"
)

// compareUpdate сохраняет newFile из converted, вызывает compare.Build
// для oldFile.Lesson()/newFile.Lesson() и catalog.ProposePlacement
// с input.Result.Document.Metadata.Section/Order. План, оба файла и предложения
// остаются неизменными до Retry. current первоначально копирует baseline,
// revised=oldFile; отсутствие order не порождает предложение удаления веса.
// Каждое Fields и каждое предложение размещения получает отдельное ожидание.
func (op *Operation) compareUpdate() []*diagnostic.Error

// DecideField принимает одно решение по индексу полного plan.Fields.
// token должен адресовать текущий Snapshot; index проверяется, включая
// PageTitle с OldPage=-1 и After=nil. Нет решения «принять все поля».
// Сохраняет revision.Accept либо Reject; урок пока не пересобирает.
// После изменения уже принятого решения revisionReady сбрасывается,
// итоговые данные до PrepareRevision недоступны для записи; согласие отзывается.
// Reject не подменяет поля принятого урока значениями кандидата.
func (op *Operation) DecideField(token ReviewToken, index int, accept bool) []*diagnostic.Error

// PrepareRevision требует явного решения по каждому plan.Fields.
// Вызывает applyRevision и syncRevision, затем publishRevision и refreshPlan.
// До успешной подготовки обоих результатов op не меняется; публикация атомарна.
// Повторное применение использует только oldFile/newFile, исходный plan
// и стабильное op.at, никогда не предыдущий revised. Одна операция — +1 версия.
func (op *Operation) PrepareRevision(token ReviewToken) []*diagnostic.Error

// applyRevision вызывает revision.Apply с неизменными oldFile.Lesson(),
// newFile.Lesson(), plan, fields и контекстами этих файлов. При changed=false
// итогом остаётся сам oldFile с OriginalBytes; возвращённая копия урока
// не превращается в NewFile. При true применяется module.ReplaceFile.
func (op *Operation) applyRevision() (*module.File, bool, []*diagnostic.Error)

// syncRevision вызывает catalog.SyncLesson с окончательным file.Lesson().Document
// на копии текущего placement, сохраняющей принятые section/order.
// Ошибка nil State отклоняет результат целиком; ненулевой с блокировками
// остаётся редактируемым. op не меняется до publishRevision.
func (op *Operation) syncRevision(file *module.File) (*catalog.State, []*diagnostic.Error)

// publishRevision заменяет ровно один File в отдельном срезе current.Files,
// принимает подготовленный catalog и changed, устанавливает revisionReady
// и отзывает старое согласие. Входы здесь уже проверены предыдущими шагами.
func (op *Operation) publishRevision(file *module.File, changed bool, value *catalog.State)

// DecidePlacement отдельно решает одно неизменное предложение section/order.
// До вызова console показывает Snapshot.PlacementProposals[index].
// Accept применяет только указанное поле к текущему catalog через MoveLesson
// либо SetLessonWeight; Reject лишь отмечает отказ, не меняя принятый catalog.
// Ненулевой State с конфликтами может быть принят и исправлен из превью.
// nil State сохраняет ожидание и прежний снимок. Другие поля не подтверждаются.
// Уже решённый индекс повторно не применяется: следующие ручные изменения
// выполняются через отдельные Propose-методы. Accept отзывает прежний просмотр
// и вызывает refreshPlan; Reject сохраняет модель, но обновляет доступность действий.
func (op *Operation) DecidePlacement(token ReviewToken, index int, accept bool) []*diagnostic.Error
