package app

import (
  "os"
  "smoothlingua/diagnostic"
)

// Destination — сведения о цели для обязательного показа до подтверждения.
type Destination struct {
  // Directory — полный существующий каталог, введённый отдельно от имени.
  Directory string
  // FileName — проверенное имя ZIP, без разделителей каталогов.
  FileName string
  // Path — окончательный полный путь, показываемый перед согласием.
  Path string
  // Exists — цель существует и является обычным файлом.
  Exists bool
}

// targetState связывает показанную цель с наблюдением файловой системы.
type targetState struct {
  // destination — сведения, показываемые пользователю.
  destination Destination
  // info — исходная идентичность, размер и дата; nil при отсутствии.
  info os.FileInfo
}

// SetDestination разрешён только при Create. Принимает каталог и имя отдельно,
// вызывает archiveName, filetree.Resolve и inspectDestination. Успех публикует
// цель, отзывает прежнее окончательное согласие и требует нового Snapshot.
// Ошибка ввода не меняет прежнюю цель. Для Update/Add целью служит archivePath.
func (op *Operation) SetDestination(token ReviewToken, directory string, name string) []*diagnostic.Error

// archiveName проверяет самостоятельное имя Windows: непустое, без / и \ ,
// тома, управляющих символов, < > : " | ? *, крайних точки/пробела и имён
// устройств CON/PRN/AUX/NUL/CONIN$/CONOUT$/COM/LPT с зарезервированными
// номерами, включая допустимые Windows надстрочные варианты, независимо от
// регистра и расширения. Не обрезает ошибочные знаки и не исправляет ввод.
// Существующий суффикс .zip любого регистра сохраняет; иначе добавляет .zip.
// Имя проверяется также после добавления расширения; длина искусственно не ограничена.
func archiveName(name string) (string, *diagnostic.Error)

// inspectDestination проверяет существование каталога и os.Lstat цели;
// отличает os.IsNotExist от отказа доступа, запрещает каталог/ссылку вместо ZIP.
// Не создаёт каталог или файл; возвращает полный показанный путь и os.FileInfo.
func inspectDestination(path string) (*targetState, *diagnostic.Error)

// checkDestination сверяет текущую цель с показанным наблюдением: наличие,
// os.SameFile, размер и время. При изменении отзывает согласие; Update/Add
// требует повторного анализа архива, Create — нового показа цели и согласия.
// Дополняет контроль safewrite, начинающийся только с его собственного вызова.
func (op *Operation) checkDestination() *diagnostic.Error

// inputPath снимает одну внешнюю пару кавычек интерактивного пути и вызывает
// filetree.Resolve с явной baseDir. Не используется для source внутри JSON.
func inputPath(baseDir string, value string) (string, *diagnostic.Error)
