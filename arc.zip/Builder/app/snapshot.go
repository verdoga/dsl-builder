package app

import (
  "smoothlingua/catalog"
  "smoothlingua/compare"
  "smoothlingua/diagnostic"
  "smoothlingua/module"
  "smoothlingua/resourceusage"
  "smoothlingua/safewrite"
)

// ReviewToken связывает решение с конкретным снимком без открытых счётчиков.
// Нулевой, чужой и прежний токены отклоняются; это не разрешение записи.
type ReviewToken struct {
  // key — закрытая идентичность показанного состояния.
  key *reviewKey
}

// reviewKey отличает состояние операции по идентичности адреса.
type reviewKey struct {
  // owner — операция, которой принадлежит состояние.
  owner *Operation
}

// Snapshot — независимые подготовленные данные для console и preview.
// Изменение полей снимка не меняет op; Snapshot не принимается назад как команда.
type Snapshot struct {
  // Token — адрес именно этого принятого состояния для последующего решения.
  Token ReviewToken
  // Mode — сценарий для выбора применимого оформления.
  Mode Mode
  // ArchivePath — полный исходный путь ZIP либо пусто при создании.
  ArchivePath string
  // Catalog — независимый catalog.Clone, включая незавершённое размещение.
  Catalog *catalog.State
  // Module — независимый контейнер, полный Files даже при невозможном Export.
  // Manifest значим как итоговый только при ManifestReady; иначе это прежний
  // либо нулевой манифест. Для Composition используются Catalog и Module.Files.
  Module *module.Module
  // ManifestReady — Export и module.Validate успешно подготовили манифест.
  ManifestReady bool
  // NewFileNames — добавленные имена; при Create пусто для preview.Composition.
  NewFileNames []string
  // Conflicts — все готовые catalog.Conflicts текущего каталога.
  Conflicts []catalog.Conflict
  // Resources — Registry.Snapshot без суммирования счётчиков уроков.
  Resources resourceusage.Report
  // ManifestChanges — полный catalog.Changes относительно beforeCatalog;
  // при Create пусто: nil не передаётся API Changes, создание видно из состава.
  ManifestChanges []catalog.Change
  // Before — старый неизменяемый File для FieldProposal и UpdateHeading.
  Before *module.File
  // After — принятый итоговый File; готовность определяет RevisionReady.
  After *module.File
  // Plan — глубокая копия полного compare.Plan, без удаления Fields/Pages.
  Plan *compare.Plan
  // FieldAnswered — отдельный факт решения по каждому Plan.Fields.
  FieldAnswered []bool
  // FieldAccepted — выбранное согласие по тем же индексам; ожидание отдельно.
  FieldAccepted []bool
  // AcceptedFields — только принятые элементы Plan.Fields для preview.
  AcceptedFields []compare.FieldChange
  // RevisionReady — можно показывать итоговые ID и Replacements.
  RevisionReady bool
  // PlacementProposals — отдельные исходные section/order «было → станет».
  PlacementProposals []catalog.Change
  // PlacementAnswered — факт отдельного решения по каждому предложению.
  PlacementAnswered []bool
  // Target — полный путь и наблюдаемое существование цели до согласия.
  Target *Destination
  // NoChanges — после всех решений нет содержательной правки урока и
  // catalog.Changes; время исключено. До завершения решений и при Create false.
  NoChanges bool
  // Actions — применимые действия, без текста и нумерации меню.
  Actions Actions
  // Blockers — полный актуальный список структурированных блокировок записи.
  Blockers []*diagnostic.Error
  // WriteResult — фактический safewrite.Result; OriginalPath/TemporaryPath видны
  // и при Installed=true с ошибкой очистки. Успех требует также пустых ошибок.
  WriteResult *safewrite.Result
}

// Actions задаёт доступность конкретных операций для последовательного меню.
type Actions struct {
  // EditCatalog — доступны предложения названий и весов.
  EditCatalog bool
  // EditSections — доступны создание и переносы при Update/Add.
  EditSections bool
  // SortSections — есть секции для полного ввода весов.
  SortSections bool
  // DecideFields — остаются поля без решения.
  DecideFields bool
  // PrepareRevision — все поля решены, нужна подготовка итога.
  PrepareRevision bool
  // DecidePlacement — остаются предложения размещения без решения.
  DecidePlacement bool
  // ChooseDestination — при Create можно ввести либо изменить каталог и имя ZIP.
  ChooseDestination bool
  // MainMenu — возврат доступен всегда; незаписанное отменяется через Cancel.
  MainMenu bool
  // ReviewSave — готов состав с изменениями, нет ожидающих решений и блокировок.
  ReviewSave bool
  // Save — получено актуальное окончательное согласие и разрешение перезаписи.
  Save bool
  // Retry — можно повторить полный анализ после исправления исходников.
  Retry bool
  // Cancel — можно отменить незаписанную операцию и вернуться в главное меню.
  Cancel bool
  // Exit — выход доступен всегда; console предварительно вызывает Cancel.
  Exit bool
  // UnusedResources — доступен отчёт текущего анализа, включая пустой список.
  UnusedResources bool
}

// Snapshot создаёт независимые копии всех изменяемых данных через cloneModule,
// catalog.Clone, clonePlan и cloneDiagnostics; Report получен Registry.Snapshot.
// До создания Registry ресурсы представлены нулевым Report. Конфликты
// вычисляются на независимом Clone каталога, без ссылок на внутренние Items.
// Nil Operation даёт снимок с CodeState и доступными MainMenu/Exit.
// Не меняет дату, решения или готовность и не выполняет новый анализ.
func (op *Operation) Snapshot() Snapshot

// refreshPlan заменяет устаревшие блокировки проверками catalog.Validate,
// catalog.Conflicts, catalog.Export и module.Validate при успешном экспорте.
// При блокировках сохраняет полный Files и catalog для исправления.
// Для готового размещения экспорт использует прежний baseline.Manifest.CreatedAt,
// при Create — op.at в UTC; текущие часы не создают различий.
// Changes вызывается только для двух ненулевых catalog с подготовленными
// записями; конфликты размещения не скрывают различия. При блокировках
// экспорт не считается готовым, но Snapshot сохраняет ManifestChanges.
// Изменения создания определены наличием новых файлов. Отсутствие изменений
// определяется отдельно от готовности и не разрешает запись ошибочного плана.
func (op *Operation) refreshPlan() []*diagnostic.Error

// invalidateReview выдаёт новую закрытую идентичность после принятого изменения,
// отбрасывает кандидата правки и любое согласие записи, включая перезапись.
// Отказ от правки и ошибка её ввода не изменяют принятую модель.
func (op *Operation) invalidateReview()

// checkReview проверяет принадлежность, актуальность и допустимость состояния.
func (op *Operation) checkReview(token ReviewToken) *diagnostic.Error
