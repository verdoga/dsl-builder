package app

import (
  "smoothlingua/catalog"
  "smoothlingua/diagnostic"
)

// EditPreview содержит кандидат одной отдельной правки для показа и решения.
// Даже ненулевые Blockers не запрещают принять редактируемый catalog:
// они запрещают запись, а последующие правки могут устранить конфликт.
type EditPreview struct {
  // Token — закрытый идентификатор этого предложения, не токен записи.
  Token ReviewToken
  // Catalog — независимая копия всего предлагаемого размещения.
  Catalog *catalog.State
  // Changes — catalog.Changes между принятым и предлагаемым снимками.
  Changes []catalog.Change
  // Blockers — актуальные ошибки кандидата, включая временные конфликты.
  Blockers []*diagnostic.Error
}

// catalogEdit сохраняет неподтверждённый кандидат отдельно от placement.
type catalogEdit struct {
  // key — идентичность конкретного предложения.
  key *reviewKey
  // base — принятый снимок, на котором построено предложение.
  base *reviewKey
  // candidate — ненулевой результат операции catalog, не доступный снаружи.
  candidate *catalog.State
  // issues — блокировки предлагаемого снимка.
  issues []*diagnostic.Error
}

// Все Propose-методы сначала вызывают checkCatalogEdit. Новое предложение
// при активном edit отклоняется до RejectEdit/AcceptEdit; незавершённый
// ввод группы не создаёт edit. Пока edit активен, ReviewSave/Save запрещены.

// checkCatalogEdit проверяет token, готовность каталога и режим. При Update
// сначала требуются все решения исходных section/order, чтобы ручная правка
// не сделала исходное «было → станет» устаревшим. Сохранение недоступно
// во время отдельного предложения; ранее данное согласие отзывается.
func (op *Operation) checkCatalogEdit(token ReviewToken) *diagnostic.Error

// ProposeCourseTitle вызывает catalog.SetCourseTitle и stageCatalogEdit.
func (op *Operation) ProposeCourseTitle(token ReviewToken, title string) (*EditPreview, []*diagnostic.Error)

// ProposeUnitTitle вызывает catalog.SetUnitTitle и stageCatalogEdit;
// пустое название предлагает убрать юнит, без изменения уроков.
func (op *Operation) ProposeUnitTitle(token ReviewToken, title string) (*EditPreview, []*diagnostic.Error)

// ProposeSection нормализует пользовательское имя только через
// catalog.NormalizeSectionTitle, затем catalog.CreateSection на отдельной копии.
// Предложение показывает нормализованное имя; до AcceptEdit оно не принято.
// Доступно при Update/Add; пустая секция может требовать распределить все уроки.
func (op *Operation) ProposeSection(token ReviewToken, rawTitle string) (*EditPreview, []*diagnostic.Error)

// ProposeMove вызывает catalog.MoveLesson для одного технического имени.
// nil означает отсутствие секции; введённое имя сначала нормализует catalog.
// Разрешён при Update/Add; не подтверждает другие переносы или новые веса.
func (op *Operation) ProposeMove(token ReviewToken, fileName string, section *string) (*EditPreview, []*diagnostic.Error)

// ProposeFlatPlacement вызывает catalog.UseFlatPlacement; не снимает секции
// со всех записей автоматически. Переносы пользователь подтверждает отдельно.
func (op *Operation) ProposeFlatPlacement(token ReviewToken) (*EditPreview, []*diagnostic.Error)

// ProposeLessonWeight вызывает catalog.SetLessonWeight для одной записи,
// в частности для отсутствующего веса; не выполняет собственную арифметику.
func (op *Operation) ProposeLessonWeight(token ReviewToken, fileName string, raw string) (*EditPreview, []*diagnostic.Error)

// ProposeLessonWeights принимает только полный набор весов выбранной группы:
// keys — все её FileName ровно по одному, без чужих файлов. console собирает
// последовательный ввод локально и при отмене не вызывает этот метод.
// Координирует checkWeightMembers, applyGroupWeights и stageCatalogEdit.
// Изменения выполняются на catalog.Clone; ошибка любого ввода отклоняет
// весь набор. Временные конфликты промежуточных ненулевых кандидатов не мешают
// завершить набор; наружу идут только итоговые ошибки catalog.Refresh.
func (op *Operation) ProposeLessonWeights(token ReviewToken, section *string, weights map[string]string) (*EditPreview, []*diagnostic.Error)

// checkWeightMembers проверяет полноту набора по текущим catalog.Items;
// записи весов проверяет только catalog.SetLessonWeight, не app.
func checkWeightMembers(value *catalog.State, section *string, weights map[string]string) *diagnostic.Error

// applyGroupWeights последовательно применяет SetLessonWeight к закрытой копии
// в порядке Items, а не map; nil любого шага отбрасывает весь кандидат.
func applyGroupWeights(value *catalog.State, weights map[string]string) (*catalog.State, []*diagnostic.Error)

// ProposeSectionWeights передаёт полный независимый срез в
// catalog.SetSectionWeights; полноту, числа и сортировку проверяет владелец.
// Отмена последовательного ввода не вызывает этот API, частичного набора нет.
func (op *Operation) ProposeSectionWeights(token ReviewToken, weights []catalog.SectionOrder) (*EditPreview, []*diagnostic.Error)

// stageCatalogEdit не принимает nil candidate: тогда возвращает ошибки без
// изменения placement. Ненулевой кандидат с ошибками сохраняется отдельно,
// получает собственный токен и независимый EditPreview. Новое предложение
// не заменяет другое активное предложение. Только AcceptEdit может
// заменить принятое размещение.
func (op *Operation) stageCatalogEdit(candidate *catalog.State, issues []*diagnostic.Error) (*EditPreview, []*diagnostic.Error)

// AcceptEdit проверяет токен предложения и его base, принимает весь кандидат,
// отзывает прежнее согласие через invalidateReview и вызывает refreshPlan.
// Отдельное согласие не является окончательным согласием на запись архива.
func (op *Operation) AcceptEdit(token ReviewToken) []*diagnostic.Error

// RejectEdit отбрасывает только указанное актуальное предложение. Принятый
// catalog, файлы, решения полей и токен принятого снимка остаются прежними.
func (op *Operation) RejectEdit(token ReviewToken) []*diagnostic.Error
