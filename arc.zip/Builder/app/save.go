package app

import (
  "time"
  "smoothlingua/diagnostic"
  "smoothlingua/module"
  "smoothlingua/safewrite"
)

// saveReview связывает итоговое согласие с составом, целью и её существованием.
type saveReview struct {
  // key — отдельная идентичность окончательного показа записи.
  key *reviewKey
  // base — принятый снимок, для которого получено согласие.
  base *reviewKey
  // target — независимое наблюдение показанной цели.
  target *targetState
  // confirmed — явное окончательное согласие на запись всего плана.
  confirmed bool
  // replaceExisting — отдельное явное разрешение перезаписи показанной цели.
  replaceExisting bool
}

// SavePreview представляет конкретный результат для окончательного решения.
type SavePreview struct {
  // Token — адрес этого предложения записи, не токен каталога или поля.
  Token ReviewToken
  // Snapshot — полный актуальный состав и различия, подлежащие показу.
  Snapshot Snapshot
  // Destination — полный путь и существование цели; никогда не nil.
  Destination Destination
  // ManifestTimeWillChange — корневая дата обновится при фактической попытке
  // записи; это единственное служебное изменение после согласия, до callback.
  ManifestTimeWillChange bool
}

// ReviewSave требует актуальный token, готовый итог, отсутствие блокировок,
// решений в ожидании и активной правки. Проверяет содержательные изменения:
// без них не создаёт предложение и не пишет. Проверяет цель и сохраняет её
// наблюдение для ConfirmSave/Save, возвращая независимое SavePreview.
// Для Update/Add сначала checkDestination сравнивает цель с наблюдением
// loadBaseline: нельзя принять изменённый с анализа архив как новую базу.
// Полный исходный путь всегда показывается как перезапись.
func (op *Operation) ReviewSave(token ReviewToken) (*SavePreview, []*diagnostic.Error)

// ConfirmSave получает два независимых факта ответа: согласие на запись и
// явное согласие перезаписать существующий файл. При Exists=true без второго
// разрешения запись недоступна; его console получает отдельным вопросом.
// accept=false отбрасывает saving, возвращая к прежнему превью без изменения
// моделей. Успех связан только с Token актуального SavePreview и его base.
func (op *Operation) ConfirmSave(token ReviewToken, accept bool, replaceExisting bool) []*diagnostic.Error

// Save — короткая последовательность checkSave, freezeForWrite,
// writeFrozen и recordWriteResult. Согласие потребляется перед первой попыткой;
// повторный вызов не повторяет запись. Ошибки до установки позволяют вернуться
// к превью и получить новое согласие, если не осталось recovery-файлов.
// Installed с ошибками завершает возможность записи этой Operation, но не
// объявляет полный успех. Никаких автоматических повторов или удаления резервы.
func (op *Operation) Save(at time.Time) (safewrite.Result, []*diagnostic.Error)

// checkSave проверяет сохранённое согласие, текущий base, отсутствие правки,
// блокировок и ожиданий; вызывает checkDestination до любых записей.
func (op *Operation) checkSave() []*diagnostic.Error

// freezeForWrite вызывает catalog.Export с at.UTC().Format("2006-01-02T15:04:05Z"),
// присоединяет отдельный срез current.Files и вызывает module.Validate.
// Выполняется только после согласия и определения изменений, до safewrite.
// Меняет лишь корневой createdAt; даты/версии/lineCount уроков уже получены
// convert/revision. Результат закрыт от внешней правки и не меняется в callbacks.
func (op *Operation) freezeForWrite(at time.Time) (*module.Module, []*diagnostic.Error)

// writeFrozen вызывает safewrite.Write с показанным полным путём,
// подтверждённым replaceExisting, newWriteCallback и verifyCallback.
// Ни один callback не преобразует уроки, не обновляет дату и не меняет catalog.
func (op *Operation) writeFrozen(value *module.Module) (safewrite.Result, []*diagnostic.Error)

// recordWriteResult сохраняет Result и структурированные ошибки, отзывает
// согласие. Полный успех — только Installed=true и отсутствие всех ошибок.
// Installed с ошибками очистки показывается как установленный результат с
// неполным завершением; OriginalPath/TemporaryPath остаются видимы.
// Непустой TemporaryPath либо OriginalPath вне TargetPath означает остаточные
// recovery-файлы и блокирует Save/Retry. OriginalPath=TargetPath после полного
// отката сам по себе не считается остаточной резервой.
func (op *Operation) recordWriteResult(result safewrite.Result, issues []*diagnostic.Error)
