package app

import (
  "smoothlingua/catalog"
  "smoothlingua/compare"
  "smoothlingua/diagnostic"
  "smoothlingua/module"
)

// cloneModule копирует контейнер и срез Files; сами File можно разделять:
// все их поля закрыты, Lesson/OriginalBytes уже возвращают независимые копии.
// Manifest копируется глубоко: Course, Unit, указатели массивов и все массивы
// секций/записей, Subtitle/Order. Типы берутся из полей value без нового импорта
// manifest и без второй модели. Не экспортирует ошибочный catalog для копирования.
func cloneModule(value *module.Module) *module.Module

// clonePlan копирует весь compare.Plan, включая Fields.Before/After,
// Reasons, Pages.Reasons, Pages.Nodes.Path и Fields каждой ноды.
// Ни уровень замены, ни порядок, ни несопоставленные поля не изменяются.
func clonePlan(value *compare.Plan) *compare.Plan

// cloneChanges копирует catalog.Change, Section и байты Before/After,
// сохраняя отсутствие, null, точные числа и исходные строки.
func cloneChanges(values []catalog.Change) []catalog.Change

// cloneDiagnostics копирует ошибки, Related/Details и структурированные
// diagnostic причины рекурсивно; для цепочек errors.Join сохраняет каждую
// дочернюю причину независимой. Не выдаёт изменяемые внутренние ошибки наружу.
// Стандартные файловые ошибки также копируются со своей цепочкой Cause.
func cloneDiagnostics(values []*diagnostic.Error) []*diagnostic.Error

// copyEditPreview возвращает независимый catalog.Clone, cloneChanges и
// cloneDiagnostics; внутренний кандидат для AcceptEdit остаётся закрытым.
func (op *Operation) copyEditPreview() *EditPreview
