package app

import (
  "time"
  "smoothlingua/catalog"
  "smoothlingua/diagnostic"
  "smoothlingua/module"
  "smoothlingua/parsed"
)

// Analyze — короткая последовательность loadBaseline, loadSources,
// prepareIncoming, convertSources и prepareScenario; последующий этап только
// после успеха предыдущего. Сначала создаёт новый общий Resolver и Registry,
// фиксирует at до convert/revision. Готовность analyzed ставится только после
// всех этапов; ненулевой catalog с исправляемыми блокировками завершает анализ.
// Ошибка входа блокирует всю операцию; каталог с исправляемыми ошибками
// после prepareScenario остаётся доступен через Snapshot для редактирования.
// Повторный вызов требует Retry: старый план и новые входы не смешиваются.
func (op *Operation) Analyze(at time.Time) []*diagnostic.Error

// loadBaseline для Update/Add вызывает moduleio.Read и catalog.Import.
// Read с ошибкой всегда даёт остановку; Import с nil не позволяет продолжить,
// ненулевой State и ошибки сохраняются раздельно. Создание пропускает чтение.
// До чтения сохраняет inspectDestination для исходного ZIP, после чтения
// проверяет то же наблюдение через checkDestination. Оно остаётся опорой
// для окончательного согласия: новый осмотр не узаконивает чужую замену ZIP.
// baseline и beforeCatalog впоследствии не изменяются; Files сохраняют байты.
func (op *Operation) loadBaseline() []*diagnostic.Error

// loadSources координирует discoverSources и parsed.Load каждого найденного
// Entry.Path. Ни один JSON не исключается по содержимому; любая ошибка
// запрещает публикацию частичного состава. Входы впоследствии не изменяются.
func (op *Operation) loadSources() []*diagnostic.Error

// discoverSources разрешает путь через filetree.Resolve и общий tree.Inspect.
// Create вызывает JSONFiles, Update только JSONFile, Add выбирает по виду.
// Каталог сортируется filetree.SortRelative от выбранного каталога;
// одиночный файл имеет базу filepath.Dir(Path). Возвращаемый порядок стабилен.
func (op *Operation) discoverSources() []*diagnostic.Error

// prepareIncoming вызывает module.CheckNewIDs для Create/Add либо
// module.FindByID для Update. Для Create/Add затем module.AssignFileNames
// до convert; существующие имена не меняются, пробелы нумерации не занимаются.
// Для Update names содержит старое FileName, oldFile сохраняется целиком.
// Затем validateInitialPlacement вызывается только при Create.
func (op *Operation) prepareIncoming() []*diagnostic.Error

// validateInitialPlacement строит частичные catalog.Item из проверенных входов
// и вызывает catalog.ValidateNewPlacement до convert: заполнены ID, FileName,
// Order, Section, RelativePath через filetree.Relative и Context.
// Схему полной Entry здесь не проверяют и отсутствующие поля не выдумывают.
func (op *Operation) validateInitialPlacement() []*diagnostic.Error

// convertSources последовательно вызывает convertSource для каждого входа.
// Локальные Registry объединяет через op.usage.Merge только после успеха;
// при любой ошибке готовый частичный набор не становится current.
func (op *Operation) convertSources() []*diagnostic.Error

// convertSource вызывает convert.Build(input, op.tree, op.at, context), затем
// module.NewFile с заранее назначенным именем. Успешный Registry передаёт Merge.
// context содержит Path, FileName и исходный DocumentID; lineCount не вычисляется.
func (op *Operation) convertSource(input *parsed.Input, fileName string) (*module.File, []*diagnostic.Error)

// prepareScenario выбирает createCatalog, addCatalog либо compareUpdate,
// затем refreshPlan. Здесь только последовательность, без правил предмета.
func (op *Operation) prepareScenario() []*diagnostic.Error

// incomingItems связывает готовые File.Lesson().Document через
// catalog.EntryFromLesson с Section/Order соответствующих parsed.Input.
// RelativePath берёт filetree.Relative; порядок совпадает с отсортированным входом.
func (op *Operation) incomingItems() ([]catalog.Item, []*diagnostic.Error)

// createCatalog вызывает incomingItems и catalog.Create с введёнными названиями.
// nil State означает провал анализа. Ненулевой State с конфликтами сохраняет
// все converted в current.Files для превью и правок, даже до успешного Export.
func (op *Operation) createCatalog() []*diagnostic.Error

// addCatalog вызывает incomingItems и catalog.Add над Clone(beforeCatalog).
// При ненулевом результате current.Files — новый срез baseline.Files плюс
// converted: прежние File используются целиком, без NewFile/повторного convert.
// Отсутствующие веса, смешение и незавершённые секции остаются блокировками.
func (op *Operation) addCatalog() []*diagnostic.Error
