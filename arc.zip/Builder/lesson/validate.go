package lesson

import "smoothlingua/diagnostic"

// Validate координирует проверку модели и ValidateIDs, не изменяя value.
// nil даёт ошибку контракта; успех — пустой срез ошибок. Сначала возвращаются
// ошибки модели, затем ID; внутри этапа — в порядке полей схемы и массивов,
// без неопределённого обхода map. Непроверенный контейнер не порождает каскад ошибок.
// Context сохраняет известный путь или техническое имя, дополняется ID;
// точное место поля указывается в Details как JSON Pointer.
// Отсутствующие обязательные скалярные поля внешнего JSON проверяет ValidateJSON:
// в корректно созданной Go-модели они всегда сериализуются без omitempty.
// Не проверяет историю ревизий, источники данных, DSL и вычисление checkable.
func Validate(value *Lesson, context diagnostic.Context) []*diagnostic.Error

// validateDocument проверяет Version через validateInteger с минимумом 1,
// LineCount с минимумом 0, дату и ненулевой срез Pages; ID проверяет ValidateIDs.
// Title и Subtitle ограничены типами схемы: нет требования непустоты,
// обрезания пробелов или повторной проверки исходных заголовков DSL.
// formatVersion проверяет Validate; страницы делегируются validatePage.
func validateDocument(value Document, context diagnostic.Context) []*diagnostic.Error

// validatePage проверяет ненулевой срез Nodes, дополняет
// Context.PageID и передаёт каждую ноду validateNode. Пустой массив допустим.
// ID проверяет ValidateIDs; названия страниц не сравниваются с документом.
func validatePage(value Page, pointer string, context diagnostic.Context) []*diagnostic.Error
