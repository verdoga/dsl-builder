package lesson

import (
  "encoding/json"
  "smoothlingua/diagnostic"
)

// UnmarshalJSON координирует checkLessonJSON и декодирование известных полей
// через decodeDocumentJSON. Получатель меняется только при успехе.
// Имена свойств сравниваются точно по схеме, включая регистр: постороннее
// TITLE не заменяет title и не затеняет его при наличии обоих ключей.
// Ошибка возвращается как *diagnostic.Error с JSON Pointer; внешний контекст
// дополняет ValidateJSON или moduleio. Семантические ограничения проверяет Validate.
// Метод нужен для сохранения обязательности полей и точного контракта
// при использовании стандартного encoding/json, а не для файлового чтения.
func (value *Lesson) UnmarshalJSON(raw []byte) error

// decodeDocumentJSON восстанавливает только точные известные поля проверенного
// объекта Document, сохраняя числа как json.Number; страницы делегирует
// decodePageJSON. Незнакомые свойства не переносятся в модель.
func decodeDocumentJSON(raw json.RawMessage) (Document, *diagnostic.Error)

// decodePageJSON восстанавливает поля проверенной страницы и null названия;
// ноды передаёт decodeNodeJSON. Отсутствующие поля не синтезирует.
func decodePageJSON(raw json.RawMessage) (Page, *diagnostic.Error)

// decodeNodeJSON восстанавливает точные известные поля проверенной ноды;
// flags передаёт decodeFlagsJSON, data — Data.UnmarshalJSON, потомков — себе.
func decodeNodeJSON(raw json.RawMessage) (Node, *diagnostic.Error)

// decodeFlagsJSON восстанавливает указатели только для присутствующих
// разрешённых флагов, сохраняя различие nil и указателя на false.
func decodeFlagsJSON(raw json.RawMessage) (NodeFlags, *diagnostic.Error)
