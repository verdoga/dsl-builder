package lesson

import (
  "encoding/json"
  "smoothlingua/diagnostic"
)

// ValidateJSON проверяет один уже прочитанный JSON урока без файлового ввода.
// Координирует стандартное декодирование через Lesson.UnmarshalJSON и Validate.
// До декодирования проверяет обязательность, JSON-типы и допустимость null,
// чтобы пропущенные title, hint, flags, page.title и прочие поля нельзя было
// подменить нулевыми значениями Go. Проверяет все уровни рекурсивной модели.
// Ошибки синтаксиса и формы возвращаются до проверки зависимых значений.
// Незнакомые свойства игнорируются там, где схема их допускает;
// исключение — NodeFlags с additionalProperties=false.
// После успеха moduleio может декодировать raw через encoding/json в Lesson;
// Data.UnmarshalJSON сохраняет типизированное рекурсивное Value.
// Чтение ZIP, UTF-8 файлов и запись JSON остаются в moduleio.
func ValidateJSON(raw json.RawMessage, context diagnostic.Context) []*diagnostic.Error

// checkLessonJSON требует корневой объект и обязательные ненулевые
// formatVersion:string и document:object; документ передаёт checkDocumentJSON.
func checkLessonJSON(raw json.RawMessage, context diagnostic.Context) []*diagnostic.Error

// checkDocumentJSON проверяет обязательные id, title, createdAt:string,
// version, lineCount:number, pages:array; subtitle необязателен, string или null.
// Каждый элемент pages обязан быть объектом по checkPageJSON.
// Числовые ограничения, дата и ID проверяются в типизированной модели.
func checkDocumentJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// checkPageJSON требует id:string, title:string или null и nodes:array;
// наличие title обязательно даже при null. Ноды передаёт checkNodeJSON.
func checkPageJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// checkNodeJSON требует id, type:string, flags:object, data, nodes:array;
// делегирует checkFlagsJSON, checkDataJSON и рекурсивную проверку дочерних нод.
func checkNodeJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// checkFlagsJSON допускает только speaking, stepped, checkable, каждое
// присутствующее значение строго boolean; null и неизвестные ключи запрещены.
// Применимость известного флага типу ноды проверяет validateFlags.
func checkFlagsJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// checkDataJSON требует type:string, value, answers:array строк и hint:string;
// role при наличии строго строка. null в обязательных полях и answers запрещён.
// Форма value определяется type: string, EmbeddedFile-объект или массив Data;
// null запрещён. Вложенные данные передаются этому же правилу.
// Роли, количество элементов и размещение проверяет типизированная модель.
func checkDataJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// checkEmbeddedJSON требует объект с fileName, mimeType, content:string;
// все три поля обязательны и не допускают null.
func checkEmbeddedJSON(raw json.RawMessage, pointer string, context diagnostic.Context) []*diagnostic.Error

// requireJSONField проверяет наличие поля и его JSON-тип kind в прочитанном
// объекте. kind — string, number, boolean, object или array; nullable разрешает
// null, но не отсутствие. Возвращает исходное поле либо nil и ошибку.
// Для необязательного поля вызывается только при его наличии.
func requireJSONField(fields map[string]json.RawMessage, name string, kind string, nullable bool, pointer string, context diagnostic.Context) (json.RawMessage, *diagnostic.Error)

// decodeDataValue восстанавливает только значение union: строку, EmbeddedFile
// либо []Data. Использует encoding/json и не выполняет преобразование DSL.
// Неизвестный type или несоответствующий JSON-тип возвращают ошибку контракта.
// Имена свойств EmbeddedFile сопоставляются точно; посторонние свойства
// не могут затенить известные через нечувствительность encoding/json к регистру.
func decodeDataValue(kind DataType, raw json.RawMessage) (any, *diagnostic.Error)
