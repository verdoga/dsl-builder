package lesson

import (
  "encoding/json"
  "smoothlingua/diagnostic"
)

// validateInteger проверяет корректное JSON-число, математическую
// целочисленность и значение не меньше minimum средствами стандартной
// библиотеки, без float64 и предела int. minimum здесь равен 0 или 1.
// Целочисленные дробная и экспоненциальная записи допускаются по JSON Schema;
// проверка не нормализует исходную запись и не выполняет арифметику ревизий.
func validateInteger(value json.Number, minimum int, pointer string, context diagnostic.Context) *diagnostic.Error

// validateCreatedAt проверяет всю строку по pattern схемы и format date-time:
// четыре цифры года, календарную дату, время и правила RFC 3339, UTC с Z,
// секунды без дробной части. Одного регулярного выражения недостаточно.
// Не проверяет, является ли время текущим, и не назначает новое значение.
func validateCreatedAt(value string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateEmbeddedFile проверяет имя без пути через validateEmbeddedName
// и Content через validateBase64; MIMEType остаётся строкой по схеме.
// Не выводит Base64 в диагностику, не проверяет содержимое медиаконтейнера
// и не воспроизводит таблицу расширений и MIME из resourcefind.
func validateEmbeddedFile(value EmbeddedFile, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateEmbeddedName проверяет требование имени без пути из ТЗ 9.5:
// запрещает разделители / и обратную косую черту и путь с обозначением тома.
// Файловая система не опрашивается; дополнительные требования к длине,
// белому списку символов и расширениям не вводятся.
func validateEmbeddedName(value string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateBase64 проверяет стандартный алфавит, padding, отсутствие переносов
// и корректность полного кодирования по ТЗ 6.2. Пустая строка допустима
// как кодирование пустого файла. Исходный файл и точность его копии неизвестны.
func validateBase64(value string, pointer string, context diagnostic.Context) *diagnostic.Error
