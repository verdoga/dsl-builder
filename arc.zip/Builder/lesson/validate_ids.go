package lesson

import (
  "smoothlingua/diagnostic"
  "smoothlingua/identity"
)

// ValidateIDs проверяет ID урока через identity.ValidateLessonID v2, затем
// синтаксис ID страниц и нод, принадлежность
// страниц и нод identity.LessonKey(Document.ID) и уникальность полных ID
// внутри одного урока. Проверяет страницы и все уровни дерева нод.
// nil ошибочен; успешный результат — пустой срез. Исходный урок не изменяет.
// Непоследовательные номера допустимы; номера не преобразуются в int.
// Не сравнивает базовые номера с игнорированием суффикса и не проверяет
// ревизию суффикса относительно Document.Version — это зона revision.
func ValidateIDs(value *Lesson, context diagnostic.Context) []*diagnostic.Error

// idIndex хранит первые места полных ID для диагностики повторов одного урока.
// Состояние существует только во время ValidateIDs и не сериализуется.
type idIndex struct {
  // pages — полный ID страницы и JSON Pointer первого вхождения.
  pages map[string]string

  // nodes — полный ID ноды и JSON Pointer первого вхождения во всех страницах.
  nodes map[string]string
}

// validatePageID делегирует разбор identity.ParsePageID, проверяет префикс
// через validatePagePrefix и регистрирует полный ID через checkUniqueID.
// Ошибку identity дополняет Context и указателем поля, сохраняя исходный Code.
func validatePageID(value string, lessonKey string, index *idIndex, pointer string, context diagnostic.Context) []*diagnostic.Error

// validatePagePrefix сравнивает разобранный Prefix с ключом содержащего урока.
func validatePagePrefix(parts identity.PageIDParts, lessonKey string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateNodeID делегирует разбор identity.ParseNodeID, проверяет префикс
// через validateNodePrefix и регистрирует полный ID через checkUniqueID.
// Форматирование и выдача новых ID не выполняются.
func validateNodeID(value string, lessonKey string, index *idIndex, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateNodePrefix сравнивает разобранный Prefix с ключом содержащего урока.
func validateNodePrefix(parts identity.NodeIDParts, lessonKey string, pointer string, context diagnostic.Context) *diagnostic.Error

// checkUniqueID сравнивает полные проверенные строки точным равенством;
// при повторе возвращает ошибку с указателями первого и текущего вхождений.
// При первом вхождении запоминает pointer в переданном локальном индексе.
func checkUniqueID(value string, seen map[string]string, pointer string, context diagnostic.Context) *diagnostic.Error

// validateNodeIDs проверяет ID одной ноды и её потомков в порядке дерева,
// используя один общий индекс для всех страниц урока.
func validateNodeIDs(value Node, lessonKey string, index *idIndex, pointer string, context diagnostic.Context) []*diagnostic.Error
