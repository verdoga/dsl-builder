package lesson

import "smoothlingua/diagnostic"

// validateData проверяет дискриминатор и конкретный тип Value, ненулевой
// массив Answers, известную роль при её наличии и локальные ограничения роли.
// Для EmbeddedFile вызывает validateEmbeddedFile, для коллекции проверяет
// роли непосредственных детей и рекурсивно каждый элемент. Глубина не
// ограничивается произвольным пределом. Текст и ответы не разбираются как DSL.
func validateData(value Data, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateDataValueType требует string, EmbeddedFile или ненулевой []Data
// строго по Type. Неизвестный Type, nil и другие конкретные Go-типы ошибочны.
// Типы элементов Answers и Hint обеспечены Go-моделью и checkDataJSON.
func validateDataValueType(value Data, pointer string, context diagnostic.Context) *diagnostic.Error

// validateDataRole проверяет enum роли; nil сам по себе допустим.
// items, options, positions требуют DataCollection; instruction, item,
// option, position требуют DataText. options и positions содержат минимум
// два элемента. Прочие роли не ограничивают тип сверх правил схемы.
func validateDataRole(value Data, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateCollectionRoles проверяет непосредственных детей коллекции:
// items требует роль item у каждого, options — option, positions — position.
// У других коллекций роль необязательна, но item, option и position запрещены.
// В любой коллекции запрещены instruction, options и positions.
// Роль items внутри других коллекций сама по себе допустима по схеме.
func validateCollectionRoles(parentRole *DataRole, children []Data, pointer string, context diagnostic.Context) []*diagnostic.Error
