package lesson

import "smoothlingua/diagnostic"

// validateNode проверяет Type, Flags, обязательные ненулевые срезы Data
// и Nodes, делегирует собственные данные и затем дочерние ноды.
// Пустые массивы допустимы; ограничений DSL на вложенность не добавляет.
func validateNode(value Node, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateNodeType проверяет enum всех 22 типов фиксированной схемы.
func validateNodeType(value NodeType, pointer string, context diagnostic.Context) *diagnostic.Error

// validateFlags допускает Speaking и Stepped только у task, Checkable только
// у multifill, singleChoice, multipleChoice, ordering, matching и question.
// У остальных типов все указатели nil; неприменимый указатель ошибочен
// даже при false. Все применимые флаги необязательны. Соответствие флагов
// ответам, внутренней разметке и истории преобразования здесь не вычисляется.
func validateFlags(kind NodeType, flags NodeFlags, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateNodeData проверяет каждый Data, непосредственные роли и число
// коллекций отдельными функциями; сохраняет исходный порядок элементов.
func validateNodeData(kind NodeType, data []Data, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateDirectRole требует известную непустую роль; item, option, position
// запрещены. instruction и options разрешены только для singleChoice,
// multipleChoice, matching; positions — только для ordering.
// Другие роли не ограничиваются по типу ноды сверх фиксированной схемы.
func validateDirectRole(kind NodeType, role *DataRole, pointer string, context diagnostic.Context) *diagnostic.Error

// validateCollectionCounts требует ровно одну options у singleChoice,
// multipleChoice и matching, ровно одну items у matching и ordering,
// не более одной positions у ordering и instruction у трёх разрешённых типов.
// Минимум элементов прямой items: matching — один, ordering — два.
// На items других типов нод дополнительных ограничений схема не накладывает.
// Общий минимум options и positions проверяет validateDataRole.
func validateCollectionCounts(kind NodeType, data []Data, pointer string, context diagnostic.Context) []*diagnostic.Error
