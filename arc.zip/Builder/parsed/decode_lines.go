package parsed

import (
  "encoding/json"
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// decodeLine читает line/nestingLevel как целые, parentLine как integer|null,
// type/raw/eol как строки, hasErrors как boolean; все поля обязательны.
// elements — ненулевой массив ненулевых объектов через decodeElement.
func decodeLine(raw json.RawMessage, field string, context diagnostic.Context) (model.Line, *diagnostic.Error)

// decodeElement читает type/raw как строки, value как string|null,
// start/end как целые, errorIds как ненулевой массив строк без null.
// Все поля обязательны; семантическое value сохраняется без деэкранирования DSL.
func decodeElement(raw json.RawMessage, field string, context diagnostic.Context) (model.Element, *diagnostic.Error)

// decodeDiagnostic читает id/source/code/severity/message/scope как строки,
// fatal как boolean, location как объект Location|null, relatedLocations
// как ненулевой массив ненулевых Location. Все поля Contract обязательны.
func decodeDiagnostic(raw json.RawMessage, field string, context diagnostic.Context) (model.Diagnostic, *diagnostic.Error)

// decodeLocation читает обязательные ненулевые объекты start/end через
// decodePosition. Допустимость null у location проверяет decodeDiagnostic.
func decodeLocation(raw json.RawMessage, field string, context diagnostic.Context) (model.Location, *diagnostic.Error)

// decodePosition читает обязательные целые line/column ненулевого объекта.
func decodePosition(raw json.RawMessage, field string, context diagnostic.Context) (model.Position, *diagnostic.Error)
