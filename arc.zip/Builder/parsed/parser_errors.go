package parsed

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// parserErrors независимо собирает четыре блокирующих признака ТЗ 5.3:
// document.hasErrors, severity=error, line.type=invalid, element.type=unparsed.
// Несогласованность признаков не отменяет ни одного срабатывания.
// Порядок: признак документа, error-диагностики в исходном порядке,
// затем invalid/unparsed по строкам и элементам. Warning/recommendation
// не включаются в пользовательские сообщения или Details.
// При true без доступной error-диагностики всё равно возвращается ошибка.
func parserErrors(result *model.Result, context diagnostic.Context) []*diagnostic.Error

// parserDiagnostic преобразует только severity=error в diagnostic.Error.
// Сохраняет code/message/source/id/fatal в Details, начало location
// в Context, дополнительные начала диапазонов в Related; точные концы
// диапазонов при наличии — в Details. Путь всегда от технического JSON.
// Русская Reason объясняет блокировку, исходное сообщение не переписывается.
func parserDiagnostic(item model.Diagnostic, context diagnostic.Context) *diagnostic.Error

// parserMarker оформляет один признак с известными строкой/колонкой.
// related содержит только доступные error-диагностики, связанные с признаком;
// их код и сообщение сохраняются, отсутствующие сведения не выдумываются.
// Для document.hasErrors доступны все error, для invalid — начинающиеся
// на строке либо связанные через её элементы, для unparsed — его errorIds.
func parserMarker(marker string, context diagnostic.Context, related []model.Diagnostic) *diagnostic.Error
