package parsed

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// validateContract координирует независимые небольшие проверки документа,
// метаданных, processing, строк/элементов, диагностик и родительских связей.
// Номера индексируются до проверки ссылок; проверка циклов требует разрешимых
// ссылок. Неполные индексы наружу не возвращаются. Успех даёт LineIndex и nil.
// Для ошибок сохраняется порядок полей Contract, затем исходных массивов;
// обход map не задаёт порядок сообщений. Входные данные не нормализуются.
func validateContract(result *model.Result, context diagnostic.Context) (LineIndex, []*diagnostic.Error)

// validateDocument проверяет известные lineCount/byteLength >= 0,
// encoding="UTF-8" и sha256 из 64 строчных шестнадцатеричных символов.
// Nullable-сведения сохраняются неизвестными; путь исходного DSL не открывается.
// dslVersion не заменяется и не ограничивается повторной DSL-валидацией.
// Согласованность физических строк проверяет indexNumbers.
func validateDocument(document model.Document, context diagnostic.Context) []*diagnostic.Error

// validateSourceName проверяет только явный инвариант Contract: известный
// filePath абсолютен и его последний компонент совпадает с fileName.
// Использует правила путей целевой Windows, не требует существования DSL-файла
// и не разрешает этот путь относительно технического JSON.
func validateSourceName(document model.Document, context diagnostic.Context) *diagnostic.Error

// validateMetadata требует ненулевой documentId по ТЗ 5.2 и вызывает
// identity.ValidateLessonID v2 без собственного белого списка DSL.
// Исходные ID, регистр и все строки сохраняются. При заданном order вызывает
// order.Validate, сохраняя исходный вес и контекст ошибки зависимости.
// title/subtitle/section/order/resourceDirs=null не заменяются значениями;
// наличие веса в группе и ограничения выходных названий проверяют владельцы.
// Ресурсные пути не проверяются на существование и не нормализуются здесь.
func validateMetadata(metadata model.DocumentMetadata, context diagnostic.Context) []*diagnostic.Error

// validateProcessing проверяет непустые уникальные id, неотрицательные
// известные durationMs и startedAt в RFC 3339 с часовым поясом.
// Tool — открытый словарь, version — свободная строка; порядок массива
// не пересортировывается по startedAt. Возвращает id -> индекс запуска.
func validateProcessing(processing []model.Processing, context diagnostic.Context) (map[string]int, []*diagnostic.Error)
