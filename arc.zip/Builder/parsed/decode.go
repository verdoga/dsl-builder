package parsed

import (
  "encoding/json"
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// decodeResult принимает ровно один JSON-объект с допустимым хвостовым
// whitespace; комментарии JSONC и второе JSON-значение не допускаются JSON.
// Проверяет наличие formatVersion/document/processing/lines/diagnostics,
// строковый formatVersion и точное равенство model.FormatVersion1.
// Document — объект, остальные три поля — ненулевые массивы объектов.
// Поэлементное декодирование делегируется функциям соответствующих моделей.
// Числа не проходят через float64. Неизвестные поля игнорируются на каждом
// уровне; имена известных полей сопоставляются точно по JSON-тегам model.
// Все поля Contract присутствуют, даже когда допускают null; отсутствие
// не приравнивается к null, false, нулю или пустому массиву.
func decodeResult(data []byte, context diagnostic.Context) (model.Result, *diagnostic.Error)

// decodeObject проверяет ненулевой объект и наличие required; возвращает
// RawMessage полей без новой входной модели. Неизвестные ключи не запрещает.
// При повторе JSON-ключа применяется поведение encoding/json: последнее
// значение; отдельного запрета дублей ключей входной контракт не вводит.
// field — путь поля внутри JSON для Details, не координата исходного DSL.
func decodeObject(raw json.RawMessage, required []string, field string, context diagnostic.Context) (map[string]json.RawMessage, *diagnostic.Error)

// decodeArray принимает массив RawMessage, сохраняя порядок; null допустим
// только при nullable. Отсутствующее значение всегда ошибочно.
// Допустимость каждого элемента проверяет вызывающий профильный декодер.
func decodeArray(raw json.RawMessage, nullable bool, field string, context diagnostic.Context) ([]json.RawMessage, *diagnostic.Error)

// decodeScalar читает одно известное строковое, логическое или целое поле
// в указатель dst соответствующего типа model средствами encoding/json.
// Проверяет наличие, JSON-тип и nullable до присваивания: null не становится
// нулём или false. Integer-поля не принимают дробную запись и строки.
// nullable соответствует указателям model, а не умолчанию сериализатора.
func decodeScalar(raw json.RawMessage, dst any, nullable bool, field string, context diagnostic.Context) *diagnostic.Error

// decodeStrings читает массив строк без null-элементов; nullable относится
// только к массиву целиком. null и пустой массив сохраняются различными.
func decodeStrings(raw json.RawMessage, nullable bool, field string, context diagnostic.Context) ([]string, *diagnostic.Error)
