package parsed

import "smoothlingua/diagnostic"

// readBytes полностью читает файл по переданному адресу, закрывает его при
// любом исходе и сообщает ошибки чтения/закрытия с исходной Cause и путём.
// Каталоги не обходит, пути не разрешает и исходник не изменяет.
func readBytes(path string) ([]byte, []*diagnostic.Error)

// prepareUTF8 проверяет корректность всех байтов UTF-8 до JSON-декодирования
// и снимает не более одного BOM только в начале. Не исправляет неверные байты,
// не удаляет BOM в строковых данных, пробелы или переносы внутри JSON.
// Это BOM технического JSON, а не document.hasBom исходного DSL.
func prepareUTF8(data []byte, context diagnostic.Context) ([]byte, *diagnostic.Error)
