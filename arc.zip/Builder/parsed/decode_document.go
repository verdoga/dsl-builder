package parsed

import (
  "encoding/json"
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// decodeDocument читает все поля Document через decodeObject/decodeScalar.
// dslVersion/fileName/filePath/encoding/sha256 — string|null,
// hasBom — boolean|null, lineCount/byteLength — integer|null,
// metadata — ненулевой объект через decodeMetadata, hasErrors — boolean.
// Не восстанавливает неизвестные значения из строк или имени JSON-файла.
func decodeDocument(raw json.RawMessage, field string, context diagnostic.Context) (model.Document, *diagnostic.Error)

// decodeMetadata читает documentId/title/subtitle/section/order как string|null,
// resourceDirs как string[]|null; каждое поле обязательно присутствует.
// Наличие documentId=null допустимо для формы Contract, но запрещено затем ТЗ.
// Отсутствующий documentId диагностируется как CodeMissingID.
func decodeMetadata(raw json.RawMessage, field string, context diagnostic.Context) (model.DocumentMetadata, *diagnostic.Error)

// decodeProcessing читает id/tool как строки, version/startedAt как string|null,
// durationMs как integer|null; все пять полей обязательны, запись не null.
func decodeProcessing(raw json.RawMessage, field string, context diagnostic.Context) (model.Processing, *diagnostic.Error)
