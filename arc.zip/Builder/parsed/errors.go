package parsed

import "smoothlingua/diagnostic"

const (
  // CodeRead — невозможно полностью прочитать или закрыть технический JSON.
  CodeRead = "parsed.read"

  // CodeUTF8 — входные байты не являются корректным UTF-8.
  CodeUTF8 = "parsed.utf8"

  // CodeJSON — нарушен синтаксис единственного JSON-документа.
  CodeJSON = "parsed.json"

  // CodeVersion — formatVersion не равен поддерживаемому model.FormatVersion1.
  CodeVersion = "parsed.version"

  // CodeContract — отсутствует поле, неверен тип/null или инвариант Contract.
  CodeContract = "parsed.contract"

  // CodeMissingID — обязательный ID урока отсутствует либо равен null.
  CodeMissingID = "parsed.missing_id"

  // CodeParser — обнаружен хотя бы один блокирующий признак ошибки парсера.
  CodeParser = "parsed.parser"

  // CodeParent — нарушена целостность или глубина связи parentLine.
  CodeParent = "parsed.parent"

  // CodeParentCycle — обнаружен цикл parentLine.
  CodeParentCycle = "parsed.parent_cycle"
)

// inputError создаёт существующий diagnostic.Error с русской Reason,
// известным Context и исходной Cause. Field в Details обозначает JSON-поле;
// координаты синтаксиса JSON указываются отдельно в Details и не выдаются
// за физические строки DSL. Недоступные координаты не выдумываются.
// Ошибки identity и order сохраняют свой Code и дополняются контекстом.
func inputError(code string, reason string, field string, context diagnostic.Context, cause error) *diagnostic.Error
