package parsed

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// validateLine проверяет LineType и LineEnding по перечислениям model,
// nestingLevel>=0 и пустой EOL только у последней физической строки.
// Raw не содержит CR/LF, сохраняется без преобразований и удаления пробелов.
// Проверку элементов делегирует validateElement/validateElementOrder,
// родителя — validateParent; классификацию raw как DSL заново не выполняет.
func validateLine(line model.Line, last bool, context diagnostic.Context) []*diagnostic.Error

// validateElement проверяет ElementType по model, 1<=start<=end<=число
// Unicode-кодовых точек line.Raw+1 и точное совпадение raw с этим диапазоном.
// Пустой диапазон допустим. Значение не сверяется повторным разбором raw.
func validateElement(element model.Element, line model.Line, context diagnostic.Context) []*diagnostic.Error

// validateElementOrder проверяет порядок start, затем end, отсутствие
// пересечений диапазонов и дублей элементов. Пробелы и весь raw покрывать
// не требуется; порядок не исправляется сортировкой.
func validateElementOrder(elements []model.Element, context diagnostic.Context) *diagnostic.Error

// validateElementValue проверяет только явно заданный словарь Contract:
// tag — 34 канонических имени Contract; heading-level — 1, 2 или 3 с
// соответствующим raw; media-type — audio/video/image; number через
// order.Validate. Block-open/block-close имеют соответствующий одиночный
// символ в raw/value. Null у placeholder без ответа допустим и не является
// ошибкой; у unparsed value=null. Для ошибочных значений сохраняются
// предусмотренные Contract null и errorIds, их блокирует parserErrors.
// У остальных корректных элементов value — строка, в том числе пустая,
// когда это разрешено Contract; null не подменяется пустой строкой.
// Остальные текстовые значения не ограничиваются синтаксисом DSL.
// Source — любая переданная подстрока или путь по ТЗ, а не только номер.
// Version сохраняется как прочитана; placeholder/multifill не разбираются.
func validateElementValue(element model.Element, context diagnostic.Context) *diagnostic.Error

// validateBoundaryElements проверяет только форму Contract: block-start
// содержит block-open, block-end содержит block-close, invalid содержит
// unparsed. Грамматику тегов, параметры и допустимость вложений не проверяет.
func validateBoundaryElements(line model.Line, context diagnostic.Context) *diagnostic.Error
