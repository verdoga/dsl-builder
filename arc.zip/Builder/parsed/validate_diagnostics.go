package parsed

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// indexDiagnostics проверяет непустые уникальные id и возвращает индекс
// diagnostic.id -> позиция в исходном массиве, не меняя его порядок.
func indexDiagnostics(diagnostics []model.Diagnostic, context diagnostic.Context) (map[string]int, []*diagnostic.Error)

// validateDiagnostic проверяет severity/scope по model, fatal только у error,
// существование source в processing. Code и tool не закрываются словарём.
// Location для element обязателен, для line при наличии лежит в одной строке;
// block допускает несколько строк. RelatedLocations не повторяют основную
// location и друг друга. Диапазоны делегируются validateLocation.
func validateDiagnostic(item model.Diagnostic, processing map[string]int, context diagnostic.Context) []*diagnostic.Error

// validateLocation проверяет положительные строки/колонки и неубывание
// концов диапазона по строке, затем колонке. Конец исключающий, пустой
// диапазон допустим. Нового типа позиции или координат не вводится.
func validateLocation(location model.Location, context diagnostic.Context) *diagnostic.Error

// validateDiagnosticOrder проверяет порядок известных source в processing,
// затем доступных начальных строк и колонок; равные координаты сохраняют
// входной порядок обнаружения. Для location=null новый порядок не навязывается.
func validateDiagnosticOrder(items []model.Diagnostic, processing map[string]int, context diagnostic.Context) *diagnostic.Error

// validateErrorReferences проверяет errorIds без повторов, существование
// диагностик scope=element и порядок ссылок по массиву diagnostics.
// Для каждой element-диагностики требует хотя бы одну обратную ссылку
// из элемента с точно совпадающим основным диапазоном.
// Для других scope ссылка из errorIds запрещена; предупреждения не выводятся.
func validateErrorReferences(result *model.Result, diagnostics map[string]int, context diagnostic.Context) []*diagnostic.Error

// validateErrorFlags проверяет document.hasErrors как наличие severity=error
// и line.hasErrors как error с основной location на этой строке либо ссылку
// элемента на error; дочерние ошибки не наследуются. Это проверка Contract,
// не замена независимой предварительной блокировки в parserErrors.
func validateErrorFlags(result *model.Result, context diagnostic.Context) []*diagnostic.Error
