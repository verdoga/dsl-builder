package parsed

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// LineIndex хранит только рабочие адреса строк; сами model.Line не копирует.
// Индексы среза начинаются с 0, физические номера — с 1.
// Карты и срезы читаются без изменения вместе с Input.Result.
type LineIndex struct {
  // ByNumber связывает номер физической строки с индексом в Result.Lines.
  ByNumber map[int]int

  // Children связывает номер родителя с номерами непосредственных потомков
  // в исходном порядке. Ключ 0 обозначает строки с parentLine=null.
  // Отсутствующий ключ означает отсутствие детей; фиктивной строки 0 нет.
  Children map[int][]int
}

// indexNumbers проверяет положительность, уникальность и исходный порядок
// физических номеров, строит ByNumber без перезаписи дублей.
// При известном lineCount дополнительно требует номера 1..lineCount
// и равенство длине lines; при null не выдумывает полный размер исходника.
func indexNumbers(lines []model.Line, lineCount *int, context diagnostic.Context) (map[int]int, []*diagnostic.Error)

// validateParent проверяет одну ссылку: родитель существует и предшествует
// строке, его nestingLevel на 1 меньше. Корень имеет nestingLevel=0.
// heading имеет parentLine=null и глубину 0; родитель block-end — block-start.
// Не трактует nestingLevel как единственный источник семантики task/step.
func validateParent(line model.Line, lines []model.Line, byNumber map[int]int, context diagnostic.Context) *diagnostic.Error

// validateParentCycles проверяет конечность всех цепочек parentLine,
// включая компоненты без корня. Вызывается после проверки существования
// ссылок; возвращает участников цикла в Related без лимита глубины.
// Ошибки порядка родителя не исключают диагностику обнаруженного цикла.
func validateParentCycles(lines []model.Line, byNumber map[int]int, context diagnostic.Context) []*diagnostic.Error

// indexChildren строит только непосредственные связи после успешной проверки
// родителей и циклов; сохраняет порядок исходного массива, включая blank
// и границы блоков. Семантические контейнеры и развёртывание фрагментов не строит.
func indexChildren(lines []model.Line) map[int][]int
