package revision

import (
  "encoding/json"
  "math/big"
  "time"
  "smoothlingua/lesson"
)

// nextRevision прибавляет ровно 1 к математическому целому значению
// проверенного old.Version и возвращает каноническое JSON-число цифрами.
// Например, 5.0 и 5e0 дают 6. Точность и диапазон не ограничиваются
// float64, машинным int или uint64; применяется math/big.
func nextRevision(old json.Number) json.Number

// integerValue получает точное целое из уже проверенного lesson.Validate
// json.Number, включая допустимую дробную и экспоненциальную запись.
// Это служебное представление для арифметики ревизий, не новый валидатор
// схемы. Экспонента также не ограничивается машинным диапазоном.
func integerValue(value json.Number) *big.Int

// stampInitial устанавливает Version=1 и CreatedAt через versionTime.
// LineCount остаётся точным значением кандидата из технического JSON;
// количество страниц, нод, переводов строк и строк сериализации не считает.
func stampInitial(result *lesson.Document, at time.Time)

// stampUpdate устанавливает уже вычисленную revision, CreatedAt через
// versionTime и точное candidateLineCount. Вызывается один раз только
// при changed=true, даже для одного подтверждённого названия страницы.
func stampUpdate(result *lesson.Document, revision json.Number, candidateLineCount json.Number, at time.Time)

// versionTime форматирует at в UTC как YYYY-MM-DDTHH:MM:SSZ без долей секунды.
// Не читает системные часы, не использует дату исходного файла или парсера.
// Допустимость четырёхзначного года проверит итоговая lesson.Validate;
// при отсутствии изменений at не используется и не порождает ошибку даты.
func versionTime(at time.Time) string
