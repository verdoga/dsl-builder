package revision

import "smoothlingua/lesson"

// cloneLesson создаёт независимый снимок через clonePages и копирование
// указателя Subtitle. Скаляры сохраняются точно, включая json.Number.
// nil входа обрабатывается вызывающим API до копирования.
func cloneLesson(value *lesson.Lesson) *lesson.Lesson

// clonePages копирует страницы, указатели Title и деревья через cloneNodes.
// Пустые ненулевые массивы остаются ненулевыми; nil также сохраняется.
func clonePages(values []lesson.Page) []lesson.Page

// cloneNodes копирует каждый уровень дерева, все указатели Flags и Data
// через cloneData. Не нормализует текст, роли, флаги и порядок массивов.
func cloneNodes(values []lesson.Node) []lesson.Node

// cloneData копирует Answers, Role и вложенные []lesson.Data в Value.
// string и EmbeddedFile не содержат изменяемых ссылок и копируются по значению.
// Неизвестный вариант Value остаётся для диагностики lesson.Validate;
// до её успеха исходный Value не изменяется и результат не публикуется.
// Base64 не декодируется, не перекодируется и сохраняется точно.
func cloneData(values []lesson.Data) []lesson.Data
