package revision

import (
  "math/big"
  "smoothlingua/compare"
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
)

// applyContent координирует replaceLessonPages либо applyPageChanges.
// result первоначально является независимой копией old. revision — новая
// положительная глобальная ревизия десятичными цифрами без padding.
// Выбор ветви уже задан планом; нет сравнений содержимого или порогов.
func applyContent(result *lesson.Lesson, old *lesson.Lesson, candidate *lesson.Lesson, plan *compare.Plan, revision string, context diagnostic.Context) []*diagnostic.Error

// replaceLessonPages копирует все страницы кандидата и вызывает assignPageIDs
// и assignNodeIDs с максимумов прежнего урока плюс 1. Старые названия урока
// и подзаголовок остаются в result; отдельно их меняет applyFields.
// Все страницы и все ноды получают новые ID, включая точные совпадения.
// Порядок страниц/нод кандидата сохраняется, пары старых и новых ID не строятся.
func replaceLessonPages(result *lesson.Lesson, old *lesson.Lesson, candidate *lesson.Lesson, revision string, context diagnostic.Context) []*diagnostic.Error

// applyPageChanges обрабатывает изменения страниц по индексу плана.
// Единственный nextNode для всех ReplaceNodes начинается с максимума
// базовых номеров ВСЕХ нод old плюс 1, включая удаляемые и вложенные ноды.
// Точечные замены не расходуют этот счётчик; номера не уплотняются.
// Вызывает replacePageNodes либо replaceNodeOwn для каждого изменения.
// ID всех страниц сохраняются; страницы вне плана остаются копиями old.
func applyPageChanges(result *lesson.Lesson, old *lesson.Lesson, candidate *lesson.Lesson, changes []compare.PageChange, revision string, context diagnostic.Context) []*diagnostic.Error

// replacePageNodes копирует Nodes одной страницы кандидата, затем назначает
// всем нодам новые номера из общего nextNode и суффикс revision.
// ID и название страницы не меняет. Пустой лес не расходует счётчик.
// Названия позднее применяются через отдельные решения applyFields.
func replacePageNodes(result *lesson.Page, candidate lesson.Page, lessonID string, nextNode *big.Int, revision string, context diagnostic.Context) []*diagnostic.Error

// replaceNodeOwn заменяет собственные Type, Flags и Data по адресу Path
// из кандидата, сохраняя дерево детей результата. Остальные собственные
// поля эквивалентны по неизменному плану; повторное сравнение не выполняется.
// Базовый номер берётся через identity.ParseNodeID старой ноды, новый ID —
// через identity.FormatNodeID с новой глобальной revision. Прежний суффикс
// заменяется, а не дописывается. Ноды без NodeChange сохраняют полный ID;
// изменение ребёнка само по себе не затрагивает собственные поля родителя.
func replaceNodeOwn(result *lesson.Page, old lesson.Page, candidate lesson.Page, change compare.NodeChange, lessonID string, revision string, context diagnostic.Context) *diagnostic.Error

// nodeAt возвращает ноду по проверенной непустой цепочке индексов Path.
// Не использует ID для соответствия, не ограничивает глубину дерева.
func nodeAt(nodes []lesson.Node, path []int) *lesson.Node
