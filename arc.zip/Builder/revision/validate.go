package revision

import (
  "smoothlingua/compare"
  "smoothlingua/diagnostic"
  "smoothlingua/identity"
  "smoothlingua/lesson"
)

// validateUpdateInputs координирует lesson.Validate обоих снимков,
// проверку равенства identity.LessonKey их ID и ValidateHistory для old.
// Кандидат прошёл Initial; его служебные ID и ревизия не переносятся.
// Несовпадение ключей даёт CodeLessonMismatch. Ошибки старого снимка
// предшествуют ошибкам кандидата; неисправный вход не порождает каскад
// арифметических ошибок и не допускает применения даже пустого плана.
func validateUpdateInputs(old *lesson.Lesson, candidate *lesson.Lesson, oldContext diagnostic.Context, candidateContext diagnostic.Context) []*diagnostic.Error

// validatePlan проверяет непустой указатель plan, validateDecisions,
// validateFieldAddresses и validatePageChanges. Это проверки исполнимости
// неизменённого результата compare.Build; сравнение содержимого и полноту
// найденных отличий повторно не выполняет. Ошибки дают CodePlan.
// ReplaceLesson требует пустой Pages и непустой Reasons; иначе Reasons
// пуст. При отсутствии полной замены число страниц снимков одинаково.
func validatePlan(old *lesson.Lesson, candidate *lesson.Lesson, plan *compare.Plan, decisions []Decision, context diagnostic.Context) []*diagnostic.Error

// validateFieldAddresses проверяет известный Field, допустимые индексы,
// отсутствие повторных адресов и корректную форму значений FieldChange.
// Поля документа имеют OldPage=NewPage=-1; у DocumentTitle оба значения
// не nil. PageTitle имеет существующий NewPage; OldPage либо существует,
// либо равен -1 только при полной замене и тогда Before=nil.
// При частичной замене OldPage=NewPage. Устанавливать безопасную пару
// повторно или подбирать Before по позиции функция не вправе.
// Связь Before/After с неизменными снимками гарантирует compare.Build.
func validateFieldAddresses(old *lesson.Lesson, candidate *lesson.Lesson, plan *compare.Plan, context diagnostic.Context) []*diagnostic.Error

// validatePageChanges проверяет существование и возрастающий порядок
// уникальных индексов страниц. ReplaceNodes требует Nodes пуст и Reasons
// непуст; точечная замена — наоборот. Пути проверяет validateNodeChanges.
// Не определяет причины структурных изменений вместо compare.
func validatePageChanges(old *lesson.Lesson, candidate *lesson.Lesson, changes []compare.PageChange, context diagnostic.Context) []*diagnostic.Error

// validateNodeChanges проверяет непустые уникальные Path, существование
// каждой цепочки индексов в обоих деревьях и порядок родитель → дети.
// Fields непуст, содержит только известные compare.NodeField без повторов.
// Родитель и его ребёнок могут оба изменяться; это не конфликт путей.
// Не сравнивает Type/Flags/Data и не выводит изменения из значений ID.
func validateNodeChanges(old []lesson.Node, candidate []lesson.Node, changes []compare.NodeChange, context diagnostic.Context) []*diagnostic.Error

// ValidateHistory проверяет только наблюдаемые инварианты одной версии:
// уникальность базовых номеров нод во всём уроке, отсутствие суффиксов
// в ревизии 1, отсутствие суффикса больше Document.Version.
// Предусловие: lesson.Validate успешно проверил модель и полные ID.
// Ноды без суффикса допустимы и в поздних ревизиях; суффикс меньше текущей
// ревизии допустим. Не требует сплошной нумерации или одинаковых суффиксов,
// не восстанавливает отсутствующую историю прежних версий.
// Предназначена также для module при проверке загруженного урока, если
// её вызовет app: зависимость module от revision для этого не требуется.
// Использует validateHistoryNode в порядке страниц и полного дерева.
func ValidateHistory(value *lesson.Lesson, context diagnostic.Context) []*diagnostic.Error

// validateHistoryNode разбирает ID через identity.ParseNodeID, передаёт
// части validateNodeRevision и регистрирует Number в seen с JSON Pointer.
// Повтор Number с иным суффиксом даёт CodeHistory с обоими адресами;
// потомки проверяются отдельно с тем же индексом всего урока.
func validateHistoryNode(value lesson.Node, document *lesson.Document, seen map[string]string, pointer string, context diagnostic.Context) []*diagnostic.Error

// validateNodeRevision сравнивает parts.Revision с математическим значением
// document.Version через integerValue, без машинного ограничения чисел.
// Ошибки содержат ID и адрес ноды; содержимое ноды не выводится.
func validateNodeRevision(parts identity.NodeIDParts, document *lesson.Document, pointer string, context diagnostic.Context) *diagnostic.Error
