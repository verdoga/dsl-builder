package revision

import (
  "math/big"
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
)

// assignInitialIDs координирует assignPageIDs и assignNodeIDs с независимыми
// счётчиками с 1. Ноды всех страниц используют один nextNode и пустую revision.
// Prefix и минимальные ширины чисел определяет только identity.
func assignInitialIDs(result *lesson.Lesson, context diagnostic.Context) []*diagnostic.Error

// assignPageIDs присваивает ID страницам в порядке массива через
// identity.FormatPageID, увеличивая nextPage после каждой страницы.
// Счётчик — math/big.Int, ограничения 999, int и uint64 не вводятся.
func assignPageIDs(pages []lesson.Page, lessonID string, nextPage *big.Int, context diagnostic.Context) []*diagnostic.Error

// assignNodeIDs выдаёт базовые номера в порядке родитель → дети через
// identity.FormatNodeID и увеличивает общий nextNode. Применяется на всех
// уровнях Nodes; пустая revision даёт ID без суффикса, непустая — -vNN.
// Числа после 999 и версии после 99 не обрезаются. Содержимое не меняет.
func assignNodeIDs(nodes []lesson.Node, lessonID string, nextNode *big.Int, revision string, context diagnostic.Context) []*diagnostic.Error

// maxPageNumber разбирает ID всех страниц через identity.ParsePageID
// и возвращает наибольший номер как big.Int; пустой массив даёт 0.
// Перед вызовом lesson.Validate уже проверил ID и принадлежность уроку.
func maxPageNumber(pages []lesson.Page) *big.Int

// maxNodeNumber обходит все страницы и все уровни Nodes, используя
// maxNodeNumberInTree; возвращает максимум базовых номеров либо 0.
// Суффиксы не входят в номер. Максимум берётся из снимка до обновления.
func maxNodeNumber(pages []lesson.Page) *big.Int

// maxNodeNumberInTree разбирает ID через identity.ParseNodeID и обновляет
// переданный максимум по всей ветви. Пропуски номеров не заполняет.
func maxNodeNumberInTree(nodes []lesson.Node, maximum *big.Int)
