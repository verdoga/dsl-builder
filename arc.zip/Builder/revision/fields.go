package revision

import (
  "smoothlingua/compare"
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
)

// Decision — явное решение по одному compare.FieldChange; нулевое значение
// не означает отказ и позволяет обнаружить незавершённый сбор решений.
type Decision string

const (
  // Accept — применить предложенное After.
  Accept Decision = "accept"
  // Reject — оставить Before либо null при неизвестном прежнем page.title.
  Reject Decision = "reject"
)

// hasAcceptedChanges использует plan.HasContentChanges и решения Fields.
// Возвращает true для любого принятого поля или содержательной замены.
// У несопоставленного PageTitle даже After=nil не доказывает равенство
// прежнему полю; такая запись возможна только при ReplaceLesson=true.
// Версия, дата, LineCount и различия регистра ID не создают изменение.
func hasAcceptedChanges(plan *compare.Plan, decisions []Decision) bool

// applyFields вызывает applyField в порядке plan.Fields, не выбирая пары
// страниц заново. При полной замене документ исходно сохраняет старые
// Title/Subtitle, а страницы берутся из кандидата; у безопасной пары без
// записи FieldChange название кандидата уже равно старому по compare.
// При частичном обновлении исходные названия взяты из копии old.
func applyFields(result *lesson.Lesson, fields []compare.FieldChange, decisions []Decision)

// applyField копирует выбранное значение в указанное поле результата.
// Accept выбирает After; Reject выбирает Before, включая известное null.
// Для PageTitle и OldPage=-1 Reject устанавливает title=null в NewPage:
// это отказ от нового названия, не восстановление неизвестного старого.
// Старое название по NewPage, сходству названий или первичному ID не ищется.
// OldPage служит только контракту поля; даже безопасная пара при полной
// замене не разрешает перенос ID. При DocumentTitle значение не nil.
func applyField(result *lesson.Lesson, change compare.FieldChange, decision Decision)

// validateDecisions требует точную длину Fields и только Accept/Reject.
// Отсутствующее, пустое и неизвестное решение дают CodeDecision; решения
// по названиям не выводятся из согласия на замену урока или запись архива.
func validateDecisions(fields []compare.FieldChange, decisions []Decision, context diagnostic.Context) []*diagnostic.Error
