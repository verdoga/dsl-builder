package moduleio

import (
  "encoding/json"
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/manifest"
)

// checkJSONEncoding проверяет UTF-8 точных байтов и отсутствие начального BOM.
// Разрешение снять BOM относится к техническому JSON, а не к готовому модулю.
// Неверные байты не заменяются символом замены; raw остаётся неизменным.
func checkJSONEncoding(raw []byte, context diagnostic.Context) *diagnostic.Error

// decodeJSONValue читает ровно одно JSON-значение стандартным Decoder с
// UseNumber и требует EOF после допустимых пробелов; второе значение и мусор
// дают CodeJSON. Предусловие — успешная checkJSONEncoding.
// Возвращает стандартное дерево с json.Number, без float64 и ограничения
// чисел машинным int; при ошибке значение nil. Проверок схем здесь нет.
func decodeJSONValue(raw json.RawMessage, context diagnostic.Context) (any, *diagnostic.Error)

// decodeLesson вызывает checkJSONEncoding и lesson.ValidateJSON, затем
// encoding/json декодирует те же raw в lesson.Lesson через её UnmarshalJSON.
// Требуется ровно одно полное JSON-значение, без хвостового мусора.
// Типизированные Data и числа восстанавливаются существующей моделью lesson;
// неизвестные допустимые свойства остаются в raw для побайтового переноса.
// При любой ошибке возвращает nil; к диагностике добавляет известный контекст,
// сохраняя коды и причины владельца схемы. Значения модели не исправляет.
func decodeLesson(raw json.RawMessage, context diagnostic.Context) (*lesson.Lesson, []*diagnostic.Error)

// decodeManifest вызывает checkJSONEncoding, decodeJSONValue и фактический
// manifest.ValidateShape до декодирования encoding/json в manifest.Manifest.
// ValidateJSON в принятом API manifest отсутствует; проверки формы не дублируются.
// ValidateShape сохраняет различие пропущенных полей, null и пустых массивов
// и отклоняет посторонние имена, включая отличающееся написание регистра.
// json.Number сохраняет точные числа; семантический manifest.Validate далее
// вызывает module.Validate. При любой ошибке результат nil.
func decodeManifest(raw json.RawMessage, context diagnostic.Context) (*manifest.Manifest, []*diagnostic.Error)
