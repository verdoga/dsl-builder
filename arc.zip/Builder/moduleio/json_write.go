package moduleio

import (
  "smoothlingua/diagnostic"
  "smoothlingua/manifest"
  "smoothlingua/module"
)

// lessonBytes возвращает File.OriginalBytes дословно при ненулевом результате.
// Не меняет пробелы, порядок ключей, неизвестные допустимые свойства и перевод
// строки в конце; не выполняет повторную сериализацию неизменённого урока.
// Для File, созданного NewFile/ReplaceFile с nil OriginalBytes, сериализует
// File.Lesson стандартным encoding/json.MarshalIndent с двумя пробелами,
// без BOM; ошибка сериализации даёт CodeSerialize и nil байты.
// Предусловие — успешный module.Validate; доверие к связи raw и модели
// обеспечивается неизменяемым module.File, повторной проверки связи здесь нет.
func lessonBytes(value *module.File) ([]byte, *diagnostic.Error)

// manifestBytes сериализует готовый манифест через encoding/json.MarshalIndent
// с двумя пробелами, UTF-8 без BOM; сохраняет числа, строки и порядок массивов.
// Не использует время системы, не нормализует веса и названия.
// Предусловие — успешный module.Validate. Ошибка даёт nil байты и CodeSerialize
// с именем module.ManifestFileName; собственная JSON-модель не вводится.
func manifestBytes(value manifest.Manifest, context diagnostic.Context) ([]byte, *diagnostic.Error)
