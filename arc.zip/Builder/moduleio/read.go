package moduleio

import (
  "archive/zip"
  "smoothlingua/diagnostic"
  "smoothlingua/manifest"
  "smoothlingua/module"
)

// Read загружает существующий ZIP по подготовленному пути path только для чтения.
// Координирует zip.OpenReader, readArchive и закрытие zip.ReadCloser.
// Ошибка открытия либо структуры ZIP даёт CodeOpen либо CodeArchive;
// ненулевая ошибка открытия запрещает использовать даже ненулевой reader.
// Созданный reader закрывается при любом результате; ошибка закрытия добавляется
// после основных ошибок и также запрещает возвращать модель.
// При успехе файлы содержат независимые снимки и точные несжатые байты JSON.
// При любой ошибке результат nil, частично прочитанного модуля нет.
// Path в диагностике — path; имена записей передаются отдельно в FileName.
func Read(path string) (*module.Module, []*diagnostic.Error)

// readArchive координирует validateEntries, readContents и module.Validate.
// Следующий этап запускается только после успеха предыдущего; любая ошибка
// даёт nil. Схемы, веса, ID и связи не проверяются повторными местными правилами.
// Все записи успешного архива полностью прочитаны с контролем CRC до возврата.
// Reader принадлежит Read и здесь не закрывается.
func readArchive(reader *zip.Reader, context diagnostic.Context) (*module.Module, []*diagnostic.Error)

// readContents читает все записи проверенного состава через readManifestEntry
// и readLessonEntry. Files сохраняет порядок записей ZIP, не порядок манифеста.
// Не схлопывает файлы по ID или имени и не сортирует содержимое манифеста.
// Собирает независимые ошибки в порядке записей; при любой ошибке возвращает
// nil. Успешный результат ещё требует module.Validate в readArchive.
func readContents(entries []*zip.File, context diagnostic.Context) (*module.Module, []*diagnostic.Error)

// readLessonEntry связывает readEntry, decodeLesson и module.LoadedFile.
// Передаёт LoadedFile ровно те raw, из которых декодирован проверенный урок;
// имя берёт из записи, Context дополняет этим именем и прочитанным ID.
// Не вызывает NewFile вместо LoadedFile: исходные байты должны сохраниться.
// При любой ошибке возвращает nil, не прикрепляет частичные байты.
func readLessonEntry(entry *zip.File, context diagnostic.Context) (*module.File, []*diagnostic.Error)

// readManifestEntry связывает readEntry и decodeManifest для manifest.json.
// Контекст содержит имя module.ManifestFileName. При ошибке возвращает nil;
// исходные байты манифеста сохранять для последующей записи не требуется.
func readManifestEntry(entry *zip.File, context diagnostic.Context) (*manifest.Manifest, []*diagnostic.Error)
