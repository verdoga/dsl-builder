package console

import "smoothlingua/app"

// editLessonWeight выбирает один файл, читает обязательную строку веса
// и вызывает ProposeLessonWeight(snapshot.Token, fileName, raw), затем
// reviewEdit. Подходит и для отсутствующего веса. Не использует int/float64,
// не снимает ведущие нули, не проверяет положительность вместо владельца.
func (d *dialog) editLessonWeight(snapshot app.Snapshot) error

// editGroupWeights выбирает группу через chooseGroup, собирает полный набор
// collectLessonWeights и лишь затем вызывает ProposeLessonWeights с исходным
// snapshot.Token. Никаких отдельных ProposeLessonWeight во время сбора нет.
// Ошибка итоговой проверки показывает диагностику и позволяет новый ввод
// всей группы через меню; отказ от набора не меняет принятые веса.
func (d *dialog) editGroupWeights(snapshot app.Snapshot) error

// collectLessonWeights последовательно спрашивает строковый вес каждой
// записи выбранной группы в порядке Catalog.Items. Ключи — Entry.FileName,
// без чужих файлов. readValue перед каждым значением предоставляет отдельную
// числовую отмену всей группы, включая уже набранные ответы. Возвращает карту
// только при полном вводе; при отмене/EOF/ошибке карта nil, app не вызывается.
func (d *dialog) collectLessonWeights(snapshot app.Snapshot, section *string) (weights map[string]string, accepted bool, err error)

// editSectionWeights работает с независимым Snapshot операции: локальный
// срез sections берёт из snapshot.Catalog.Sections без объявления нового типа.
// Для каждой секции читает raw через readValue, сохраняет отдельный *string
// в sections[i].Weight. После полного набора вызывает
// Operation.ProposeSectionWeights(snapshot.Token, sections) и reviewEdit.
// Отмена любого вопроса отбрасывает весь локальный набор. Прямой импорт catalog
// не нужен; проверки полноты, положительности, равных весов и сортировка — app.
func (d *dialog) editSectionWeights(snapshot app.Snapshot) error
