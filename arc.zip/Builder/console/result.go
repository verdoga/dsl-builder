package console

import (
  "smoothlingua/app"
  "smoothlingua/diagnostic"
)

// showWriteResult читает snapshot.WriteResult, без собственной модели результата.
// Полный успех сообщает только при Installed=true и отсутствии всех issues,
// печатая полный TargetPath. Installed=true с issues означает установленный
// результат с ошибками завершения, а не «успешно сохранён» или «не изменён».
// При ошибках всегда показывает все известные TargetPath, OriginalPath и
// TemporaryPath с отдельными подписями, не гарантируя существование после
// внешних изменений. Все issues выводятся showIssues, включая ошибки очистки.
// Nil WriteResult не выдаётся за файловый результат и не вызывает повтор Save.
func (d *dialog) showWriteResult(snapshot app.Snapshot, issues []*diagnostic.Error) error

// noChangesChoice сообщает об отсутствии содержательных изменений и записи,
// затем вызывает terminalChoice. Предусловия: актуальный показанный Snapshot,
// NoChanges=true, отсутствие Blockers и завершённые отдельные решения.
// Для Mode=app.Update дополнительно требуется RevisionReady=true после
// PrepareRevision и нового Snapshot. При RevisionReady=false вызов запрещён,
// даже если NoChanges=true, поля отсутствуют либо все предложения отклонены.
// Решения без подготовки ревизии не подтверждают отсутствие правок нод.
// ReviewSave/Save не вызываются; неверные предусловия не дают терминального
// сообщения и оставляют продолжение через обычное меню operationLoop.
func (d *dialog) noChangesChoice(snapshot app.Snapshot) (route, error)

// terminalChoice предлагает «1. Вернуться в главное меню», «2. Выход»
// согласно Actions.MainMenu/Exit. Перед уходом вызывает Cancel: установленный
// результат не откатывается. Новый анализ recovery-файлов сам не запускается.
func (d *dialog) terminalChoice(snapshot app.Snapshot) (route, error)

// presentationFailureChoice после успешно показанной ошибки представления
// предоставляет только Retry, Restart/MainMenu и Exit по Actions. Повторный
// показ сам по себе не даёт согласия; запись неполного превью недоступна.
func (d *dialog) presentationFailureChoice(snapshot app.Snapshot) (route, error)
