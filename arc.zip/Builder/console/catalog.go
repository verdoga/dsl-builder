package console

import (
  "smoothlingua/app"
  "smoothlingua/diagnostic"
)

// editCourse читает обязательное название и вызывает ProposeCourseTitle
// с snapshot.Token; кандидат передаётся reviewEdit. Отмена не вызывает app.
func (d *dialog) editCourse(snapshot app.Snapshot) error

// editUnit явно поясняет «Enter — убрать юнит» и вызывает ProposeUnitTitle
// только после завершённого ввода; применение решает отдельный reviewEdit.
func (d *dialog) editUnit(snapshot app.Snapshot) error

// createSection читает непустое исходное имя и вызывает ProposeSection.
// Нормализованное имя и изменения показывает только из полученного EditPreview.
func (d *dialog) createSection(snapshot app.Snapshot) error

// moveLesson выбирает файл через chooseLesson и назначение через chooseSection,
// затем вызывает ProposeMove(snapshot.Token, fileName, section). Все уроки,
// включая старые/новые и нераспределённые, доступны для индивидуального переноса.
// nil section — явный пункт «Без секции», а не отмена. Отмена второго вопроса
// отбрасывает первый выбор; подтверждение переноса выполняет reviewEdit.
func (d *dialog) moveLesson(snapshot app.Snapshot) error

// useFlatPlacement предлагает ProposeFlatPlacement(snapshot.Token) только
// после явного выбора пункта завершения размещения без секций. Уроки
// автоматически не переносит; кандидата подтверждает reviewEdit.
func (d *dialog) useFlatPlacement(snapshot app.Snapshot) error

// reviewEdit показывает все issues. nil edit означает отказ app создать
// кандидата и возврат к прежнему превью; не трактует это как частичный успех.
// При ненулевом edit показывает showEdit и спрашивает отдельное 1/2.
// Да вызывает AcceptEdit(edit.Token), Нет — RejectEdit(edit.Token).
// Исправляемые Blockers не скрывают возможность принять рабочий кандидат.
// Ошибка показа приводит к RejectEdit; ошибки показа и отклонения объединяет.
// При EOF/ошибке потока отменяет Operation целиком; до принятия группа
// остаётся локальной. Принятие не считается согласием на запись архива.
func (d *dialog) reviewEdit(snapshot app.Snapshot, edit *app.EditPreview, issues []*diagnostic.Error) error
