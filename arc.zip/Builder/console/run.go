package console

import (
  "bufio"
  "io"
  "smoothlingua/app"
)

// dialog хранит только потоки и текущую операцию для гарантированной отмены.
type dialog struct {
  // input — единый буфер строк на весь запуск, без ограничения Scanner в 64 КБ.
  input *bufio.Reader
  // output — меню, вопросы, превью и последовательная диагностика операции.
  output io.Writer
  // baseDir — явный полный базовый каталог из main; не читается из окружения.
  baseDir string
  // operation — текущий app.Operation; nil до полного ввода начальных данных.
  operation *app.Operation
}

// Run проверяет ненулевые потоки, непустые baseDir и buildVersion, затем
// передаёт управление showWelcome и mainLoop. Не проверяет файловую систему.
// Версия берётся только из buildVersion; отсутствующую не заменяет v1.0.0.
// arguments никогда не становятся параметрами операции или настройками.
// При любом завершении вызывает Cancel текущей операции. EOF до Enter
// отменяет даже частично прочитанную строку и завершает Run без новой записи.
// Остальные ошибки потока возвращает main, не повторяя ошибочный вывод.
// Предметные ошибки после успешного показа остаются в диалоге продолжения.
// Не закрывает переданные потоки, не вызывает os.Exit и не меняет их режимы.
func Run(input io.Reader, output io.Writer, baseDir string, buildVersion string, arguments []string) error

// showWelcome выводит DSL-Builder и переданную версию; при аргументах пишет
// «Работа выполняется через интерактивное меню; аргументы не используются».
func (d *dialog) showWelcome(buildVersion string, arguments []string) error

// mainLoop обслуживает только главное меню и запуск выбранного режима.
// После возврата и перед выходом отменяет незаписанное через app.Cancel.
func (d *dialog) mainLoop() error

// mainChoice показывает четыре отдельных пункта: создать, обновить, добавить,
// выход. Возвращает номер 1–4; неверный ввод повторяет именно это меню.
func (d *dialog) mainChoice() (int, error)

// runMode соединяет ввод одного сценария, Analyze(time.Now()) и operationLoop.
// routeRestart означает отмену прежней Operation и полный новый ввод того же
// режима; ошибки конструктора показываются и дают повтор ввода/главное меню/выход.
// Сбой анализа не отменяет редактируемый каталог: действия определяет Snapshot.
func (d *dialog) runMode(mode app.Mode) (route, error)

// route — только направление возврата диалога, не стадия предметной операции.
type route int

const (
  // routePreview — снова показать актуальный снимок текущей операции.
  routePreview route = iota
  // routeRestart — начать тот же режим с новым вводом и новой Operation.
  routeRestart
  // routeMain — отменить незаписанное и перейти в главное меню.
  routeMain
  // routeExit — отменить незаписанное и завершить Run.
  routeExit
)
