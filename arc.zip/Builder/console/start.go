package console

import "smoothlingua/app"

// startCreate локально собирает каталог технических JSON, обязательный курс
// и необязательный юнит. Только полный ввод вызывает app.NewCreate с baseDir.
// Пути передаются буквально, включая внешнюю пару кавычек, для app.inputPath.
// Отмена любого вопроса отбрасывает все ответы и возвращает nil без ошибки.
func (d *dialog) startCreate() (*app.Operation, error)

// startUpdate локально собирает путь ZIP и ровно одного технического JSON,
// затем вызывает app.NewUpdate. Содержимое и вид путей проверяет только app.
// Отмена любого вопроса не создаёт Operation; ошибки конструктора показывает
// через showIssues, после чего возвращает nil для startFailureChoice.
func (d *dialog) startUpdate() (*app.Operation, error)

// startAdd локально собирает путь ZIP и путь JSON либо каталога, передаёт
// полную группу app.NewAdd. Контракт отмены и ошибок тот же, что startUpdate.
// startCreate также показывает ошибки конструктора без частичного запуска.
func (d *dialog) startAdd() (*app.Operation, error)

// startFailureChoice после отменённого/неуспешного первичного ввода предлагает
// новый ввод того же режима, главное меню и выход; Retry без Operation нет.
func (d *dialog) startFailureChoice() (route, error)

// analyze вызывает только Operation.Analyze(time.Now()), показывает все
// возвращённые ошибки и оставляет выбор продолжения Snapshot.Actions.
// Не печатает вымышленные промежуточные счётчики успешных этапов.
func (d *dialog) analyze() error

// retry при Actions.Retry вызывает Operation.Retry(time.Now()) и показывает
// ошибки; следующий экран полностью заменяет старые снимки и нумерацию.
// После recovery-файлов/Installed доступность не восстанавливает самостоятельно.
func (d *dialog) retry() error
