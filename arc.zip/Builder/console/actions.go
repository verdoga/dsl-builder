package console

import "smoothlingua/app"

// action — адрес одного пункта текущего меню; не замена app.Actions.
type action string

const (
  // actionCourse — предложить изменение курса при EditCatalog.
  actionCourse action = "course"
  // actionUnit — предложить изменение или удаление юнита при EditCatalog.
  actionUnit action = "unit"
  // actionLessonWeight — задать вес одного урока при EditCatalog.
  actionLessonWeight action = "lesson_weight"
  // actionGroupWeights — задать весь набор весов группы при EditCatalog.
  actionGroupWeights action = "group_weights"
  // actionSectionWeights — задать веса всех секций при SortSections.
  actionSectionWeights action = "section_weights"
  // actionNewSection — создать секцию при EditSections.
  actionNewSection action = "new_section"
  // actionMove — перенести выбранный урок при EditSections.
  actionMove action = "move"
  // actionFlat — завершить плоское размещение при EditSections и всех Section=nil.
  actionFlat action = "flat"
  // actionField — решить одно ожидающее поле при DecideFields.
  actionField action = "field"
  // actionPlacement — решить одно предложение размещения при DecidePlacement.
  actionPlacement action = "placement"
  // actionRevision — подготовить итоговые ID при PrepareRevision.
  actionRevision action = "revision"
  // actionDestination — выбрать или изменить цель при ChooseDestination.
  actionDestination action = "destination"
  // actionSave — полный показ и согласие при ReviewSave; прямого обхода нет.
  actionSave action = "save"
  // actionUnused — просмотреть список при UnusedResources.
  actionUnused action = "unused"
  // actionRetry — повторно анализировать при Retry.
  actionRetry action = "retry"
  // actionRestart — начать тот же режим заново, когда доступен MainMenu.
  actionRestart action = "restart"
  // actionMain — главное меню при MainMenu; Cancel вызывается перед уходом.
  actionMain action = "main"
  // actionExit — выход при Exit; Cancel вызывается перед уходом.
  actionExit action = "exit"
)

// availableActions получает разрешения только из snapshot.Actions; отсутствие
// блокировок само по себе не разрешает запись. Пункты над пустыми списками
// скрывает: веса/перенос требуют Items, веса секций — Sections. actionFlat
// требует Sectioned=true и все Items.Section=nil, согласно ProposeFlatPlacement.
// Ожидающие section/order скрывают ручные правки: app.checkCatalogEdit требует
// их решений первыми. Не выводит недоступные действия как отключённые пункты.
// Save не становится самостоятельным меню: это продолжение confirmSaving
// непосредственно после ConfirmSave. app.Actions.Cancel покрывается actionMain.
func availableActions(snapshot app.Snapshot) []action

// actionLabel задаёт русскую подпись пункта без номера; номер назначает choose.
// actionRevision подписан «Перейти к итоговому просмотру изменений».
func actionLabel(value action) string

// operationLoop получает свежий Snapshot, показывает его и меню, выполняет
// один выбранный пункт через dispatchAction. noChangesChoice допустим только
// при NoChanges без Blockers, после всех решений; для Mode=app.Update
// дополнительно обязательно RevisionReady=true. До этого NoChanges не
// разрешает объявлять отсутствие изменений или завершать операцию как пустую.
// При Actions.PrepareRevision меню содержит actionRevision: выбранный пункт
// вызывает prepareRevision. Автоматической подготовки и повторов после ошибки
// нет. После вызова и показа его ошибок цикл обязательно получает новый
// Operation.Snapshot и показывает его до новой оценки NoChanges/Blockers.
// При RevisionReady=false сохраняет обычное меню новых Actions; следующая
// попытка подготовки возможна только новым выбором разрешённого actionRevision.
// После Installed показывает результат и terminalChoice.
// Ошибка представления запрещает пункт записи и даёт retry/main/exit, если
// они разрешены app, через presentationFailureChoice. Ошибки showSnapshot
// и dispatchAction разделяет isStreamFailure: поток прекращает цикл целиком,
// а проблему представления сначала показывает PrintError в исправный поток.
func (d *dialog) operationLoop() (route, error)

// operationChoice связывает нумерацию только с переданным списком actions;
// повтор неверного номера не меняет список. Не хранит номера между снимками.
func (d *dialog) operationChoice(actions []action) (action, error)

// dispatchAction только направляет один пункт в отдельный диалог. Снимок
// и его Token относятся к показанному меню; повторный выбор требует нового.
// actionRevision при snapshot.Actions.PrepareRevision вызывает prepareRevision
// ровно один раз и возвращает routePreview; ошибка потока прекращает диалог.
// Навигация не вычисляет предметную доступность и не выполняет запись сама.
func (d *dialog) dispatchAction(snapshot app.Snapshot, selected action) (route, error)
