package console

import (
  "io"
  "smoothlingua/diagnostic"
)

const (
  // CodeConfiguration — отсутствует обязательная база, версия или поток.
  CodeConfiguration = "console.configuration"
  // CodeInput — потеря входного потока кроме штатного EOF.
  CodeInput = "console.input"
  // CodeOutput — ошибка вывода либо неполная запись в переданный поток.
  CodeOutput = "console.output"
  // CodePreview — переданный подготовленный снимок невозможно полностью показать.
  CodePreview = "console.preview"
)

// PrintError — общий публичный вывод ошибки, в том числе ошибки main до Run
// (получение базового каталога/версии). main передаёт stderr и обычный error,
// не импортируя diagnostic. nil ошибки ничего не печатает. Не завершает процесс.
// Для обычной причины добавляет русское «Не удалось выполнить действие».
// При сбое самого вывода возвращает errors.Join исходной и ошибки потока,
// обёрнутой streamError(CodeOutput, cause), без рекурсивной попытки напечатать
// её туда же. При nil output возвращает CodeConfiguration без паники.
func PrintError(output io.Writer, err error) error

// showIssues выводит все ненулевые diagnostic.Error по порядку через PrintError.
// Успешный показ возвращает nil: предметные блокировки остаются в app.
// При сбое вывода возвращает errors.Join всех исходных issues и сбоя;
// непоказанные причины не теряются. Typed nil не добавляет в объединение.
func (d *dialog) showIssues(issues []*diagnostic.Error) error

// writeErrorTree представляет текущую ошибку и каждую дочернюю причину.
// Проверяет именно текущий узел как *diagnostic.Error, отдельно обходит
// Unwrap() []error и Unwrap() error: один errors.As для всего Join запрещён,
// поскольку он скрыл бы вторую ветвь. Родительскую Reason не заменяет Cause.
// Каждый узел сохраняет свой контекст; общий текст Join не дублируется вместо
// дочерних структур. Предупреждения парсера не читает: parsed уже отобрал ошибки.
func writeErrorTree(output io.Writer, err error) error

// writeDiagnostic выводит Code, русскую Reason, Context, все Related с
// нумерацией участников и все Details в исходном порядке, включая повторные
// Label и пустые Value. Cause обходит writeErrorTree отдельно без потери ветвей.
func writeDiagnostic(output io.Writer, issue *diagnostic.Error) error

// writeContext выводит все известные Path, FileName, LessonID, PageID,
// Line и Column с отдельными русскими подписями. Не подставляет неизвестное,
// document.filePath и не обрезает длинные пути/ID; значения экранирует для вывода.
func writeContext(output io.Writer, context diagnostic.Context) error

// writeDetails выводит каждую пару Label/Value без анализа её предметного
// смысла, числового преобразования, сокращения или добавления рекомендаций.
func writeDetails(output io.Writer, details []diagnostic.Detail) error

// joinedIssues сохраняет исходные ненулевые *diagnostic.Error через errors.Join.
// Это перевод среза в стандартное дерево причин, не новая модель ошибок.
func joinedIssues(issues []*diagnostic.Error) error

// streamError создаёт diagnostic.Error с кодом ввода/вывода, русской Reason
// и исходной Cause. Не выдумывает файловый путь для стандартного потока.
func streamError(code string, cause error) *diagnostic.Error

// presentationError оборачивает ошибку preview в diagnostic.Error CodePreview
// с русской причиной и сохранённой Cause; несколько причин остаются errors.Join.
// Ошибку потока этой функцией не подменяют.
func presentationError(cause error) *diagnostic.Error

// isStreamFailure проверяет каждую ветвь error на console.input/console.output
// и непосредственный io.EOF от readLine. Не ограничивается первым errors.As
// внутри Join. True запрещает продолжение диалога и любое следующее действие;
// ошибки представления без сбоя потока допускают меню безопасного возврата.
func isStreamFailure(err error) bool
