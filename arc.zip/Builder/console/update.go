package console

import "smoothlingua/app"

// decideField выбирает первый ещё не отвеченный индекс Plan.Fields по
// FieldAnswered. Печатает preview.FieldProposal(snapshot.Before,
// snapshot.Plan.Fields[index]), включая OldPage=-1 и After=nil без исключений.
// После отдельного «Применить это изменение? 1. Да / 2. Нет» передаёт ответ
// Operation.DecideField(snapshot.Token, index, accept). Одного ответа на все
// поля нет. Следующее поле спрашивается только из нового Snapshot и меню.
// Отмена всей операции доступна между полями через главное меню/выход.
func (d *dialog) decideField(snapshot app.Snapshot) error

// decidePlacement выбирает первый неотвеченный индекс PlacementAnswered,
// печатает preview.ManifestChanges с единственным элементом среза
// snapshot.PlacementProposals[index:index+1] и получает отдельное 1/2.
// Передаёт Operation.DecidePlacement(snapshot.Token, index, accept).
// Решение по section не подтверждает order; ручные правки ждут всех решений.
func (d *dialog) decidePlacement(snapshot app.Snapshot) error

// prepareRevision по выбору actionRevision вызывает
// Operation.PrepareRevision(snapshot.Token) ровно один раз, только при
// snapshot.Actions.PrepareRevision. Token принадлежит актуальному показанному
// снимку. Все возвращённые ошибки показывает через showIssues; предметная
// ошибка после успешного показа возвращает управление operationLoop, а сбой
// потока прекращает диалог. Ни успех, ни ошибка не запускают повтор сами.
// Следующий шаг operationLoop — новый Operation.Snapshot и его показ;
// прежние NoChanges, Blockers и RevisionReady повторно не оцениваются.
// Только новый RevisionReady=true допускает итоговые ID и проверку условий
// noChangesChoice. При false доступны дальнейшие действия из нового Actions,
// включая явную повторную подготовку, если она разрешена. Значения готовности
// и отсутствия изменений принадлежат app; console их не вычисляет и не меняет.
func (d *dialog) prepareRevision(snapshot app.Snapshot) error
