package console

import "smoothlingua/app"

// chooseLesson перечисляет snapshot.Catalog.Items в текущем порядке:
// техническое имя, ID и название, без содержимого урока. Возвращает точный
// Entry.FileName, а не отображаемый номер. Последний числовой пункт отменяет
// текущий ввод; accepted=false отделён от любого допустимого имени.
func (d *dialog) chooseLesson(snapshot app.Snapshot) (fileName string, accepted bool, err error)

// chooseSection показывает все точные имена Catalog.Sections и отдельный
// пункт «Без секции», затем отмену. Пустая рабочая секция также доступна.
// Возвращает копию выбранного Title либо nil при явном выборе без секции;
// accepted=false означает отмену. Новое имя вводится отдельным createSection.
func (d *dialog) chooseSection(snapshot app.Snapshot) (section *string, accepted bool, err error)

// chooseGroup предлагает только существующие непустые группы Catalog.Items,
// следуя Catalog.Sections, затем группу с Section=nil, если такие записи есть.
// При Sectioned=true последняя подписана «Не распределены», иначе «Без секций».
// Нормализации и сортировки предметных значений нет. Отмена отдельным пунктом.
func (d *dialog) chooseGroup(snapshot app.Snapshot) (section *string, accepted bool, err error)
