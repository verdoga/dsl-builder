package console

import (
  "smoothlingua/app"
  "smoothlingua/preview"
)

// showSnapshot — небольшой координатор showComposition, showUpdate,
// showManifest и showIssues(snapshot.Blockers). Отсутствующий Catalog/Module
// после провала анализа не передаёт обязательным параметрам preview; вместо
// обещания готового превью показывает диагностику и доступные действия.
// Для ресурсов вызывает preview.Resources(snapshot.Resources), только когда
// Actions.UnusedResources сообщает о доступности отчёта текущего анализа.
// Ошибки разных блоков сохраняет вместе, не выдавая неполный вывод за полный.
// Ошибки preview возвращает через presentationError, ошибки потока сохраняет
// отдельно и прекращает вывод сразу. Не печатает Node.Data и Base64.
func (d *dialog) showSnapshot(snapshot app.Snapshot) error

// showComposition вызывает preview.Composition(snapshot.Catalog,
// snapshot.Module, snapshot.NewFileNames), затем отдельно всегда показывает
// preview.OrderConflicts(snapshot.Conflicts), даже если Composition ошибся.
// До ManifestReady не использует Module.Manifest как готовый результат.
func (d *dialog) showComposition(snapshot app.Snapshot) error

// showUpdate только при Mode=app.Update и RevisionReady вызывает
// preview.UpdateHeading(ArchivePath, Before, After),
// preview.AcceptedFields(Before, After, AcceptedFields) и
// preview.Replacements(Before, After, Plan), сохраняя каждый результат/ошибку.
// До RevisionReady сообщает, что итоговые версии и ID ещё не подготовлены,
// и не подменяет After первичным кандидатом или вычисленными console ID.
func (d *dialog) showUpdate(snapshot app.Snapshot) error

// showManifest передаёт snapshot.ManifestChanges в preview.ManifestChanges.
// Изменения курса/юнита/секций/записей не вычисляет и не фильтрует заново.
func (d *dialog) showManifest(snapshot app.Snapshot) error

// showUnused печатает preview.UnusedResources(snapshot.Resources) и отдельный
// пункт «1. Вернуться к предварительному просмотру». Возврат не изменяет app.
func (d *dialog) showUnused(snapshot app.Snapshot) error

// showEdit показывает preview.Composition(edit.Catalog, snapshot.Module,
// snapshot.NewFileNames), preview.ManifestChanges(edit.Changes) и все
// edit.Blockers. Здесь состав нужен, в частности, для временного порядка
// секций и новой пустой секции, не входящих в экспортированный манифест.
// Ошибка формирования любого блока запрещает подтверждение этого кандидата.
func (d *dialog) showEdit(snapshot app.Snapshot, edit *app.EditPreview) error
