package console

import "smoothlingua/app"

// chooseDestination при Actions.ChooseDestination читает отдельно обязательный
// каталог и обязательное имя ZIP. Отмена второго вопроса отбрасывает оба ответа.
// Только полный ввод вызывает Operation.SetDestination(snapshot.Token,
// destinationDirectory(directory), name). Проверки каталога, имени Windows,
// расширения и существования выполняет app. После успеха обязателен новый
// Snapshot; прежний Token и прежнее согласие далее не используются.
func (d *dialog) chooseDestination(snapshot app.Snapshot) error

// reviewSaving при Actions.ReviewSave вызывает Operation.ReviewSave с Token
// показанного снимка. Ошибки показывает; nil SavePreview не допускает вопроса
// о согласии. Ненулевой результат передаёт showSavePreview и confirmSaving.
// Ошибка представления закрывает предложение ConfirmSave(token,false,false),
// сохраняя обе причины через errors.Join; ошибка потока отменяет Operation.
func (d *dialog) reviewSaving(snapshot app.Snapshot) (route, error)

// showSavePreview показывает полный showSnapshot(value.Snapshot), затем
// точные Destination.Path и Exists. ManifestTimeWillChange сопровождает
// сообщением о будущей смене даты манифеста. Путь и весь план показаны до
// первого вопроса согласия; ошибки любого блока запрещают подтверждение.
func (d *dialog) showSavePreview(value *app.SavePreview) error

// confirmSaving спрашивает «Записать показанный модуль? 1. Да / 2. Нет».
// Для согласия и Destination.Exists=true отдельно показывает полный путь
// и спрашивает «Перезаписать существующий файл? 1. Да / 2. Нет».
// Все ответы остаются локальными до завершения обоих вопросов. Только затем
// вызывает ConfirmSave(value.Token, accept, replaceExisting). Отказ в любом
// вопросе передаёт accept=false, replaceExisting=false, возвращает превью.
// EOF/ошибка вывода отменяет Operation без ConfirmSave с согласием и без Save.
// После успеха запрашивает Snapshot: только Actions.Save разрешает writeOnce.
// Смена цели/плана между ответом и записью не обходится новыми токенами.
func (d *dialog) confirmSaving(value *app.SavePreview) (route, error)

// writeOnce вызывает только Operation.Save(time.Now()) один раз после
// confirmSaving. Файловые callbacks и транзакция остаются внутри app.
// Результат и ошибки сохраняет app; console использует новый Snapshot и
// showWriteResult. При Installed либо recovery-файлах предлагает только
// terminalChoice. Иначе возвращается в обычное меню доступных Actions:
// новая попытка возможна лишь через новый ReviewSave и новые ответы.
// Не повторяет Save автоматически и не удаляет/перемещает оставшиеся файлы.
func (d *dialog) writeOnce() (route, error)
