package structure

import (
  "smoothlingua/diagnostic"
  "smoothlingua/fragments"
)

// walkSequence обходит одну последовательность в заданном порядке, вызывая
// visitEntry для очередной ещё не потреблённой конструкции. Индекс следующей
// записи возвращает visitEntry; повторно обходить тело потреблённого блока нельзя.
// boundary равен nil у документа либо Entry include у вставки.
// Конец документа завершает все оставшиеся семантические области; конец
// последовательности include обрабатывает walkInclude, не закрывая внешний task.
func walkSequence(state *builder, entries []*fragments.Entry, boundary *fragments.Entry) []*diagnostic.Error

// visitEntry — только диспетчер: skipEditor, walkInclude, pageBoundary/openPage,
// trimContexts, обработчики контейнеров и appendContent. blank вне тела ноды,
// заголовки 1/2 и метатеги dsl-version/document-id/section/order/resource-dir
// не создают нод; endtask и speaking передаются своим обработчикам.
// block-end завершает соответствующий контейнер, но не создаёт ноды.
// fragment после Expand означает нарушение предусловия и CodeSource.
// Значимый непредставимый вход не пропускается молча: возвращается ошибка.
func visitEntry(state *builder, entries []*fragments.Entry, at int, boundary *fragments.Entry) (next int, errors []*diagnostic.Error)

// blockEntries выбирает конструкцию до её собственного block-end включительно,
// сопоставляя закрывающую строку через Entry.Parent с конкретным объявлением.
// У однострочной конструкции возвращает одну запись. Сохраняет внутренние
// границы и пустые строки; raw не анализирует и текстовые данные не собирает.
// Незамкнутый/пересечённый блок даёт CodeBoundary с исходными координатами.
func blockEntries(entries []*fragments.Entry, at int, state *builder) (body []*fragments.Entry, next int, errors []*diagnostic.Error)

// skipEditor пропускает однострочный editor либо полное тело его блока,
// найденное blockEntries. Содержимое комментария не интерпретируется как теги.
func skipEditor(state *builder, entries []*fragments.Entry, at int) (next int, errors []*diagnostic.Error)

// walkInclude вызывает walkSequence для site.Included в точке вставки.
// Сохраняет действующие внешний task/step/variant и не создаёт ноды include.
// Соседство question/answer/hint снаружи и внутри разделено этой границей.
// После вставки закрывает только ещё активные области, открытые внутри неё;
// внешние области, уже завершённые реальной границей, не возобновляет.
// Исходные номера не перенумеровываются; разные *Entry не объединяются.
func walkInclude(state *builder, site *fragments.Entry) []*diagnostic.Error

// closeBlock завершает область конкретного блока, указанного Entry.Parent,
// и все её внутренние области через closeFrom. Закрытие внутреннего variants
// закрывает только его variant и её потомков; внешние variants/variant/task/step
// остаются активны. Сопоставление по типу или номеру другого include запрещено.
// Блоки собственных данных уже потреблены blockEntries и сюда не поступают.
func closeBlock(state *builder, end *fragments.Entry) []*diagnostic.Error
