package structure

import (
  "smoothlingua/diagnostic"
  "smoothlingua/fragments"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// contentType сопоставляет семантический tag.Value с lesson.NodeType:
// header→heading, instr→instruction, key→answerKey, wordlist→wordList,
// choice→singleChoice, multichoice→multipleChoice; text/note/alt/script/hint/
// example/table/media/question/multifill/matching/ordering — одноимённые типы.
// Самостоятельная содержательная строка content соответствует NodeText.
// Теги контейнеров и служебные теги обрабатывает visitEntry, а не эта функция.
// Непредставимая форма даёт CodeSource; raw не используется как новое DSL.
func contentType(line model.Line, state *builder) (lesson.NodeType, *diagnostic.Error)

// appendContent — координатор blockEntries, questionTail, splitInstruction
// и appendNode для одной отображаемой конструкции. Блочное содержимое text,
// table, multifill и остальных листовых нод не создаёт дочерних текстовых нод.
// Каждая самостоятельная непустая строка content вне блоков даёт одну text.
// script всегда отдельная нода на своём месте, даже сразу после media.
// hint, не вошедший в собственные данные инструкции/упражнения или questionTail,
// создаёт отдельную ноду; совпадения текста не вызывают удаления или слияния.
// Родителя определяет receivingPath для исходного entry после trimContexts.
// Для пары выделенная instruction/упражнение использует один полученный путь
// без смены контекста между ними; обе ноды принадлежат ближайшей области.
func appendContent(state *builder, entries []*fragments.Entry, at int) (next int, errors []*diagnostic.Error)

// appendNode добавляет одну lesson.Node указанного типа к parentPath либо
// в корень страницы и одновременно регистрирует Binding с новым путём.
// Инициализирует пустые ID, ненулевые Data/Nodes и пустые Flags; собственных
// данных не формирует. Возвращает индекс привязки для стека контейнеров.
// Инструкция и интерактивная нода добавляются разными вызовами с одним parentPath.
func appendNode(state *builder, parentPath []int, kind lesson.NodeType, entries []*fragments.Entry) int

// questionTail выбирает лишь структурно связанные внешние конструкции question:
// следующий значимый answer на том же уровне и следующий за ним один hint.
// Использует nextSignificant и blockEntries; возвращает исходные вхождения,
// не извлекает ответы/подсказки, не проверяет их количество или содержимое.
// Не пересекает страницы, task/step/variant, block-end и границы include.
// При отсутствии answer ничего не поглощает: следующий hint самостоятельный.
// Ответы/подсказки внутри других интерактивных блоков сохраняются в их Entries
// целиком; размещение по элементам данных принадлежит exercisedata.
func questionTail(state *builder, entries []*fragments.Entry, question int, next int) (tail []*fragments.Entry, after int, errors []*diagnostic.Error)

// nextSignificant ищет следующую конструкцию только в данной последовательности,
// пропуская blank и полные editor. Границы вставок и блоков не пропускает.
// Возвращает len(entries), когда конструкций больше нет; ничего не изменяет.
func nextSignificant(state *builder, entries []*fragments.Entry, at int) (next int, errors []*diagnostic.Error)
