package structure

import (
  "smoothlingua/diagnostic"
  "smoothlingua/fragments"
)

// pageBoundary распознаёт только heading с heading-level.Value="3" и newpage.
// Название первой формы берёт из title.Value без нормализации, у второй nil.
// Отсутствующее/неоднозначное необходимое значение даёт CodeSource, а не
// подстановку document.title. header здесь не считается границей страницы.
func pageBoundary(entry *fragments.Entry, state *builder) (boundary bool, title *string, errors []*diagnostic.Error)

// openPage завершает все активные task/step/variant и открывает страницу.
// Перед первым heading 3 начальную страницу создаёт только ранее размещённый
// материал. Для первого newpage сохраняет начальную страницу и открывает
// следующую: newpage — граница, завершающая предшествующую страницу.
// Последующие явные границы всегда сохраняются; пустые явно созданные страницы
// не склеиваются и не запрещаются повторным применением старой DSL-валидации.
// Title равен переданному названию либо nil; ID пуст, Nodes — ненулевой срез,
// допускающий ноль элементов. Само событие не становится нодой.
func openPage(state *builder, entry *fragments.Entry, title *string)

// ensurePage создаёт начальную страницу с Title=nil только при отсутствии
// текущей страницы. Вызывается перед первой отображаемой нодой.
func ensurePage(state *builder)

// finishPages обеспечивает одну страницу с Title=nil, если границ и материала
// не было вообще; уже сформированные страницы и их названия не меняет.
// Ни название документа, ни заголовки 1/2 не используются вместо page.title.
func finishPages(state *builder)
