package structure

import (
  "smoothlingua/diagnostic"
  "smoothlingua/fragments"
  "smoothlingua/parsed"
)

const (
  // CodeSource — исходная конструкция не позволяет однозначно выбрать структуру.
  CodeSource = "structure.source"

  // CodeBoundary — отсутствует либо противоречива необходимая граница блока.
  CodeBoundary = "structure.boundary"

  // CodeContext — step/variant/speaking/endtask не имеет нужного контейнера
  // в своей области, у ближайшего variants нет собственной активной ветви
  // либо служебный answer не принадлежит потреблённой конструкции данных.
  CodeContext = "structure.context"
)

// sourceContext заполняет путь технического JSON из Input.Path, исходный ID
// из метаданных и физическую строку Entry.Source.Number; column известна
// из элемента либо равна 0. PageID не выдумывается до назначения ID.
func sourceContext(input *parsed.Input, entry *fragments.Entry, column int) diagnostic.Context

// structureError создаёт diagnostic.Error с кодом пакета и русской причиной.
// Context содержит место исходной проблемы, Related — известные объявления,
// границы и всю цепочку мест include для конкретного повторного вхождения.
// Диагностики идут в порядке развёрнутого входа; предупреждения и рекомендации
// парсера не копируются. Ошибка блокирует весь Build, наружу ничего не печатается.
func structureError(code string, reason string, entry *fragments.Entry, related []*fragments.Entry, state *builder) *diagnostic.Error
