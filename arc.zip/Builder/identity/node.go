package identity

import "smoothlingua/diagnostic"

// NodeIDParts — разобранные части ID ноды; нужны для сохранения базового
// номера при замене и чтения суффикса без зависимости от модели урока.
type NodeIDParts struct {
  // Prefix — проверенный ID урока в нижнем регистре.
  Prefix string

  // Number — положительный базовый номер ASCII-цифрами без ведущих нулей.
  Number string

  // Revision — положительная ревизия ASCII-цифрами без ведущих нулей;
  // пустая строка означает отсутствие суффикса, а не ревизию ноль.
  Revision string
}

// ParseNodeID проверяет полную каноническую форму prefix-nNNN
// либо prefix-nNNN-vNN. Prefix соответствует ValidateLessonID
// и равен своему LessonKey; ограничений DSL для Prefix нет.
// Формы a:b-n001 и lesson+1-n001 допустимы.
// Номер положителен, ширина минимум 3; суффикс при наличии положителен,
// ширина минимум 2; лишние нули
// сверх минимальной ширины запрещены. n001-v06 и n1000-v100 допустимы.
// Терминальные -n с номером и необязательным -v с ревизией выделяются
// справа; такие же фрагменты внутри Prefix не создают неоднозначности.
// Ревизия суффикса не сверяется с document.version и историей изменений:
// это обязанность вызывающего пакета, синтаксически v01 допустим.
// Ошибка имеет CodeInvalidNodeID; разобранные числа не содержат padding.
func ParseNodeID(value string) (NodeIDParts, *diagnostic.Error)

// FormatNodeID проверяет lessonID через ValidateLessonID,
// положительный number и revision.
// Возвращает LessonKey(lessonID) с -n и номером минимальной ширины 3.
// Например, A:B, 1 и пустая revision дают a:b-n001.
// Пустая revision означает отсутствие суффикса; иначе добавляется -v
// с положительной ревизией минимальной ширины 2, без ограничения длины.
// Для замены суффикса вызывающий код передаёт Prefix и Number из ParseNodeID
// и выбранную им новую глобальную ревизию; прежний суффикс не переносится.
// Решение об отсутствии суффикса в первой ревизии принимает вызывающий код.
// Ошибки: CodeInvalidLessonID либо CodeInvalidNumber; Details указывает,
// какое значение неверно: базовый номер или ревизия.
func FormatNodeID(lessonID string, number string, revision string) (string, *diagnostic.Error)
