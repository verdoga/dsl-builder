package identity

import "smoothlingua/diagnostic"

// ParseFileName проверяет техническое имя урока по Manifest.schema:
// строчная ASCII l, положительный номер минимальной ширины 3 и .json.
// Допустимы l001.json, l999.json, l1000.json; запрещены l000.json,
// l01.json, l0001.json, иной регистр, разделители путей и лишние символы.
// Возвращает номер ASCII-цифрами без ведущих нулей, любой длины.
// manifest.json не является техническим именем урока.
// Ошибка имеет CodeInvalidFileName, числовой результат тогда пуст.
func ParseFileName(value string) (string, *diagnostic.Error)

// FormatFileName проверяет положительный number и выдаёт техническое имя
// со строчной l, номером минимальной ширины 3 и расширением .json.
// Ведущие нули входного числа заменяются каноническим padding;
// номер не выбирается и не увеличивается. Ошибка имеет CodeInvalidNumber.
func FormatFileName(number string) (string, *diagnostic.Error)
