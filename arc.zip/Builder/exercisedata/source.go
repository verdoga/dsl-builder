package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// checkSource проверяет непустую проекцию и соответствие первого тега kind:
// question — однострочный; choice/multichoice/matching/ordering — блочные.
// Полный входной контракт, номера и отсутствие циклов уже проверены parsed.
// Проверяет завершённость локального блока через blockEnd; не достраивает
// отсутствующие строки, не принимает посторонний хвост после его закрытия.
func checkSource(kind lesson.NodeType, lines []model.Line, context diagnostic.Context) *diagnostic.Error

// blockEnd находит закрывающую строку переданного block-start по типу строки
// и ParentLine; возвращает её индекс в lines. Вложенные блоки не закрывают
// внешний. Отсутствующая граница — CodeSource, искусственного лимита нет.
func blockEnd(lines []model.Line, at int, context diagnostic.Context) (int, *diagnostic.Error)

// tagValue возвращает каноническое ElementTypeTag.Value либо пустую строку
// при отсутствии тега. Nil у найденного тега — CodeSource, не пустой тег.
func tagValue(line model.Line, context diagnostic.Context) (string, *diagnostic.Error)

// contentValue извлекает единственный ElementTypeContent.Value и его место;
// необязательное отсутствие даёт found=false, а nil и неоднозначность — ошибку.
// Непустой текст не обрезается. Значение "---" само по себе не разделитель.
func contentValue(line model.Line, context diagnostic.Context) (value string, found bool, source diagnostic.Context, err *diagnostic.Error)

// nextSignificant возвращает индекс следующей значимой строки либо len(lines).
// Пропускает blank; allowEditor дополнительно разрешает пропуск уже выделенного
// editor вместе с его блоком. Он true только при соседстве question/answer/hint
// на внешнем уровне; в упражнениях и телах answer/hint editor не разрешён.
// Границы блоков и любые другие теги не пропускаются; исходный порядок сохранён.
func nextSignificant(lines []model.Line, at int, allowEditor bool, context diagnostic.Context) (int, *diagnostic.Error)

// contentRows извлекает непустые content-значения тела answer или hint;
// возвращает значения и их контексты в одинаковом порядке и количестве.
// Только blank и пустые строки content отбрасываются. Иные вложенные теги
// дают CodeSource; отображаемая разметка сохраняется. Value не разбирается.
// Все содержательные строки должны иметь ParentLine объявления этого тела;
// start — первая строка после объявления, end — индекс его block-end.
func contentRows(lines []model.Line, start int, end int, context diagnostic.Context) ([]string, []diagnostic.Context, *diagnostic.Error)

// isSeparator распознаёт LineTypeSeparator только среди прямых строк списков.
// Для golden 6/7 допускает прежний LineTypeContent с единственным content:
// Value="---", Raw элемента="---", Raw строки после удаления только краевых
// U+0020/TAB равен "---". Экранированный Raw="\\---" остаётся текстом.
// Не ищет разделители внутри answer/hint и не делит текст по подстрокам.
func isSeparator(line model.Line) bool
