package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// questionData координирует contentValue, questionAnswer и textData.
// Создаёт единственный DataText/RoleBody с формулировкой вопроса.
// Отсутствующая, nil или пустая обязательная формулировка — CodeSource.
// Нет связанного answer — Answers пуст, Hint пуст, checkable=false.
// Корректный answer — все его альтернативы и связанный hint у body,
// checkable=true. Отдельные ноды answer и hint не создаются.
func questionData(lines []model.Line, context diagnostic.Context) ([]lesson.Data, bool, *diagnostic.Error)

// questionAnswer читает необязательный единственный answer после question
// через nextSignificant/readAnswer. Он должен иметь тот же ParentLine;
// семантическую принадлежность внешнему контейнеру гарантирует проекция.
// После связанного hint допустим только игнорируемый хвост проекции.
// Второй answer, лишний hint или постороннее содержимое — CodeBinding,
// а не альтернативный способ связывания или молчаливое отбрасывание.
func questionAnswer(lines []model.Line, context diagnostic.Context) (*answerGroup, *diagnostic.Error)
