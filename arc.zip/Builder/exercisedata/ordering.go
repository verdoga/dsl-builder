package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// orderingData координирует splitLists, listItems, listLabels, requireCount,
// answerCoverage и проверку выбранного формата. Минимум два item; при явном
// разделителе — минимум две position. Возвращает items и только при явных
// позициях positions; синтетических positions для сокращённой формы нет.
// Ответы и hint относятся к item; порядок элементов и подписей сохранён,
// перестановку для показа выполняет плеер. Инструкцию обработает вызывающий слой.
// Без ответов checkable=false; частичная настройка ошибочна. При полной
// конфигурации расширенной формы вызывает checkLabelReferences, сокращённой —
// checkNumberedPositions. True выдаётся только после соответствующей проверки.
func orderingData(lines []model.Line, context diagnostic.Context) ([]lesson.Data, bool, *diagnostic.Error)

// checkNumberedPositions координирует numberedChoices и requirePermutation.
// Не извлекает числа из подписей item и не выводит ответы из исходного порядка.
// Повторяющиеся тексты item сохраняет разными экземплярами с собственными
// наборами допустимых позиций; взаимозаменяемость при оценке — задача плеера.
func checkNumberedPositions(items []entry, context diagnostic.Context) *diagnostic.Error

// numberedChoices проверяет каждый ответ через positionIndex и возвращает
// допустимые индексы позиций для каждого исходного экземпляра item.
// Повтор одной допустимой позиции внутри ответа не меняет множество
// допустимости; исходный массив Answers остаётся без удаления повторов.
func numberedChoices(items []entry, context diagnostic.Context) ([][]int, *diagnostic.Error)

// positionIndex требует ASCII-запись положительного целого без знака,
// ведущих нулей и дробной части, в диапазоне 1..count; возвращает индекс с 0.
// Произвольно длинное значение сначала сравнивается с count как десятичная
// строка, без переполнения int/float64. В int переводится лишь заведомо
// допустимый индекс реально существующего среза. Answers не переписывается.
func positionIndex(value string, count int, source diagnostic.Context) (int, *diagnostic.Error)

// requirePermutation проверяет существование хотя бы одной полной перестановки
// исходных экземпляров по их допустимым позициям: одна позиция на каждый item
// и один item на позицию. Делегирует шаг назначения assignPosition; жадный
// выбор первого ответа недостаточен. Невозможность — CodeContradiction.
// Существующую перестановку не записывает в данные и не меняет их порядок.
func requirePermutation(choices [][]int, items []entry, context diagnostic.Context) *diagnostic.Error

// assignPosition решает только шаг поиска увеличивающего пути для одного item
// в двудольном соответствии экземпляров и позиций; owner хранит текущего
// владельца позиции либо -1, visited — позиции текущего поиска. Обновляет
// только временное соответствие. Нет искусственного предела числа элементов.
func assignPosition(item int, choices [][]int, owner []int, visited []bool) bool
