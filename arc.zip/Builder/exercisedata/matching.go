package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// matchingData координирует localInstruction, splitLists, listItems,
// listLabels, requireCount, answerCoverage и checkLabelReferences.
// Минимум: один item и два option. Результат: необязательная instruction,
// ровно одна items, затем ровно одна options; их листья строго текстовые.
// Ответы/подсказки принадлежат конкретным item, нижние options ответов не имеют.
// Полное отсутствие ответов даёт checkable=false; полная корректная привязка
// даёт true; частичная, отсутствующая или неоднозначная ссылка — ошибка.
func matchingData(lines []model.Line, context diagnostic.Context) ([]lesson.Data, bool, *diagnostic.Error)
