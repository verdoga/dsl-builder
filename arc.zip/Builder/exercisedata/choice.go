package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// choiceData координирует localInstruction, choiceOptions, requireCount
// с минимумом 2, checkChoiceAnswers и collectionData. Возвращает инструкцию
// при наличии, затем ровно одну options. Порядок исходных вариантов сохранён.
// singleChoice отличается ограничением одной группы и одного правильного
// варианта; multipleChoice сохраняет все группы и экземпляры без объединения.
func choiceData(kind lesson.NodeType, lines []model.Line, context diagnostic.Context) ([]lesson.Data, bool, *diagnostic.Error)

// choiceOptions читает прямые строки содержимого через contentValue,
// создавая обычные option с пустыми Answers/Hint; answer передаёт readAnswer
// и correctOptions. Возвращает также места всех исходных групп answer.
// Blank и пустые content-строки пропускаются, непустые значения сохраняются.
// Вложенные строки answer/hint не становятся дополнительными вариантами.
// Неизвестный тег, несвязанный hint, separator или неверный родитель —
// CodeBinding/CodeSource; границы полного блока определены checkSource.
func choiceOptions(lines []model.Line, context diagnostic.Context) ([]entry, []diagnostic.Context, *diagnostic.Error)

// correctOptions превращает каждое значение одной группы в отдельный option:
// Value — собственный текст, Answers содержит только этот же текст,
// Hint — общая подсказка группы, скопированная каждому варианту.
// Места группы и отдельных значений сохраняются; экземпляры не объединяются.
func correctOptions(group answerGroup) []entry

// checkChoiceAnswers при отсутствии групп возвращает false. Для singleChoice
// требует ровно одну группу с одним правильным вариантом; для multipleChoice
// разрешает любое положительное количество групп и правильных экземпляров.
// Затем вызывает checkChoiceLabels; только успех даёт true.
func checkChoiceAnswers(kind lesson.NodeType, options []entry, groups []diagnostic.Context, context diagnostic.Context) (bool, *diagnostic.Error)

// checkChoiceLabels при включённой проверке запрещает точно одинаковые
// подписи вариантов с разными признаками правильности. Регистр, пробелы
// и пунктуация значимы; одинаковые подписи с одинаковой правильностью
// сохраняются отдельными экземплярами. Ошибка указывает оба места.
func checkChoiceLabels(options []entry, context diagnostic.Context) *diagnostic.Error
