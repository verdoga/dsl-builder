package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// splitLists делит содержимое matching/ordering только по прямому separator,
// определённому isSeparator. Возвращает индекс либо -1. В matching требуется
// ровно один разделитель, в ordering — ноль или один; повтор — CodeCollection.
// Блоки answer/hint проходят как целые конструкции; их текст не исследуется
// на разделители. Наличие пустой нижней части не равнозначно отсутствию.
func splitLists(kind lesson.NodeType, lines []model.Line, context diagnostic.Context) (int, *diagnostic.Error)

// listItems читает область до разделителя или весь сокращённый ordering.
// Каждая непустая прямая content-строка создаёт item. Следующий значимый
// answer того же родителя связывается только с этим item через attachAnswer;
// readAnswer включает его связанный hint. Повторный/осиротевший answer,
// несвязанный hint и иная значимая конструкция — CodeBinding.
// start включён, end исключён; индексы относятся к переданному lines.
func listItems(lines []model.Line, start int, end int, context diagnostic.Context) ([]entry, *diagnostic.Error)

// listLabels читает область после разделителя: по одной непустой content-строке
// на option либо position, с пустыми Answers и Hint. Теги answer/hint здесь
// запрещены; вложенные блоки не разворачиваются в подписи. Исходные обозначения
// не превращаются в индексы и не удаляются из отображаемого текста.
func listLabels(lines []model.Line, start int, end int, role lesson.DataRole, context diagnostic.Context) ([]entry, *diagnostic.Error)

// checkLabelReferences проверяет каждый ответ item по подписям нижнего списка:
// ровно одно совпадение без учёта регистра посредством strings.EqualFold,
// с учётом всех остальных символов. Вызывается только при полной конфигурации.
// Перед ссылками запрещает совпадающие без учёта регистра подписи нижнего
// списка, даже если на них нет ссылки. Отсутствие/неоднозначность — CodeReference.
// Исходные строки Answers сохраняются, не заменяются индексами или подписями.
// Не устанавливает взаимно однозначного соответствия между разными items:
// несколько элементов вправе ссылаться на один option/явную position.
func checkLabelReferences(items []entry, labels []entry, context diagnostic.Context) *diagnostic.Error

// checkDistinctLabels обнаруживает все места совпадающей без учёта регистра
// подписи при включённой проверке; непроверяемые списки не ограничивает.
func checkDistinctLabels(labels []entry, context diagnostic.Context) *diagnostic.Error

// resolveLabel проверяет одну ссылку, возвращая индекс единственной подписи.
// source — исходное место значения answer; места кандидатов попадают в Related.
func resolveLabel(value string, labels []entry, source diagnostic.Context) (int, *diagnostic.Error)
