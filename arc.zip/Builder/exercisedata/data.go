package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/parsed/model"
)

// entry хранит готовые данные листа и исходные места для предметных ошибок.
// Это временное соответствие вывода источнику, а не новая модель lesson.Data;
// оно необходимо для повторов подписей, ссылок и неполной конфигурации ответов.
type entry struct {
  // data — текстовые данные с ролью body, item, option или position.
  data lesson.Data

  // source — место исходной формулировки, элемента или варианта.
  source diagnostic.Context

  // answerSource — место породившего ответы answer; nil означает его отсутствие.
  answerSource *diagnostic.Context

  // answerSources — места отдельных значений, в порядке data.Answers.
  answerSources []diagnostic.Context
}

// textData создаёт DataText заданной роли с точным value и переданными ответами
// и подсказкой. Нулевой answers заменяет только отсутствующий массив на пустой;
// строки ответов не изменяются. Срез ответов копируется для независимости.
func textData(role lesson.DataRole, value string, answers []string, hint string) lesson.Data

// collectionData создаёт DataCollection с ролью items/options/positions,
// ненулевым []lesson.Data, пустыми Answers и Hint. Самих листовых ролей
// не меняет; коллекции никогда не вкладывает в другие коллекции.
func collectionData(role lesson.DataRole, entries []entry) lesson.Data

// localInstruction извлекает необязательный content объявления
// choice/multichoice/matching в DataText/RoleInstruction с пустыми ответами
// и подсказкой. Отсутствие даёт nil; чужие теги не принимаются.
// ordering обслуживается внешней самостоятельной instruction по контракту Build.
func localInstruction(line model.Line, context diagnostic.Context) (*lesson.Data, *diagnostic.Error)

// requireCount проверяет предметный минимум готового списка перед его
// помещением в обязательную коллекцию; сообщает CodeCollection с ролью,
// фактическим и требуемым количеством. Максимум не вводится.
func requireCount(role lesson.DataRole, entries []entry, minimum int, context diagnostic.Context) *diagnostic.Error
