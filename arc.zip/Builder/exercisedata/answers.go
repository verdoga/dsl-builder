package exercisedata

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed/model"
)

// answerGroup сохраняет один исходный answer, его альтернативы и общую
// подсказку до привязки к вопросу, item или группе правильных вариантов.
// Группа нужна для ограничения одного answer и копирования группового hint.
type answerGroup struct {
  // values — непустой список точных семантических значений ответа.
  values []string

  // sources — исходное место каждого values в том же порядке.
  sources []diagnostic.Context

  // source — исходное место тега answer, включая блочную форму.
  source diagnostic.Context

  // hint — связанная подсказка, пустая строка при её отсутствии.
  hint string
}

// readAnswer читает ровно один answer на at: однострочный content либо
// непустые строки его блока через contentRows, затем validateAnswerValues
// и readLinkedHint. Возвращает первый индекс после группы, включая hint.
// allowEditor относится только к промежутку между answer и связанным hint.
// Не поглощает следующий answer; допустимость повторов решает владелец.
func readAnswer(lines []model.Line, at int, allowEditor bool, context diagnostic.Context) (answerGroup, int, *diagnostic.Error)

// validateAnswerValues требует хотя бы одно значение и хотя бы один
// непробельный Unicode-символ в каждом. Не нормализует сохраняемые ответы,
// не удаляет пунктуацию и не сравнивает их с ответами пользователя.
// Пустой явный answer — CodeAnswer, а не отключение checkable.
func validateAnswerValues(values []string, sources []diagnostic.Context, context diagnostic.Context) *diagnostic.Error

// readLinkedHint читает максимум один hint следующей значимой конструкцией
// на том же ParentLine, что answer; после блочного answer — после block-end.
// Содержимое однострочной формы берётся из Value, блочной — из contentRows
// и соединяется через \n без пустых исходных строк. Несвязанную конструкцию
// не поглощает. Граница проекции исключает переход через include/контейнер.
// У найденной подсказки content обязан быть известен; nil не заменяется
// пустой строкой. Повторный hint остаётся владельцу для CodeBinding.
func readLinkedHint(lines []model.Line, at int, parentLine *int, allowEditor bool, context diagnostic.Context) (hint string, next int, err *diagnostic.Error)

// attachAnswer возвращает независимый entry с альтернативами и hint группы;
// применим к body question или item. Повторный answer даёт CodeBinding.
// Источники значений сохраняются для последующей проверки ссылок.
func attachAnswer(item entry, group answerGroup) (entry, *diagnostic.Error)

// answerCoverage определяет отсутствие ответов у всех entries (false) либо
// наличие у всех (true). Частичное наличие даёт CodeIncompleteAnswers:
// Context у объявления, Related у всех элементов с ответами и без них.
// Пустой явный answer уже отклонён readAnswer; false не скрывает ошибку.
func answerCoverage(entries []entry, context diagnostic.Context) (bool, *diagnostic.Error)
