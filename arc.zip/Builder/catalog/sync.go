package catalog

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
  "smoothlingua/manifest"
)

// EntryFromLesson копирует ID, Title, Subtitle, LineCount, CreatedAt и Version
// из окончательного Document и добавляет назначенные fileName и weight.
// Не вычисляет ревизию, не меняет дату, регистр ID или само значение weight.
// nil Subtitle остаётся null; числовые json.Number копируются без float64.
// Предусловие: урок проверен lesson, имя выдано module, веса проверяет catalog.
// Полное соответствие схемы записи проверяется manifest при экспорте.
func EntryFromLesson(value lesson.Document, fileName string, weight *string) manifest.Entry

// SyncLesson синхронизирует одну запись с окончательным уроком после revision
// и решений по названиям, включая отказ пользователя. Сохраняет Section,
// Order и FileName; ID обязан точно совпадать с уже сохранённым написанием.
// Не подставляет метаданные неподтверждённого кандидата; при отсутствии
// содержательных изменений app передаёт прежний Document, включая LineCount.
// Координирует findItem, EntryFromLesson и Refresh на независимой копии.
// Несовпадение ID даёт CodeIdentity; урок и другие записи не изменяются.
func SyncLesson(value *State, fileName string, document lesson.Document) (*State, []*diagnostic.Error)

// ProposePlacement описывает различия section/order нового технического JSON
// с текущей записью, не применяя их. Входной section == nil предлагает
// непосредственное размещение, но не выполняет его; nil weight не предлагает
// удаление старого веса. Строковые веса сравниваются точно: 01 → 1 меняет JSON.
// Проверяет ненулевые значения через manifest.ValidateSectionTitle и
// order.Validate. Возвращает отдельное Change для каждого различия, чтобы
// app мог независимо показать и подтвердить каждое «было → станет».
// Принятые изменения применяются MoveLesson и SetLessonWeight;
// при отказе текущий снимок и размещение остаются прежними.
func ProposePlacement(value *State, fileName string, section *string, weight *string) ([]Change, []*diagnostic.Error)
