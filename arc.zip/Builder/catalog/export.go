package catalog

import (
  "smoothlingua/diagnostic"
  "smoothlingua/manifest"
)

// Export формирует готовый Manifest без изменения State. Координирует
// Validate, exportContents, exportCourse и manifest.Validate. При любой ошибке
// возвращает nil Manifest. Не сортирует молча и не пишет файлы.
// formatVersion берёт из manifest.FormatVersion; createdAt передаёт app:
// старую дату для сопоставления, новое UTC-время при фактической новой записи.
// Само изменение этой даты не повод записывать архив; решение принимает app.
// Экспорт не меняет даты/версии записей уроков, имена, ID и ведущие нули весов.
func Export(value *State, createdAt string, context diagnostic.Context) (*manifest.Manifest, []*diagnostic.Error)

// exportContents создаёт ненулевые массивы: либо lessons без sections,
// либо sections с пустым lessons. Пустые рабочие секции пропускает.
// Сохраняет текущий порядок, все восемь полей Entry и явный null Subtitle;
// внутренние пути, веса секций и признаки рабочего состояния не переносятся.
func exportContents(value *State) ([]manifest.Entry, []manifest.Section)

// exportCourse выбирает ровно одну форму схемы: Course.Unit при UnitTitle
// либо указатели Course.Lessons/Course.Sections при отсутствии юнита.
// Указатели никогда не указывают на nil-срез; Unit имеет оба ненулевых массива.
func exportCourse(value *State, lessons []manifest.Entry, sections []manifest.Section) manifest.Course

// readPlacement переносит выбранную ветвь course/unit в рабочий снимок
// без исправления значений, объединения повторов и изменения порядка.
// Предусловие: форма и схема уже проверены manifest; вызывают Import
// и ValidateManifest. Каждый объект sections сохраняется для обнаружения дублей.
func readPlacement(value manifest.Manifest, context diagnostic.Context) *State
