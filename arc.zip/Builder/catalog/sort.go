package catalog

import (
  "smoothlingua/diagnostic"
  "smoothlingua/order"
)

// SetSectionWeights принимает полный набор из одного SectionOrder для
// каждой текущей секции. Проверяет точные имена, отсутствие пропусков/повторов
// и все ненулевые Weight через order.Validate. Ошибка ввода даёт nil State.
// Координирует validateSectionWeights, sortSectionsByWeight и Refresh.
// Равные числовые веса секций допустимы; меняется только порядок sections,
// сами временные числа не являются изменением экспортируемого манифеста.
func SetSectionWeights(value *State, weights []SectionOrder) (*State, []*diagnostic.Error)

// validateSectionWeights проверяет полноту и однократность точных имён,
// наличие каждого веса и его запись через order.Validate; ничего не сортирует.
func validateSectionWeights(value *State, weights []SectionOrder) []*diagnostic.Error

// compareSectionTitles задаёт детерминированный алфавит: strings.ToLower,
// затем исходное написание. Локаль ОС не используется. Результат −1, 0, 1.
func compareSectionTitles(left string, right string) int

// sortSectionsByWeight сортирует копию полного проверенного набора сначала
// через order.Compare, затем compareSectionTitles; не ограничивает числа int.
func sortSectionsByWeight(values []SectionOrder) []SectionOrder

// sortItems группирует копию по текущему массиву Sections и сортирует уроки
// внутри каждой группы через order.Compare после успешной order.Validate.
// Нераспределённые записи идут отдельно перед секциями. Для равных весов
// сохраняется прежний порядок; это лишь стабильное превью, конфликт остаётся.
// Отсутствующие и неверные веса идут после корректных в прежнем порядке,
// не передаются order.Compare и не подменяются синтезированными значениями.
func sortItems(value *State) []Item

// Refresh — небольшой координатор Clone, sortItems и Validate всего состава.
// Секции самовольно не пересортировывает: сохраняет импортированный либо
// выбранный порядок. После каждой предметной правки возвращает актуальное
// превью и все блокировки; ошибки других записей не скрываются.
// nil исходного State даёт CodeState и nil результат.
func Refresh(value *State) (*State, []*diagnostic.Error)
