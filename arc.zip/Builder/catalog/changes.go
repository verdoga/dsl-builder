package catalog

import "encoding/json"

// Change — одно предметное изменение манифеста для независимого показа
// «было → станет»; не команда, не подтверждение и не JSON Patch.
type Change struct {
  // FileName — неизменный селектор записи; пусто для курса/юнита/всех секций.
  FileName string
  // Section — имя секции для изменения порядка её уроков; nil для общей группы.
  Section *string
  // Field — course.title, course.unit, sections, section, lessons либо одно
  // из полей Entry: id, fileName, order, title, subtitle, lineCount, createdAt,
  // version; entry обозначает добавленную/отсутствующую целую запись.
  Field string
  // Before — JSON-значение до правки; nil означает отсутствие объекта,
  // литерал null отличается от отсутствия, пустая строка остаётся строкой.
  Before json.RawMessage
  // After — JSON-значение после правки с теми же правилами отсутствия/null.
  After json.RawMessage
}

// Changes координирует changesTitles, changesSections и changesEntries.
// Сравнивает логический экспорт двух согласованных снимков без времени
// корневого manifest, внутренних контекстов, путей и временных весов секций.
// Пустые рабочие секции и один лишь Sectioned не создают изменение JSON.
// Не является единственной проверкой готовности: перед записью нужен Export.
// Строки сравнивает точно, числа Entry — математически без потери точности;
// порядок массивов значим. Пустой результат означает отсутствие изменения
// манифеста, но app отдельно учитывает изменение содержимого урока.
// Порядок отчёта: названия, секции, записи по их порядку после изменения,
// затем исчезнувшие; для полей записи — порядок manifest.Entry.
// Удаление записи здесь только описывается; API удаления уроков пакет не даёт.
func Changes(before *State, after *State) []Change

// changesTitles описывает название курса и необязательный юнит:
// course.unit содержит имя либо null, поэтому создание/удаление отличается
// от переименования. Перестройка вложенности не дублируется по каждому полю.
func changesTitles(before *State, after *State) []Change

// changesSections описывает порядок непустых секций как массив имён,
// переносы уроков как section и порядок уроков каждой группы как lessons
// с массивами технических имён. Имена сравнивает с учётом регистра.
func changesSections(before *State, after *State) []Change

// changesEntries сопоставляет записи по FileName, уже стабилизированному module,
// и делегирует changesEntry. Новая/исчезнувшая запись описывается одним entry
// со всеми полями, без ошибочного попарного сопоставления разных уроков.
func changesEntries(before []Item, after []Item) []Change

// changesEntry сравнивает только восемь полей manifest.Entry двух Item.
// json.Number сравнивает точно средствами math/big, без ограничения диапазона;
// Order остаётся строкой: 01 и 1 равны для конфликтов, но различны в JSON.
func changesEntry(before Item, after Item) []Change
