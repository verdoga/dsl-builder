package catalog

import (
  "smoothlingua/diagnostic"
  "smoothlingua/manifest"
)

// Validate проверяет только размещение рабочего снимка: непустой состав,
// названия через manifest, реестр секций, полноту распределения, наличие
// и запись всех весов, конфликты и порядок уроков. Координирует validateSections,
// validateDistribution, validateWeights, Conflicts и validateLessonOrder.
// Обязательный итоговый вес требуется и у единственного урока.
// Не проверяет дерево lesson, ревизии, связи ZIP и уникальность ID/имён.
// Ошибки идут в порядке: названия, секции, распределение, веса, конфликты,
// сортировка; внутри — текущий порядок секций/уроков. Никаких изменений модели.
func Validate(value *State) []*diagnostic.Error

// ValidateManifest проверяет правила catalog у уже проверенного по схеме
// манифеста, не меняя его. Предназначена для module при проверке всего состава.
// Координирует readPlacement и Validate; не вызывает Import, избегая рекурсии.
// Порядок sections из архива является авторитетным: временные веса неизвестны.
func ValidateManifest(value manifest.Manifest, context diagnostic.Context) []*diagnostic.Error

// validateSections проверяет имена существующим manifest.ValidateSectionTitle,
// точную уникальность названий реестра, существование каждого Item.Section
// в реестре и валидность ненулевых временных весов через order.Validate.
// Пустые секции рабочего состояния не являются ошибкой; вывод их исключает.
func validateSections(value *State) []*diagnostic.Error

// validateDistribution запрещает одновременное наличие назначенных и
// неназначенных уроков, а также любое ненулевое назначение при Sectioned=false.
// При Sectioned=true каждый неназначенный урок блокирует запись, даже если
// пока не распределён ни один; Related перечисляет все незавершённые записи.
func validateDistribution(value *State) []*diagnostic.Error

// validateWeights сообщает каждое nil Entry.Order как CodeMissingWeight;
// ненулевые значения проверяет только через order.Validate с контекстом Item.
// Не применяет правило частичного наличия новой сборки к обновлению/добавлению.
func validateWeights(items []Item) []*diagnostic.Error

// validateLessonOrder проверяет возрастание корректных числовых весов каждой
// группы без скрытой пересортировки. Равенство отражает Conflicts;
// сравнения через отсутствующий или неверный вес пропускаются без каскада.
func validateLessonOrder(value *State) []*diagnostic.Error
