package catalog

import "smoothlingua/diagnostic"

// ValidateNewPlacement проверяет исходные Section и Entry.Order по группам:
// смешение секций и их отсутствия, имена через manifest.ValidateSectionTitle,
// ненулевые веса через order.Validate, частичное наличие через checkPresence.
// Остальные поля Entry не рассматривает: app может вызвать до преобразования,
// заполнив только ID, FileName, Order, Section, RelativePath и Context.
// Ничего не синтезирует и не исправляет. Возвращает все независимые ошибки.
func ValidateNewPlacement(items []Item) []*diagnostic.Error

// Create создаёт новую рабочую модель после преобразования всех уроков.
// Получает готовые записи через EntryFromLesson и метаданные section/order
// через Item; технические имена уже назначены module по входным путям.
// Координирует проверку названий, ValidateNewPlacement, initializeSections,
// initializeWeights и Refresh. Пустой набор, неверные исходные значения,
// смешанный состав и частичное наличие весов дают nil State.
// Числовые совпадения дают ненулевой State с ошибками для исправления в превью.
// Пустой unitTitle означает nil; непустой проверяется manifest.ValidateTitle.
// Предусловие: app передаёт items в порядке filetree.SortRelative —
// по относительному пути без учёта регистра, затем исходному написанию.
// Сортировка путей повторно не реализуется: filetree не прямая зависимость.
func Create(courseTitle string, unitTitle string, items []Item) (*State, []*diagnostic.Error)

// initializeSections объединяет точные одинаковые имена и первоначально
// сортирует уникальные секции через compareSectionTitles; регистр сохраняет.
// Предусловие: ValidateNewPlacement успешна; исходные имена не нормализует.
func initializeSections(items []Item) []SectionOrder

// initializeWeights координирует checkPresence и synthesizeGroup отдельно
// для каждой секции либо единственной группы без секций. Заданные строки
// остаются точными копиями, включая ведущие нули. Синтез применяется только здесь.
func initializeWeights(items []Item) ([]Item, []*diagnostic.Error)

// checkPresence проверяет только правило «все заданы либо все отсутствуют»
// одной группы новой сборки. При частичном наличии сообщает всех участников;
// пустая строка не считается отсутствием. Проверку записи делает order.Validate.
func checkPresence(items []Item) *diagnostic.Error

// synthesizeGroup назначает 1, 2, … одной группе, где все Order равны nil.
// initializeWeights сохраняет в группе относительный порядок общего входного
// среза, уже отсортированного app через filetree.SortRelative. Поэтому синтез
// соответствует относительным путям без дублирования функции ComparePaths.
// Последовательность десятичная, без искусственной верхней границы;
// изменяются только Entry.Order копий, исходные JSON и уроки не затрагиваются.
// Предусловия о путях и порядке обеспечиваются перед вызовом Create.
func synthesizeGroup(items []Item) []Item
