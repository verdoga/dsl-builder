package catalog

import "smoothlingua/diagnostic"

// SetCourseTitle строит кандидат с одним изменённым названием курса,
// проверенным manifest.ValidateTitle, и вызывает Refresh; путь не используется.
func SetCourseTitle(value *State, title string) (*State, []*diagnostic.Error)

// SetUnitTitle строит кандидат с новым названием либо без юнита при title == "".
// Непустое название проверяет manifest.ValidateTitle. Переносит вложенность
// только при экспорте, сохраняя уроки и секции; затем вызывает Refresh.
func SetUnitTitle(value *State, title string) (*State, []*diagnostic.Error)

// NormalizeSectionTitle приводит новый пользовательский ввод к схеме:
// заменяет TAB, CR, LF обычным пробелом, убирает крайние U+0020 и повторные
// U+0020. Не меняет регистр, прочие Unicode-пробелы и Unicode-нормализацию.
// Результат проверяет manifest.ValidateSectionTitle; пустое имя ошибочно.
// Исходные метаданные JSON и прочитанные имена этим способом не исправляются.
func NormalizeSectionTitle(raw string, context diagnostic.Context) (string, *diagnostic.Error)

// CreateSection принимает уже нормализованное и подтверждённое имя,
// проверяет manifest.ValidateSectionTitle, добавляет секцию в конец либо
// использует уже существующую с точно тем же именем. Включает Sectioned;
// неперенесённые уроки остаются видимыми и блокируют экспорт через Refresh.
// Пустая секция сохраняется в рабочем снимке до распределения.
func CreateSection(value *State, title string) (*State, []*diagnostic.Error)

// MoveLesson строит кандидат с одной новой Section и вызывает Refresh.
// Ненулевое имя уже проверено/нормализовано в зависимости от источника;
// отсутствующая секция добавляется через CreateSection. nil оставляет урок
// без секции. При первом ненулевом назначении включает Sectioned; не распределяет
// остальные уроки автоматически. Вес, метаданные и имя файла сохраняет;
// совпадения в новой группе видны в возвращённых ошибках всего состава.
func MoveLesson(value *State, fileName string, section *string) (*State, []*diagnostic.Error)

// UseFlatPlacement завершает явно выбранное размещение без секций, только
// если Section уже nil у всех уроков. Убирает пустые рабочие секции и сбрасывает
// Sectioned; не снимает назначения автоматически. Проверяет новую общую
// группу через Refresh, где одинаковые прежние веса могут стать конфликтами.
func UseFlatPlacement(value *State) (*State, []*diagnostic.Error)

// SetLessonWeight проверяет raw через order.Validate, строит кандидат
// с точной строкой веса одной записи и вызывает Refresh. Применим для
// последовательного ввода весов выбранной группы, в том числе после импорта.
// Временные совпадения допустимы в рабочем кандидате, но запрещают экспорт.
// Отсутствие, пустая строка и ноль не подставляются вместо нового веса.
func SetLessonWeight(value *State, fileName string, raw string) (*State, []*diagnostic.Error)
