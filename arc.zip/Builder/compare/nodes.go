package compare

import "smoothlingua/lesson"

// compareNodeShape сравнивает число и упорядоченную вложенность нод;
// тип, флаги и data не являются формой дерева. Отличие типа при той же
// форме допускает точечную замену. parentPath пуст у корней страницы.
// Разное число корней даёт NodeCountChanged; разное число потомков —
// NodeNestingChanged с адресом соответствующего nodes и точными количествами.
// В несопоставимом массиве не создаёт фиктивные пары детей; в остальных
// ветвях продолжает проверку. Произвольного предела глубины или числа нет.
func compareNodeShape(old []lesson.Node, candidate []lesson.Node, pageIndex int, parentPath []int) []Reason

// compareNodeChanges обходит равные по форме деревья по соответствующим
// позициям: собственные поля через compareNodeOwnFields, затем дети.
// После отличия продолжает проверку всех остальных нод. Две ноды одинаковой
// формы, обменявшиеся местами, образуют две позиционные замены; сопоставления
// по первичным ID и попытки переноса их базовых номеров между позициями нет.
func compareNodeChanges(old []lesson.Node, candidate []lesson.Node, parentPath []int) []NodeChange

// compareNodeOwnFields сравнивает только Type, Flags и Data; ID и Nodes
// исключены. Возвращает непустые изменения в порядке type, flags, data.
// Равные собственные поля дают пустой результат, даже если изменены дети.
func compareNodeOwnFields(old lesson.Node, candidate lesson.Node) []NodeField

// equalNodeTrees сравнивает полный упорядоченный лес по форме, собственным
// полям через compareNodeOwnFields и потомкам. Все ID игнорируются.
// Используется только для свидетельств порядка страниц, не для поиска
// «похожих» нод и не для определения новой версии.
func equalNodeTrees(left []lesson.Node, right []lesson.Node) bool

// equalFlags сравнивает наличие и значения Speaking, Stepped и Checkable.
// nil отличается от false; адреса указателей не сравниваются. Флаги
// не пересчитываются из данных, в том числе у multifill.
func equalFlags(left lesson.NodeFlags, right lesson.NodeFlags) bool
