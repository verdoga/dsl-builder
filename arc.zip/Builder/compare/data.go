package compare

import "smoothlingua/lesson"

// equalDataList сравнивает длину и каждый элемент через equalData в порядке
// массива. Вложенные коллекции используют то же правило без ограничения
// глубины; изменение числа элементов данных меняет собственные поля ноды,
// а не форму дерева nodes и само по себе не заменяет все ноды страницы.
func equalDataList(left []lesson.Data, right []lesson.Data) bool

// equalData сравнивает Type, Role с учётом отсутствия, Value через
// equalDataValue, Answers с сохранением порядка и Hint. Не нормализует
// пробелы, регистр, переносы, HTML, ответы и внутреннюю разметку multifill.
// Ответы не вычисляются; одинаковый текст в разных ролях остаётся различным.
func equalData(left lesson.Data, right lesson.Data) bool

// equalDataValue принимает уже проверенные lesson.Validate элементы одного
// Type. Сравнивает string точно; EmbeddedFile через equalEmbeddedFile;
// []lesson.Data через equalDataList. Иные варианты исключены валидацией.
// Сериализация в JSON и сравнение оформления объектов не используются.
func equalDataValue(left lesson.Data, right lesson.Data) bool

// equalEmbeddedFile сравнивает точные FileName, MIMEType и содержимое файла
// через equalEmbeddedContent. Имя и MIME значимы
// даже при тех же байтах. Пути ресурсов и файловые даты недоступны и не нужны;
// файлы не читаются, медиаконтейнеры не анализируются и Base64 не выводится.
func equalEmbeddedFile(left lesson.EmbeddedFile, right lesson.EmbeddedFile) bool

// equalEmbeddedContent сравнивает декодированные байты проверенного Base64
// средствами стандартной библиотеки. Не зависит от оформления JSON и не
// предполагает дополнительных требований каноничности сверх lesson.Validate.
// Содержимое не перекодируется в модели; пустой файл сравнивается как пустой.
func equalEmbeddedContent(left string, right string) bool
