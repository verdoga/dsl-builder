package fragments

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed"
  "smoothlingua/parsed/model"
)

// copyEntries создаёт отдельный Entry для каждого номера через cloneLine,
// используя готовый Input.Index.ByNumber. Parent и Included пока не связаны.
// Номера получены из documentLines/bodyLines и существуют в проверенном Input.
// Порядок numbers сохраняется, исходные номера не перенумеровываются.
func copyEntries(input *parsed.Input, numbers []int) []*Entry

// cloneLine копирует model.Line, её ParentLine, Elements и изменяемые данные
// каждого элемента через cloneElement. Ничто изменяемое не разделяется
// с Input либо другим Entry. Строковые значения и null сохраняются точно.
func cloneLine(source model.Line) model.Line

// cloneElement копирует model.Element с отдельными Value и ErrorIDs;
// сохраняет различие nil и пустого среза, Raw и диапазон Unicode-колонок.
func cloneElement(source model.Element) model.Element

// bindParents связывает Parent в пределах нового набора Entry по исходным
// parentLine. Ссылка на sourceRoot заменяется boundary; у корня документа
// parentLine=null даёт nil. Остальные ссылки обязаны разрешаться в этом наборе,
// включая block-end к своему block-start; иначе CodeParent с исходной строкой.
// Для корня тела sourceRoot — номер fragment, boundary — конкретный include.
// Нельзя оставлять ссылку на копию из другого включения или на исходный Input.
// Source.ParentLine/NestingLevel не переписываются: structure использует
// Entry.Parent для принадлежности и отдельно ведёт семантические контейнеры.
func bindParents(input *parsed.Input, entries []*Entry, sourceRoot int, boundary *Entry) []*diagnostic.Error
