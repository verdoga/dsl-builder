package fragments

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed"
  "smoothlingua/parsed/model"
)

// definition — адрес исходного определения и его тела для повторного копирования;
// это внутренний индекс, не вторая модель строк или метаданных документа.
type definition struct {
  // Header — физический номер строки fragment в Input.Result.Lines.
  Header int

  // Identifier — исходный элемент identifier для имени и точного диапазона.
  Identifier model.Element

  // Body — номера строк тела в исходном порядке без внешнего объявления,
  // его закрывающей строки и вложенных определений с их телами.
  Body []int
}

// collectDefinitions просматривает все исходные строки, независимо от ветвей
// и будущего использования. Для fragment вызывает readIdentifier и bodyLines.
// Ключ — strings.ToLower семантического identifier.Value; без обрезания,
// Unicode-нормализации и проверки синтаксиса ID урока через identity.
// Сохраняет всех кандидатов и их исходный порядок, не перезаписывает дубль.
// Имена task/document-id не входят в пространство имён фрагментов.
func collectDefinitions(input *parsed.Input) (map[string][]*definition, []*diagnostic.Error)

// readIdentifier извлекает единственный непустой identifier.Value у fragment
// или include и его исходные координаты. Проверяет только необходимую форму:
// fragment — block-start, include — tag. Отсутствие, null, пустота или несколько
// идентификаторов дают CodeShape. Имя тега читается из tag.Value, не из Raw;
// экранирование не снимается повторно, нового белого списка ID не вводится.
func readIdentifier(line model.Line, context diagnostic.Context) (model.Element, *diagnostic.Error)

// bodyLines выбирает по Index.Children потомков определения и сохраняет
// порядок Result.Lines. Собственная block-end определяется по parentLine,
// а не поиском текста скобки; требуется ровно одна такая строка после тела.
// Отсутствующая/лишняя граница или потомок за границей дают CodeShape.
// Внутренние границы контентных блоков и пустые строки сохраняются.
// Вложенные определения исключаются со всем поддеревом, но регистрируются
// отдельно collectDefinitions. Глубина обхода не ограничивается константой.
func bodyLines(input *parsed.Input, header int) ([]int, []*diagnostic.Error)

// checkDefinitionNames отклоняет несколько определений одного ключа даже
// без включений: DSL 3.12.5 требует уникальность в текущем документе.
// Выдаёт одну CodeAmbiguous на группу со всеми объявлениями в Related;
// порядок групп определяется первой физической строкой, а не обходом map.
func checkDefinitionNames(input *parsed.Input, definitions map[string][]*definition) []*diagnostic.Error

// documentLines возвращает исходные номера вне всех определений и их
// поддеревьев. Определение не создаёт границу task/step или отображаемый
// материал. Не фильтрует другие строки и не меняет порядок входа.
func documentLines(input *parsed.Input) []int
