package fragments

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed"
  "smoothlingua/parsed/model"
)

// resolveIncludes проверяет каждую исходную строку include, включая строки
// в определениях, через readIdentifier и resolveInclude. Возвращает индекс
// физического номера include в единственное определение. Разрешение имён
// ограничено одним Input; соседние файлы, метаданные и task не участвуют.
// При ошибках не возвращает пригодный частичный индекс.
func resolveIncludes(input *parsed.Input, definitions map[string][]*definition) (map[int]*definition, []*diagnostic.Error)

// resolveInclude ищет по strings.ToLower(identifier.Value), сохраняя исходное
// написание. Ноль кандидатов даёт CodeMissing, несколько — CodeAmbiguous
// с полным перечнем определений в Related; первый кандидат не выбирается.
func resolveInclude(identifier model.Element, definitions map[string][]*definition, context diagnostic.Context) (*definition, *diagnostic.Error)

// checkIncludeCycles проверяет конечность зависимостей определений по include
// в их Body. Прямой или косвенный цикл даёт CodeCycle с цепочкой исходных
// include и определений в Related. Повтор независимого использования одного
// определения не является циклом. Проверка не ограничивает глубину и число
// включений; это защита конечности развёртывания, не повторный DSL-валидатор.
// В корректном DSL 1.2 вложенные include не встречаются; неожиданный вход,
// прошедший Contract, не должен приводить к бесконечному развёртыванию.
// Порядок проверок задаётся исходными строками, не порядком map.
func checkIncludeCycles(input *parsed.Input, definitions map[string][]*definition, references map[int]*definition) []*diagnostic.Error
