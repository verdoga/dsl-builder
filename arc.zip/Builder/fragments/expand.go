package fragments

import (
  "smoothlingua/diagnostic"
  "smoothlingua/parsed"
)

// Expand принимает ненулевой Input, полученный parsed.Load без ошибок.
// Координирует collectDefinitions, checkDefinitionNames, resolveIncludes,
// checkIncludeCycles, documentLines и expandSequence; правила этих шагов
// не дублирует. Сбор определений предшествует любому включению: доступны
// определения после include и во всех ветвях текущего документа.
// Возвращает последовательность исходного порядка с отдельными экземплярами
// каждой вставки. Определения, их тела в месте объявления и собственные
// закрывающие строки отсутствуют. Остальные строки, в том числе blank,
// блоковые границы, метатеги, script и multifill, передаются без потерь.
// Строки include остаются только служебными границами Entry.Included;
// structure не создаёт для них ноды и обходит содержимое в месте вставки.
// Источник ресурсов остаётся input.Path; Document.LineCount не пересчитывается.
// Успех: непустой либо пустой ненулевой срез и nil ошибок; любая ошибка:
// nil результата и непустой список diagnostic.Error, без частичного успеха.
// Лимиты количества включений и глубины не вводятся. Повторные вызовы
// независимы, глобального изменяемого состояния и файлового ввода-вывода нет.
func Expand(input *parsed.Input) ([]*Entry, []*diagnostic.Error)

// expandSequence координирует copyEntries, bindParents и expandInclusions
// для одного исходного набора номеров. sourceRoot=0 означает документ,
// иначе это номер определения, заменённого boundary. Для документа boundary
// равен nil. Предварительно ссылки разрешены и циклы исключены.
func expandSequence(input *parsed.Input, numbers []int, sourceRoot int, boundary *Entry, references map[int]*definition) ([]*Entry, []*diagnostic.Error)

// expandInclusions заполняет только Included у Entry include, последовательно
// вызывая expandInclusion. Не превращает соседние строки в детей вставки.
func expandInclusions(input *parsed.Input, entries []*Entry, references map[int]*definition) []*diagnostic.Error

// expandInclusion разворачивает новое тело через expandSequence с собственным
// boundary=site. Не переиспользует готовые Entry другого включения и не
// кэширует изменяемое содержимое. При ошибке добавляет место include в Related.
func expandInclusion(input *parsed.Input, site *Entry, target *definition, references map[int]*definition) ([]*Entry, []*diagnostic.Error)
