package module

import "smoothlingua/diagnostic"

// CheckNewIDs проверяет ID входов до преобразования: LessonID и Path берутся
// app из проверенных parsed-данных и реального пути технического JSON.
// Использует готовый diagnostic.Context вместо второй модели входа.
// Пустой incoming даёт CodeEmpty; existing пуст при создании либо содержит
// проверенный архив, что является предусловием проверки новых ID.
// Координирует validateIDs и checkExistingIDs; каждый повтор среди входов —
// ошибка, включая различие регистра. Совпадение с архивом даёт CodeExistingID
// с указанием, что требуется обновление. Набор целиком отклоняется при ошибке.
func CheckNewIDs(incoming []diagnostic.Context, existing []*File) []*diagnostic.Error

// validateIDs проверяет каждый LessonID через identity.ValidateLessonID,
// группирует корректные значения по identity.LessonKey и сообщает один
// CodeDuplicateID на каждый повтор со всеми участниками, включая первого.
// Ничего не генерирует и не меняет исходное написание. Порядок — порядок входа;
// неверные значения не объединяются в искусственную группу пустого ключа.
func validateIDs(values []diagnostic.Context) []*diagnostic.Error

// checkExistingIDs находит все совпадения корректных входных ID с существующими
// через identity.LessonKey. Related содержит входы и прежние файлы каждого
// конфликтующего ID. Не вызывает ReplaceFile и не выполняет скрытое обновление.
func checkExistingIDs(incoming []diagnostic.Context, existing []*File) []*diagnostic.Error

// FindByID проверяет lessonID через identity.ValidateLessonID и находит ровно
// один File по identity.LessonKey. Ноль совпадений — CodeMissingLesson,
// несколько — CodeAmbiguousLesson со всеми кандидатами; первый не выбирается.
// Возвращает неизменяемый файл с прежним написанием ID и техническим именем.
// nil/нулевые файлы дают CodeFile; ни один такой файл молча не пропускается.
// При любой ошибке результат File равен nil, включая ошибку другого кандидата.
func FindByID(files []*File, lessonID string, context diagnostic.Context) (*File, []*diagnostic.Error)
