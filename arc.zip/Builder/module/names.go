package module

import (
  "smoothlingua/diagnostic"
  "smoothlingua/identity"
)

// AssignFileNames выдаёт count новых имён в порядке входного списка app.
// Для создания existing пуст: имена l001.json и далее назначаются до convert.
// Для добавления existing содержит все файлы проверенного архива; нумерация
// продолжается после максимума, пропуски не занимаются. app сопоставляет
// результат по индексу со входами, уже отсортированными filetree.SortRelative.
// Пакет не сортирует пути повторно, не сортирует уроки и не меняет старые имена.
// count — длина реально размещённого в памяти списка, не диапазон номеров.
// count <= 0 даёт CodeEmpty. Координирует validateFileNames, maxFileNumber
// и allocateNames; при любой ошибке результат nil, частичного назначения нет.
func AssignFileNames(existing []*File, count int, context diagnostic.Context) ([]string, []*diagnostic.Error)

// maxFileNumber выбирает максимум среди номеров identity.ParseFileName;
// для пустого списка возвращает строку 0. Предусловие: validateFileNames успешна.
// Сравнивает точные числа средствами math/big, без int/uint64/float64.
func maxFileNumber(files []*File) string

// allocateNames возвращает count последовательных имён после maximum:
// арифметика math/big, форматирование только identity.FormatFileName.
// maximum — неотрицательное десятичное число от maxFileNumber, count > 0.
// После 999/9999 ширина растёт свободно; искусственной верхней границы нет.
func allocateNames(maximum string, count int, context diagnostic.Context) ([]string, *diagnostic.Error)

// validateFileNames проверяет ненулевые файлы, синтаксис имён существующей
// identity.ParseFileName и точную уникальность полных имён. Пустой список
// разрешён для нового модуля. Повтор даёт CodeDuplicateFile со всеми местами.
// Недопустимое имя не исправляется; ошибки identity сохраняют свой код.
func validateFileNames(files []*File, context diagnostic.Context) []*diagnostic.Error
