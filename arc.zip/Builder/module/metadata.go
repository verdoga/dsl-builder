package module

import (
  "encoding/json"
  "smoothlingua/catalog"
  "smoothlingua/diagnostic"
)

// validateEntryMetadata проверяет шесть метаданных записи по итоговому уроку:
// ID, Title, Subtitle, LineCount, CreatedAt, Version. Эталон формирует
// catalog.EntryFromLesson с прежними FileName и Order, не дублируя их источники.
// ID, Title, CreatedAt сравниваются точно, включая регистр; Subtitle —
// с различием nil и пустой строки. Совпадение ключей ID не разрешает отличное
// написание манифеста. FileName уже сопоставлен, Order есть только в манифесте.
// Не сверяет корневой Manifest.CreatedAt с датами отдельных уроков.
// Возвращает отдельный CodeMetadata на поле в порядке manifest.Entry,
// с точными значениями записи и урока в Details; не исправляет рассогласование.
func validateEntryMetadata(file *File, item catalog.Item) []*diagnostic.Error

// equalInteger сравнивает математические значения уже проверенных целых
// json.Number без float64 и машинного предела. Различия 1, 1.0, 1e0 сами
// по себе не дают рассогласования. Это равенство метаданных, не арифметика
// ревизий и не проверка схемы; существующие проверки остаются у владельцев.
func equalInteger(left json.Number, right json.Number) bool
