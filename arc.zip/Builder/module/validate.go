package module

import (
  "smoothlingua/catalog"
  "smoothlingua/diagnostic"
)

// Validate — координатор проверки готового состава без его изменения.
// nil Module даёт CodeModule, пустые Files — CodeEmpty. Вызывает validateFiles,
// manifest.Validate и, только после успешной схемы, catalog.Import.
// Import проверяет размещение у владельца и возвращает плоские Items для
// ValidateLinks; catalog.ValidateManifest повторно не вызывается.
// Ненулевой State с ошибками размещения всё равно позволяет проверить связи;
// ошибка одной ветви не скрывает независимые ошибки других файлов.
// ValidateLinks вызывается только после успешной validateFiles и при ненулевом
// State: неверные числа и неоднозначные файлы не передаются сравнению метаданных.
// До этого moduleio проверяет форму прочитанного JSON средствами владельцев
// lesson.ValidateJSON/manifest.ValidateShape, ZIP-записи и один manifest.json.
// Порядок ошибок: файлы, схема манифеста, размещение, связи. Любая ошибка
// запрещает запись/успешное чтение модуля; исправления и пересортировка отсутствуют.
func Validate(value *Module, context diagnostic.Context) []*diagnostic.Error

// validateFiles координирует validateFileNames, lesson.Validate для каждого
// ненулевого файла и validateIDs по ID уроков. Не повторяет проверки дерева
// или встроенных ресурсов. Сохраняет контекст каждого источника; при его
// отсутствии использует переданный архив, техническое имя и известный ID.
func validateFiles(files []*File, context diagnostic.Context) []*diagnostic.Error

// ValidateLinks проверяет только состав и согласованность связей готовых
// файлов с catalog.Items. Применим и до Export для рабочего плана; не заменяет
// catalog.Validate/Export, проверки схем и итоговый Validate перед записью.
// Предусловие: validateFiles успешна, Entry проверены manifest по схеме;
// отдельные повторы ID/имён записей ещё допустимы и проверяются здесь.
// Координирует validateEntryKeys, validateCoverage и validateEntryMetadata
// для однозначных пар. Ни порядок Files, ни положение секции не являются ID.
func ValidateLinks(files []*File, items []catalog.Item, context diagnostic.Context) []*diagnostic.Error

// validateEntryKeys проверяет независимую уникальность Entry.ID через
// validateIDs и Entry.FileName точным равенством по всему списку Items,
// включая разные секции. uniqueItems схемы этого не заменяет.
// Для повторного fileName сообщает CodeDuplicateReference со всеми записями.
func validateEntryKeys(items []catalog.Item, context diagnostic.Context) []*diagnostic.Error

// validateCoverage проверяет двустороннее соответствие точных имён:
// каждая запись ссылается на один файл, каждый файл имеет одну запись.
// Отсутствующий файл — CodeMissingFile; файл без записи — CodeUnlistedFile.
// Повторы не схлопываются в map и не дают произвольной пары для метаданных;
// их сообщает validateFileNames/validateEntryKeys. Порядок: Items, затем Files.
func validateCoverage(files []*File, items []catalog.Item, context diagnostic.Context) []*diagnostic.Error
