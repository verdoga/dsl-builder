package module

import "smoothlingua/lesson"

// cloneLesson копирует FormatVersion и Document, делегируя массивы страниц
// clonePage. Копирует Subtitle; сохраняет json.Number без преобразования.
// Предусловие: lesson.Validate успешна; nil возвращает nil.
// Отдельные функции нужны для изоляции модели от сохранённых исходных байтов;
// сериализация/декодирование для копирования и новые типы модели не нужны.
func cloneLesson(value *lesson.Lesson) *lesson.Lesson

// clonePage копирует Title и каждый Node через cloneNode, сохраняя порядок
// и различие nil/пустого среза. Текст названия не нормализует.
func clonePage(value lesson.Page) lesson.Page

// cloneNode копирует указатели Flags, Data через cloneData и дочерние Nodes
// через тот же шаг. Сохраняет ID и весь порядок, без ограничения глубины.
func cloneNode(value lesson.Node) lesson.Node

// cloneData копирует Role, Answers и Value проверенной модели: string,
// lesson.EmbeddedFile либо рекурсивный срез lesson.Data. Сохраняет Hint,
// текст и Base64 буквально, не разбирает DSL и не вычисляет флаги.
func cloneData(value lesson.Data) lesson.Data
