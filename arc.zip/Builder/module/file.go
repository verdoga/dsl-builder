package module

import (
  "smoothlingua/diagnostic"
  "smoothlingua/lesson"
)

// File связывает неизменяемый снимок урока с техническим именем и байтами.
// Закрытые поля исключают изменение модели при сохранении устаревших байтов.
// Это состояние сохранности файла, а не новая модель lesson или запись Entry.
type File struct {
  // name — назначенное имя; после создания снимка не меняется.
  name string
  // value — независимый снимок проверенного урока, недоступный для правки извне.
  value *lesson.Lesson
  // original — точные несжатые байты загруженной записи JSON; nil у новых
  // и заменённых уроков. Не ZIP-заголовки и не повторная сериализация модели.
  original []byte
  // context — источник урока: технический JSON либо архив и имя записи.
  context diagnostic.Context
}

// NewFile проверяет имя через identity.ParseFileName и модель через
// lesson.Validate, затем сохраняет независимый снимок через cloneLesson.
// Имя заранее назначено AssignFileNames. original остаётся nil: moduleio
// сериализует модель стандартным JSON с отступом в два пробела без BOM.
// Не генерирует ID, даты или ревизии. Ошибка даёт nil File без частичного успеха.
func NewFile(fileName string, value *lesson.Lesson, context diagnostic.Context) (*File, []*diagnostic.Error)

// LoadedFile сохраняет проверенный moduleio урок и точную копию его raw.
// Предусловие: moduleio проверил UTF-8, целостность ZIP, lesson.ValidateJSON
// и декодировал value именно из raw; повторного разбора JSON здесь нет.
// Координирует NewFile и attachOriginal; не сериализует и не исправляет raw.
func LoadedFile(fileName string, value *lesson.Lesson, raw []byte, context diagnostic.Context) (*File, []*diagnostic.Error)

// attachOriginal возвращает новый снимок с копией непустых raw. Пустые байты
// дают CodeOriginalBytes: корректный JSON урока не может быть пустым файлом.
// Вызывается только LoadedFile после установления связи raw и value в moduleio.
func attachOriginal(value *File, raw []byte) (*File, *diagnostic.Error)

// ReplaceFile создаёт независимый файл с прежним именем и готовым уроком
// после revision. Нулевые previous, previous.value или value дают CodeFile.
// Проверяет точное совпадение Document.ID со старым написанием,
// затем вызывает NewFile. original нового снимка всегда nil; старый целиком
// сохранён. Другой ID даёт CodeIdentityChange; любая ошибка — nil File.
// Вызывается только для принятого изменения содержимого. При изменении одного
// манифеста или отсутствии изменений app сохраняет прежний File целиком.
// Синхронизацию записи выполняет app через catalog.SyncLesson с итоговым Document.
func ReplaceFile(previous *File, value *lesson.Lesson, context diagnostic.Context) (*File, []*diagnostic.Error)

// FileName возвращает техническое имя снимка; nil получатель даёт пустую строку.
func (value *File) FileName() string

// Lesson возвращает независимую копию модели через cloneLesson;
// правка этой копии не меняет снимок и его байты. nil получатель даёт nil.
func (value *File) Lesson() *lesson.Lesson

// OriginalBytes возвращает копию точных байтов либо nil. Ненулевой результат
// moduleio переносит без пересериализации; nil требует сериализовать Lesson.
// При изменениях лишь манифеста байты всех прежних файлов остаются доступны.
func (value *File) OriginalBytes() []byte

// Context возвращает известный источник с именем и ID снимка; nil даёт нулевой
// контекст. Не подставляет document.filePath или вымышленные координаты.
func (value *File) Context() diagnostic.Context
